# Eldoria 20.5 — Animações de poderes
Adiciona efeitos temporários desenhados em Canvas para as 8 classes: Guerreiro (ondas sísmicas), Arqueiro (três flechas luminosas), Mago (círculo arcano), Assassino (rastros de sombra), Tanque (barreira), Lanceiro (linhas de investida), Samurai (corte curvo) e Berserker (explosão de fúria).
Os efeitos aparecem ao ativar o botão PODER, respeitam o cooldown e desaparecem sozinhos. Limite de 12 efeitos simultâneos e desenho simplificado no celular.
Sem alteração intencional no dano, mana, cooldown ou salvamento.
JS verificado com node --check. Jogabilidade em celular não testada.
