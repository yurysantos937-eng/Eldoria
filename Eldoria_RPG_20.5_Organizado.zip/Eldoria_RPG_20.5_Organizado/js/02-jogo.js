
/* CRÔNICAS DE ELDORIA — 02-carregamento-inicial.js
   Código original preservado para evitar alterações na jogabilidade.
   Veja o arquivo LEIA-ME.md para encontrar as partes importantes.
*/
(function(){
const splash=document.getElementById('eldoriaIntro');const fill=document.getElementById('eldoriaIntroFill');const percent=document.getElementById('eldoriaIntroPercent');const status=document.getElementById('eldoriaIntroText');
if(!splash||!fill)return;
let ready=document.readyState==='complete',progress=0,started=performance.now(),finished=false;
const stages=[[18,'Abrindo os portais...'],[43,'Preparando os reinos...'],[69,'Invocando os guardiões...'],[88,'Reunindo a magia...'],[100,'A aventura começa!']];
function finish(){if(finished)return;finished=true;splash.classList.add('introDone');setTimeout(()=>splash.remove(),850)}
function tick(){if(finished)return;const elapsed=performance.now()-started;const target=ready?Math.min(100,elapsed/68):Math.min(92,elapsed/75);progress=Math.min(target,progress+1.15);const n=Math.min(100,Math.floor(progress));fill.style.width=n+'%';percent.textContent=n+'%';status.textContent=(stages.find(x=>n<=x[0])||stages[4])[1];if(n>=100&&elapsed>=6800){setTimeout(finish,300);return}setTimeout(tick,45)}
window.addEventListener('load',()=>{ready=true},{once:true});setTimeout(()=>{ready=true},6800);tick();
})();

