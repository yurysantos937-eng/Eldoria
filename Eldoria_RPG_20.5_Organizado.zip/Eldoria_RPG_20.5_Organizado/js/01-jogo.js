

/* CRÔNICAS DE ELDORIA — 01-jogo-principal.js
   Código original preservado para evitar alterações na jogabilidade.
   Veja o arquivo LEIA-ME.md para encontrar as partes importantes.
*/
const ELDORIA_LORE_IMAGE='data:image/webp;base64,UklGRo5QAABXRUJQVlA4IIJQAABQHQGdASr+AcgAPl0mj0WjoiEVeU5UOAXEsjZ24TkH5EK9wL+KomX19/R80/j3tS+SffvWv/j9envv/C8vn2L+g84n+5/ar3Xf0j/W+wR+wn7F+6n/s+t792vUv+5/7o+7H/0/3J97H9s9QT+wf8H1xfVa9Cf94PTx9nD+4/9r93faw////s7fDnV+VnoN+Zfy3/S8NfPL9O/hPRgyx9sGpf39/x/WJ/l+AvzW1C/aHoIRWXCnwD+N83r9Xz5+2P/h9wT+iegv/m8Sz8r6g39X/03pV/+voZ/YP+L/8vcO/Y4/CraoDOroYc752sV3R1lcvkEKqx6Sd89miCC6mYrJmyYm6rDeIcILJvENoMDoQOZyw3W90c7W6vgtOVDbaV4JrTkKB1YRRXBanUBuiW5eW7igK5GvcT1kLX2qtNM1ZxlBfcVVWYrr2JJz3qkH+zte3rxpMH//lOi6hV8P5cVjhmt+wMVPGs3D76u5opPrpKQGpObGCG9zHOTontDBir2NsFOWwJexB9mLE2iOxtNkk+Ssuo7Eoz9hX4qda9nHGG94DphbWPU+oOwRO0q3luzhl3t1Lw1nKzxxE/Ka9BcUbOZvFwc6uOU9/yxbKCq67uCgVS7HyFayO9QCP2KYBg5VO+o0JmPO25Bp15aVGhFQK/WZF3cR6tR3MYUkEWHg7XmZh0P5TzMemT2GParlNVLzz92YOE4w+qvQVsiDxHG8bnue0+cxd1GyXZRCiQDSJvN+hzUNUWVnVhKX4HZC/gYMPRXlX4WBfkky0gjuLTgGyyEz8yOz0FMDz4uAdqWqFLZyreECfZsIEurbl2xTEZuS0jDEoiku6dUp3IDbB7VRzURo8DIJOT8J6r5oaHLfVUcYv7C8RLrOu4Tn9btPMwQ23/vMgaVxgc5izz6kiZYHvXeSDZuMYkiRcs0s/sYfd8T2svVAIMq6U1S9nTtxL16mir7hc0K9FQg9HFqy1sKr7fu1CiklGSxiPQgSXyV6qSHDWE6172NBS9wQwUXtXQny3MXBbQskFL516oFBMtXUJBJ9HDLL3lgJeJdjj8EkDavX2sYeUkOkAj/pnqp0fWkZM5mHGDVy387H/bBCMvZyelQiJK1SpV/nwiuljZ2aJ/7M5+UIX9KZ/s8+F+TOMSQHbWvgLPtw0yKn9/bseuV4zIXrkyFt104G71b9RXOqOghy+qv4Wh6ZM+04/yH5ButJ2HcWeZgyYoVWSdj4MTzRi3iQJL6hC/+TUb/rnvUmlMeDNTpWqQYgRhyI0Xn/6ttTvCpIZ1np+a2i7gEpTz0zFCa6r9NlPmCWzEf5lW7k4U6XGLHB2zZkFUgIA/65kcgdv0l9s0WITmdbEAuhfyfBUNEkbB567oaKF9QcM147gY3AtByElJWpRBNTDDK/nusGT9K4XxWKaENdM3F4ARoa812IYqeRH8k11lw12gd1vFLJW4GMj34WVhPUhuR41fefcv0XJEqQBxU/yEwa3664VD/vS26QPTtYtxd9dgnRDPmg41NgrrXyHBxFczwGt5UA+y6PKZM5fuR72BM18qigG7VnfHGxHIGBtAOPCfUgYugXa6xRa4i9D/lXyOBxIC13AflqL0ikWTC109VSHD/oLePjkf7IjsiMdH1OTddBzDL6ffQ68vkMtTKu2+Y6QTSB7GWN5HGU3sIdrc7hn10aLoHqhHPSAileew3Axk64b2Vmw/EFQ+iVLH4LstIbL2b5REsFteIg42tIBHo4bFMG2wyolw5bnWfHZlXhlsv8mub7GSwdCQBezqv15EXEKW0aN7jQlLWJx6ficlEyoyGzUKsCKqReveiYV4QXRgZa7i2zPG6ajiHMo34XehaBoQsLmBzJTwORKjy1qZZyBP01j4/DWnmXxDVdMhzrXSpstWoMLNl8Y2/m0A6aU70nBajEP5FvtCh6wF2t5PZS1TNrXkWSiI0bnFMb98yH0ETnkIL8MVny72/OMT3I6uh2qFmUf5gERFlOqotSgM/5AL8oyqrsUbALSpy0ZtfTK1Ok86yp0rjjD2D31IqcobeesbAIW/lH0W0H4fnS/aOj4D+51N3sySyqCp1UMqxHGquG81KpWNBMTxtO4Pnil5gg/21QKJFyzGFxi0g2LOhk9Ab19FbYu4MiuC/JcFmGUZ0xOAmHLCHYdAgn5CKA9akU+FN1HkxoEKoAYOiaYaJifAXzD/svHB8719LxcjKawQzdnC5iffTdQHS5MsaYiaR0jiRsl+D1A0XBWskAJsDhI+FwyvIOXrYnF9GtxSxqJGiw+JuFCH6xyUP/Kv3+l/0bPHtug1vxC1WJ1P2L76yvHsjG7ZYwD511d7BVb62wJsYcXjAL7gwcEcse1VcdpP2EKTWSXXgOKuj+wcLJH8FGZSJ/gmq4r2F1I8NKr/x8qDdxbM4PTgxOYZm5qVQjQvJ7vqVPUtWAeoqErrG6Rg/3wBkiXVxb1E1lngjY0B2yknHD6i6tYz0i50+8Gqme5oVlexvYwcLml+dRsKaUL5sm3L+8G6Kui9aTS8H2mOlgFghcCPjsHRptpPjXSrRD5zhK0GTb9qruxbemTub3KLc5gaXKeHfsaEj/JJaB+EFsUnkk8DhJuImowqh5N4Jn8qNk65nHC53UfrGAjJI7YaAKFx8PsQFP4vMqldNT9qIHggQv3krWZtFhIlnHW3nxXa0Jq5LJxVV0pv83uE18PSc+U7xw8nq+WqrI8KzqCorskHiPM2R4dZ6ISj9B6/MaljZug5xXnfCGv1kMs0e0WcA9ipeAvXlcZAtCXlaPhE193iTuHi3hD3BFaw/zDD91toGFhvZuN1kNuUB3D4tPUgJuVclhTULTRudNbMNDx4n536jhp7bL3yrLQwGYKlzj4o1lvMnm8uRPqzbLI4WZYxj6agCt7vK9sKsIxjYaCrDdPD1jLWjxGCh8glM9R7OHIsLTr6tHpcK67i4wL7vx83jnpEk/Nf0E1ZwWO1K5OPql8JR6eh+CiaAH1r5jfR3Iine0Z0Qk2MRKlp68sBA62rgD/huSUDmbEH+gm5/0aruyJApDCm4lAAD+/Tgsn8K/Qp5v+bS1iPRTABJ3mF8Rehw1Y3FXN3ET2X80xEI5LkUP+IIW2u32qmqhch9ik68+gBFOkiH/+aYgCABnwACXXgDwEGxPhFajj4fMSq44gqXaLtvTn9cygAyH7NAl+QyOJ/0K78/wAaZpvpWA/tpq0/8D/x6W66/7/Yv17Z76revf8U/whta2zvvhH0+/4qNSc6xI+uYAn4bUagwdYBzwEzrbyTJUzVNA2Hxptr8f8xI/NSHxndv9ole8jxhbB/+/i6z+fuyAN1xNQAk/8M7tk94Nrwl4aEmQmgbIGkkkSbVSGCl6xzxWjM70MG3AbVFX8PThAMf1+7BFdoVk4IJScWz2is6xkHDqP7y5HTGT76Ht6iFwN4r4QiXBg8g1UvqrqXR5sI9HdVCqy2PQaRc9czJtoYJCCDqVBYTdPeHwe372ZQDz+eCZjYSrr8afCZscI9LMpuYzIuhOr8xAFm9SQS4XcQA9uSb87SPZmER9RBHt/W1BJOdOLA5+PCGyU4UxKAwuNnUYSMjJNc0U83otHL/fmM7PKFz16EdwqHVM58m3g0ZWSeJ0Ry6lK0mzkXrclQ/cRpraVJgWAwe/WfZXxGyhF3yam31tgJN0GDEEtD1SDzKSb/tUuv+bt76tZfMmaclx3Kbn9JIR6LZRwQdn/Br3KrUIfQFtghnVciduwlyCKSpT0mz3n+ULBjiw93iyKGT4vRsDdAcHAigKVZUGt84Rlz15LPmkA07w5pTmxNnEwD+/fI0j3h3QywwFWol1Pl0r5SKcn5Fwwi46X7XU3BFTWC+iLQtly7wKMRnSnd9fg+6e5dniWfe+tvlMio/XR3xVxgVYvcMwxG6CfRHs5vL7ddu7ub1tDuGqxE2HVmdqS5/dQvexBckwaWbQIZkyB70Zqez88ZunJe2fMwUwcWoZ86ZYHT7IhiXPJN+7kz4WA/QHEYDm1O+EnKP1eoJ0GzLDVgoSCdAoHq4ZWgfqYWjSmZSlZHtXl37zH4ZI9GvHZabwlyvJS1n/6sDbZlPktUuZBH8wvf+bRIGBPKgVT6zKz+Xjjr458oIV/D0MYGDMOSv9FCWlZzYKtLEEODte2KpYCwe61WszQXIEf2rvacDcduDFslyKSbzdiAhCH14H5TLzZKwptZ/04swMjOamabcIRawEbF1q+KgXSOyEF1tpQM0/uv+SWkxp3x7cjUgHNkjeYbrw9DWKi7c9EJEyNAHe+6LVdDpANnioQPz2a437BRQq0xrvDjYVPOXBj4NwrR4e4llB5tbVp9RXeGalsNgOp8/IPZQ5EBiI2StbiM49R3iCqpjOAaK3fgqm/rcH19VH7Ay7b6mwI8/hh7r4ARPxzmvUVKTlPR/u7JWTRGQM0yLMFdHpTPQInfsniI7cFHi2Y+pwQs8w32iAux1Pq/4zh3j/p3qFEWgnlmHEznP9dPSZuG6/kIeP3FGcGXDAoE6eI1r+nGdkVF40FRSqgIe5CjCxytDaZqH41YI/O73bOnvwkoAiJQuIkJlvORmUER3EvHjA8qKtCd8OtSHRegGQl95Rbs77l/qvKYSwiETtpxeTjwsUWvSH9P+C1GqS1iOke+KPXv/cnZYKRM8kh227tMsvHW8FEBV2Urb8VPXowx4+FGaVeqZL7JMaT6/PIttIiBybM67unMmLcXtROpFJ5C99DmWBoMZlODgzyMGTYEAURB42mqj4O7C8EdVoAQH8ZJvgmAOSp5IguRCVLEyMQP6a/8RAkO5qt7V9S7Pq7zrXBjcoKE7Atgd0XQ2XRgtYET36r7BYGW6eX0N7ZYPPMgFL/J8PHamm0mIkh1DlVSOF43qrJE4zJmedGtGOLLJipAXHWFV+9ecoYqIkch8Q3RoJZB9jzkH+NnWdFbMZigaYa9MAaQjo7zQ6gDb0TABoVcWaR47I2mWOLf3FjWdoivslM9J1DRWgP5RZH+dEgdkGOXjLTQyct+vh9cjR8EjUz3dXsfQ23eOjjxhD2T4KcvLyPEU0aHlvrqDn9EIyIMtt2NO2lbiLson00Z3kfVwq75RCtgNsiV7Kl28niUXcxkz9fVsRpZYBn5XCj8EUu5L0q4J3wIrxllirGFx3wTl5InLSPJW2szhcPdXWAC1kFuVTPGvP6H+EU5Wr1ldooV4GnxqH8kRVKcAC7eBlKP8ST8oIQZDUVW8FdAEOPVO0ltyeD7uSl+04odSIvDtpdYxWas6VNJaCIk6fuqlWB9n0RFYS2N1MbYjbEac3Jq1yUTU3OCvlGQhzh++Yp18AlmlGWgC1Cg8MDHE9RgUKtGlqmALhb2X1f3Od8sHYaAfLH5kpHst7AlkaUTL7jZ7+mctMw9SL7Tkx2nRBPLSROmEb6jQPll591MZk6KjGEd7TSYMY7RfRR7AuWHBCIhwN3Yg8lZtj9urzk4iJ+Awo13fETpqttuKP9h/9r6Ao2IGuTLyBXe/SlDJEC+tWuG4/xc+Ris+pmBdk2oTeTALOzmNu38PaTRgxLibzS7YOfyrOPtcxO57gOHzaU0fTR7dYxYRl7lb/2bsWVLF0hxIsrtWz7hbxWCkDwbTeri6xd5LEVxLKeV1JVRcBrFREemX/RXTQ/Hhx7VXnGeCM5iKGpMdrZ48g+xwLyL68vrh27qGkasGgn5ELWZexFDNUGpBg61NKNl2wFn+hlJtSYtJ2e/ZaN/zPg3U8vyQIWlOhaMA5TKOw35c1H8N7kau3FvHgjfaPuyTRhAIJSW27EsZFOStqtzrZ+mE9XgQ6nbnm86aBlS5oD6a7pCRAdgAwRPymqC2py4MyL3CoU+xS2ee1/BxASbYZQ3+sRX43PCLWo6cQqmyUUQCVrt9JbSfzSiBpuMDLB5QhQ3pwq3aeK9JWALPgY5HTKzU64kh5DaymHDrOJNXhA7H/H3pKXbbql47vqkBrpoHkzGSHQbrcjnq6BVBp7DckmJ6vxTeT6fbbtI7bIviknmAJbAlYmSwSD1s3GY8utEdXZNa+PuabCzQLmrjEga6C9ko0o5iXqERyUXqT+zvHsvkbLJgdXOj3tfkfzOtbtkLjlllJEWGopqJe4lP3NGTHqQumr/kiB2NYnQJ2Faqj0WU6pFwRa4Ak4EZ1uEst62ROq2FIePQDOK+yY4nU7iOS1fRhLoqOtEoXGnq54L8q2U7Gw3HpL+AJbFtCr2xmAmgAj9c7BKbnh+o/II/g2T4cA1TX5chV6ZFGHfgPCER+MxbofG/EdmWupTmXgxkgfslFENPjF+b7rN4+5sC6uQiMDL6HxpyUDRad4ja5vfZWmftgxRQPq+SVRAqNP+ZlojowuSlTmM+LgH1Y/xuaSXt+WM2Y914qRbAvveOZ+tN+a7F8a/7u3Z/ApFW01wGhZGKr6Hhk0WWn9ZhwLIa9pFfLnSgeq0krpCDzx4mjSWfx2GSW6vzW25ZluB6EvFTGMmEdvSgm7kqHTlUPtfzf0uFLo8PCwuBBeeFhMaz8H/WOXUdu8WyQTA704I41AUdaX/NQ8tMH5w9SAXTcnnmgLi8ZEJfFbRF2nAp1VYDNu5MfYmDexwt4dvaRAbUh1kMVZBiNAW8GYK4IpZVmih604I4omnqu4lkOfvvwUZPEO1alj8ovQ9tMqTH2YD0ZD5r1B7aV9x9h5L8odO9SO3mtxq8E0OrJyK1J4M19hzJTOJa4HbX+X1lXPLjS8WpaZoypdl9QRfCiPKbPiTS2QZGNACyoNz//CIVcPe/42ZiaRi1FZChDaHiRETHrdabNTi91LBPSpopfp+P/iebgC5zM3b7/bGAD2wl8MbvVMwzpLvbRbgNMC1ugFApfDXm4rVpYOfQ0ylHSZSPzJY/9ikvAMnh7Ypm7CNEmk8gNbzOI8Joy/qYgLJCIPXxf2uvDR6mtAYDQNp0dWZvnZrRXJJKSPX6JHBZxhDRzk9vWJH7Grxece0ImPwYMKJpKoREdK8tOgZfbh9x2s2fZDuGEYgfKKrcSKjYFMyJOaQTmGYGOj5Q6ENbnpxXn74zxJESUvZ3PC5btWu19AG0KUYw7yptBodxCz9RCQTVILzYVSzR1nLujBE2+3vtH1eZrcQHnWEiIlm96vGKor0rtzywLNH+3JUwB5XE/yoMcSa18cAfA2OiXfqreUYEdhUDK0jjEhBSDzsHPsQMd7ZwzzTGKIkLLR+vcg7I3KkklclLor42LXv8UPmJRAwmnV+sB4QhJwMkaHIwKGedl9aOesvATvVehEL77+T0g3LZuVwa8XSdCLyh+wnZd4p3ugzV2p5eRzObFapPJLwV+LDlE5+BnkaXJkYpWT/mIGERscbJpVyBNbcebDz/gqHaTsDwfSe4jEAqMfNCmo+zMrDqxUYbxtq/+gmY5VcD8831VhE7SYr1SSvUO21pyOKa/pL1kQB0cPwLbHIm+Msf21O15AzkByjB8Gua7JDGcAqCqRws0ivWqokw6W9yLEr4UlTmzifJsJ+d0IPkSqXSRWg+sClNelPk/5IK7prY5IwqMRcs/oM96/3iMVbChh+Y/IwMYR1lUDEuUd7BDxTM51nWW8sCksn02/EcTBp2Z7BhlP4P6e0wwT9ofAX2MUra4YiYyFKImM5p7uWYieGR1LuWtzanAFedU3TyoWair/nC1ypk9O2FKxN09K4IruohZhsKsceZ8W+b+GW2w2h804TvvMFP5BduO60HsrHpOc7aHcaPGH2FDBKFLF+fpJGmvcIJicM8ZQ/upWaW6wef4ocdWP6SGIwxDY7CiHL13FdATaYrsmcZqqSPuDBF/68EId7npjM4crowOc2rj3CCrBixCKM9acuVwkQrcIkEt1m8rJiPPrLSs+DvnXxmT0FfK71LkRZO+FZmWFT8x+37d+RYrEq07W9B0dlnBao4spijZX8Jy3DQ++8QJucC/Sq6g+u+fDB02BpfGpsxzPr0g5wheuDUqE8IVg/j+O03pPsHF8xxPzOaIuwHl3lXJrpl8blfvwV8iNVkpowT0yHhoo9MYwUssSSTjnf5cw/lIsDNUPKBtHkgoNFeXJ+aKczrqGPTN6GZArx0TKTlLUXr74DwcrnDP47miJwvQ9vDdj4SCy2b2xTum2+I6EVT+G5JBTCs0N8YDof3KmCPkuHaTnC8dVv0Hc6O3VQOWXjgBv5ZBjtaNanjYbFm1513qqWjK1GMdpXyxy/l0iEKRogDTqi6apB4h2Rn16vu5T5Qii8J/jY7E8g+7X7Xct+eU9QBrZaxgDH22f8kyHUQcQ5LjM46YeY5v242ecPYMWKM6x8CBES5ZGvekCafetqZxq0k0rCXtpD+p40iEgVnf4eQhWnklWwD12POu4SJtcmtTvgL6TNRtN1fw3+WRm+bu7js1MlgJJi2Npf6bYGQ5/uwP0KueazU2wRIDwCCCoG1+Dkqcv5DmqRYQkuBn8buSl82MA8krlxxR7RJ2ymOao16NVpxIacrVgb2bDd1nqaGa+DwmUnjZBJZzuT4yOlcJFOQPObx0cXQ24WQzw+Z5oc+QUH3e+lV68LjU8TAVvw2n2tH3D/cWNgLshLBLXWR/65BZry9VIEMUYf6MhRKrnSKHanRM0pqtfEhy3QDpMJmbyxo0MQ9z1Hj0hcOWLL9TE9OC/pQ17m54fuzFlLvo1krfEV+G0PftNFrKK8thcU3AgLFCUFHRBejnIYIef7w6dTIk/BLTPpisf//cQSHRASbwcOVAzcJR6PurbqszhjQ/hOgRGdUFKTph9Pgq+KBBSPJic7nLvOlXHILXUpv3VXOwkixBe+Ed9lmyDrtujT4jzSgXwVsPSNA1zwH/FlP3iinj8rGuV0zykIAwb85rFHzINPygxLBDxC+PbXONlrYqK1eX0w/+SlswTfO07ObCsehUzsl8k8up51Bzy7IJXjc9ADuBMPcJJF8JsrZjzU0RwbjYeY2oV1xh7tdEw36N5YJh8PFgtt+W3b8pzPSPkqx+FrIl46jvvGIWJbEbkAs1HTDXuH7/DxokYPCFz+ZY3PrOpFeX029eGRPGWc0blbdnxqCiaH/2H5O3VFft10f14cFNCF4ZLIkGFYYNtIYitjB3M3hxvUBsyjfiJhFG8zzQuejT6zg/qIG0xdNrtZPlj2jwmBUFxYQ1KeN5dZ3dgssq9EeVcOR3KlBfJ1BUFBOhSHnAStxYYFVvyB2MBPcu49rgZQBLMXGSm0U4mExHfL5OgjMUIrdWOG5hciATK+JXZO724DssDMd1VRaCNrWqFGmWHXF4XEGiCjfeOJYQqxAjzbBiIHJ4zpSKxLn8eHWYqG0tV9RdRpHyLbiMVUtjllejkq9VJ6yQJkLmMn2AjSItIk2HmFhBsRo8BypyI8kKHeXGzK2eUFonlbcrMVQqJjql2y8TDKlATH9VxGdNqdjhAqHuKxPMoQOh80T2dyX/xRRBDiYTFdwpW0wGRmJBc/guyQ5KseI4IojICfld27172OH/oJqJNLkIdwCF87OUkSFmY2Rg7WXeFT2VZ9+Jmz30EfY2747xohWzMcssyd0qmPUFOxn2fl7tJ7JUYMa4LUaNmLJMwxvWz3Qkc2Hw93Hdev+77qHoLaUEiAv8k3MpT5AOXyqMknXx2GvuK/HP8YdvG0un5batA51splT7G4NzMP+GMAbO8xSgN8KGdUXlJ1road3KMjCUdvDxP0WXyeSV4fg/okJyrXWHOhi/XfTHjZnluf5T90RAkZzUP7AilALY4qr3vVF4IPWlh+RDlA/3r52aGNEIyTAq7QF1Vmm3qEG+x39IbjXHMyIf2H82yu+9bgJFcWpUKZZ75RheNqdyFLZDru5cA6gggTZLSlH2U92Ot0hygUWqN6H/vMN8C7pIjogdt07+30JgsMcz4UtA65pdMm5P8DbEq2A2kwAtAAovgGUe8Z51cMEyiEuglOhAAO+yR1DwbFXpWLWQlHPykQJ/E6OunGLzbcGmJuEVYEO35RpJ260a+Rj7ejskhKyy1Nw6hm54gSUFhOqB5A+8B4KXy1pY8fOcOAvmDnzAPjdg3Gx32D3fkfe7MvcLHjDEvmD2x7bHsHXV6dxN+lHnDB6xfeOmKjRP+JCGc/qGzzMroZhVTyP3ZopTM0BRQPpLkRhkoREhxaje4qgTbfN0ZzZArnCXryB18BDXpoG2RA0yefOHIrH5MI2HZ7kO5aI393Y1EyRg+75DDmEaEIexTrcIkKV6Eg7rIbA5PBHpeFeKGpGyOSt7LRxI51dkBc3lfRuaSss/afE4A8UvvEFLPXTY60NAHMetK8e3qMFlHfMqzwHhPnlhyvXA7KmiCmNIc/jkwCow/fko1qYmJMSrjLd6qTjfjs/wM0P+Vc+SUJ+SNqEuDoPrSwBk2Dnzb2q+GWDV/LGaBwLe0SV2EhNpZXqq1J2JRDjAhoLtyitMWl1eRH/z6p/fu838TiMu2t14fTKUVIpBriWvpAyIljZcv/TuiawFdkF+tA3dOJrJYd04uOmrfj9sij1vd9PdBrvC/aew2j3lnqLtWH5tt5pZdh8QUN+lAhVJP19lVfvuYKTLeOn+HavN6pU/G5sfTs2mKz5opEbLp56Y0sxGXev3U/sNYvRT84XoDt4PEksW96WcLdjAG0ktKLER1VUPDSnsoDp9c/m0SyazwFaeRRh/ERp0iR3BahGiZl0fSU+2Mlv10ByQ+/G+PFRdef2hGMFezinvDX/WJosT+9j1cgnOIY54Mba0yGdWFJBL+zU6NHNQ09IGpZfZ5FeA9Q7NfWu2yliMBMfRu9YeON1HWGfaoz2Z4RFPDYEby8UuxVSU9C8nObSJfP6ka8I3hIFTcrdksgBdC3USrt2e0MXYiL4+FoU9BQjL8uMNNczvVzU+mrm4BE107bMgbLwb3d0Nwb7MMr4F5Q63ijs6a8D57sq8QKfLjZ5j9/1VCx4h1qXg/62GqIDkqdijXe8eoG9icDTR4sCaRS/zpMIaAOCoGJjYd8tOVjJcvweOfFE6hiOFy+iN2gWK5Vp/c13QNMiotkMtcJvhtWDIkzJsVkTBaUqnNurF0Zmn1c6aiznXgmQD7IrteAjeodq2RfKAJD2TbGmKHzWyyzqCXrf0ZsW+n7Lg6XiTqTXHEZSpvpaxaoGK/dzWBvNh1h1t6AD8hNgjL4dUyYASYrSNJhftq3Hq8eoKzqP9jWBu3sZQsRL8B7K0qit5UKWG3BQJyN/MmPJ4I4931GwAj35WQy3JBFl4XVlGLIxsHdjLxqNZY8kCTiCfT05Y9c1PIqO1tiZk7dFHDj78+kctq53dYfZNKTCyVa3jmTit+xaDeWCRabmKVDhuV8J05Ch4FK5sRvuhZGQlqu7aG79H06+c+6MaAYZ0ssD+BcN70ETEXHDN8XehV/ASFxJOgDwzWMl3HSRmQOkXyHYYK9mtlRM8grt/dezaBpi0V8uiDVYG2m9Re72TOEXc5JC8DWJWGVGo2AUNMyPMIMF5K/8iC8jca1MrZ16jMLGAzPrJDpTiUHuzqH1oUdTnFpNIQr4c67B9TzqedJOurZooaZhfjIP+mgPF6Mgvx+v8vn3kkqbz7FBwNyyJpmyqb+s9tOtpsZON4XAjmKnrArOw0Pl8+lFubRXZRj/fN7fjmGNDVyarp4FKwJY6HUizcRCt3a02BLqj8reY2lG+JfzJR112CQ90kJgrYrsFEg9hRJawQu6TYc3Cg+CJB6sZ4uT1iBwyRPi1ScvK/ajO2vOTkEry5JTo90SfNF2ojK27IT8hh3VMuR/+/yMgI+S9hM4+T9bRfK5TXd7SQUv0ANxQF0qn8PvhEJkkug3f5Wp817gwWTF0WT5mT3R/2yMrfkkYSiCWWSELtlTuJEE91lOwM24U8OTWNHPQVKA7znTgF2C9ku/Tc/il0+djqqicbNe0R34W59dmLF75xQWtibOeyDwuVrAwgIohCoFFwOXLQ1pA5FNAJBTno80fq1C9KiIr71jEQI86abATSQa8erU3hT/AExKMXNyqzKidJsKZoVwGlWvuMZE/2lLX8yK6yhjuG1rktKkeWqP1/tv4AcPxurNZe+RqViWniLyz1zGsslEroymxoujMDOJ68IM16yF0zeJ5p5z6yS1qZ6SUmsLPrt9DRysdF0lEtleuGpHrGCWRtfD/Xp4QHdjEqu6pkxEw1vJXTk3Tf+7vxjbRnZpF1YG9ZTTUUKMGROlu7AqpKHK9Qiwe4Q06Loih2XEq7c5iRnpPwBEw3vIgy+BydLdmZQIxnMaQARVyb4RrHOxbpurWwKpm6KiHhny8uw76tPyq4Z15GUCd82G/LFcIYg15nL04uQAuwH9WTHTmfvwqGmNYP5fyqluqKYEFvDqIaOL7kLE8XNRWOrjwMF5ESb8ZX7VRANoNuC+JmI6QZf4M13jcEA2xaRS+v0tnCG/y/iPltjDRA9Cjlj6sJtoX4BmyBHrcvbTIp6VyQa7ziHYJPIxXryMvwFWCjT36KTthpAev6pg++tM0EYyb8/CjRTcaWbGIrIHdjzWLMA2neqS9Nn7opiVstpdiGFWLMHiEsU1x4GEy890ZdVdmnhayXX3IEWwBmR3LS2BM26QaKTujApZxEjtqCt6bcmkW8jYw9YvpIJ7ifOwqCEOemaqYw6DDcQUt/uSwDGxfVDgWG+N88hSaraxJgT/B+lTuITAw8/YdsCNXO97+qUr1cRkS0PIU8EjFUJYKL9nNtLxu4jGrbefJ8GmDWfRclGF/4uO2+OH33g623HvPxHR/uRde35UOxVBqPVjWu5MIBHHqSSBXLt64Nh3zCZP7ulwkutqe/8VGsRh9vKHQaBSeTP4NBKya9Q3OXQ9d+WM7NVKUr3G6Oz5x4vDH0gECklcPCidxFC1Bh6iRlwtbxYpTI56izYo6dj1Xoagxf1EiuPp7BlpycdZ7Uk0MiXXk4opMYAmSzqPgcMvYd/7FV6IoyyTXeH9ahJ4vkJxDcufNcU3QDe2LJmGE0skGA/b8y2kz1oTAQ16kb7+NcIYEdqKy+St61+uMnC/O0y/x3Ey2Yt56XnDKuILaeDuq8bomPz+W/ZgEPZCuQU7+vdG+aCiW/a9z/RSs2KNhU8plMBuWIhhqnTB4i7b29OkL7Uh8546aeGfm89yjBvTpsq8mSbDzuVgpsoYrVU2AdyCfeKKkyYI2Tq/VFJ2FAAYdPnbRMlL8ArO/VnmXVNCsrySHFRYupd/S0ts/3CagWDrBQPmOysYYGJN1HMU8OwrnSWbR7lVGN+WNLb4ePXpRyWa7S5jFnmgZcYf5gpoUlGNV5f4yaIpDZwftJBlJve0MDIDHX1XOOBbCCUf2Ul7JSq0MfxfSos2in54YFJHxrNZGVvCEnepXZu493Fs1FJsKZFinyKk/9SV3aBo7aJocgfTEqwV081Khvu3+K5Z0A9fj0Ew+McnKnu9RHzkpThrKWPiQHNq2vjU8Syl3e4Tu5nG6QhfWn7CH2IhGDQvmJW7crayNmxvIAQoKN9FOv4RKQMg0ZvZmkGAlZ0cEjlxWaocciUc7VCW/tSMEZ7savAoZsZsrCTDGRsdqlKuGU2WjYC+vUz7bglyYGb5BAzA9a8txKiT3zJ0yxdgc6tht6dcvM3Xies/jObiI2d0FTpQVYz0Ll06t3TUb+FikpPhGYxQQCdgcUdwEh/dPQ8Em8FzLjhZB/bVLqq0JjICB4HM8jMVItyHb1BP8jC4obDAyBcuQVhVvaOuVpHAo2FIiCOMAWwqPpfKgKgNYZblmpQW9JCQa/JPoWX/KUYGqbdOmATP4UhF8n39K3EiX6QfbYbOGw1+12ssYPIFr0nowYMk8CrXf0uFuxflDVujbWiENIU8ifkD9CQN86kM5/bfkGOCa3+wL/sIXCjzClPv0MM9U/52nMsNy8sNUhF9XNXj4QXeZy6Rarf3tLSXVFcukAnKmegwIvFR2EFZtboFtzVlgRGujwCx3VEExqpCQ5hPNTdz0fgYN1DJmll+zkCseQm9xbzaxwf5tXO8weoGjd1O1dKeFmmSZCzNHxlUinBuPARmrcMFKDJp/cZSSqbZ0gvzSHCFyiPwTorNpxGYdQHHUOgX5+DxuYC4mL6T4sv/OdpkhBgNBq3/7wIcFw8wmI3miz9rnWkHkGAKcfYjKcu0+mv4Ypw0UZ6kuTdiJvvtwYpdoaBDh3xGs/vvDQdPpe9UhkaR7CxxX05zsVwIT47u4xgTSGQJ95L/axDgGvMSqZ1bGcQR+Dp5dIQqmcQkSrzELw+rUHTwUbxuh3/m2cKHHjJEgQ0rdtuInZ6GICkLEZuEqNFjP6VY/s9XXzwGv1nUYJ746JtJozIyt2G/ccFiqv/iOjGEACHQJynOlY1+m4QonkcBVdmnJfgvGBa8nusCuqxyy7FnYb3amwGjIAibABVm22sHoWJfYUhpi0wA0UtLJ25eWEhkMpzHi8rFbDDikO8hnHv86WMNaACy0A+WMGo1RafAPmCWnvB6Gcy/I6ovxFkgYuyRDp8QmdZXaJ+kr08gGcTZhSEQDP+lPvcQOBlYDhRjSTWNceJUfOy7WyPgnEHMPG0GGxBY4w++5h0mRNc4d9h7PDXjlh1jAEvQydJK/6XuYJRdWKu5S2vtUQEoKwmpoZPR1SZQttFwRC4nNmlQyF9wQt9sDbsshA2iMtViMLC9xkk9UlQfqgKvYnZZ16iPAoy4/N6SY07sqbvPAekT6GafHupR9+c/EyHs2Bsk6GQk+6LiyaZ/NJvRs1Sspq1oPazxpAirX0l3CbbvrnOBXG1+G5c+8WAE6fhtfdehKZVhtwfk1WeWIfRROA+oV33b4+yvP/w3Kle4c+c5ZyvWiTyOSrWC/vCtsf7+j2WWN2cGOf06pdNRxXUsfYbRdf5BqlYjeMfsV4FBEPPsEQ39zgDuHpmX3HCs9lQcv5gISqpcpt0B1Nb0q1mroAfVMdwN98Nx10tU5Fq/vgcioT1U1rtwlQjwIIpkACownAUO8uje/gpw5qKFJz6OpIZLrDMIygItX4gwFGYhPS5m/l/lXYCHJoC+4boZzMA5qRECfvel7eH3QB7jSl9T/Ha3LVf+OCO8QNRbIZ+/u1PEGqH05l2R3ZGy8xy1Q4Idq0/PDR75ZXpe47k2XYSjioTtbwGJTP8ozQ9i/F6hQ20TRXDqcl1w2lVv5zxq+SEtKGCedfXONxD7nDd82q3fUOecAOGenZOva5PwO3fp7FJsHkY9U3RaDAMJEqoTtiJJEWo6fBUIV4ZWB6PZwrjjvfYEjwsZxNetARZDzgrrP6m281o0crgSJSEFvdkm+ozu2hNVVpJywjyY6WfJQUqePHe27XollzQ6oP1RviTky59lndecfEw+jZaCH/ILEetOqR6QmsGzMBeGW5U55orH528W2TGUD1JdaqskKz/XDJz7ZTcIl93EAtdNwKK2Zg0QOBf8IsY/d2qBHMlF1t7aFoz4qvS+PeudZvYefRkvrOzzQtrp4CG7M70VRZbwP+4u9X1BrQkGWIShOf1PQkfqUlKMxjLGlwLHfFHVOAI91AZYLA53BXy2f6VE+EmiqnTclE6K0bcofnVvhTSnmBIfS2VV+AupOH+JzG6qlSU+emmiLR00FXl0zPyV8ibr7zyP/rFV2qlMp0NYnRcZks7JN4lTN6qnz9saEJGD0cbG2ZqXJhU0thQfr25g1qJpA3XkcF/4ijpz+NmzulykxO6I1HZyWg2S7Fn4YInu2EoL86OywfN9XR9Mq9lEXRtWiXfOzeJBdf0iX5rAAIDjGdtR3u40thYpyWInmSbBfqGClPhqmtPFOSpaHgmMLCjw3vCg/vpukLOjo4hGEw5MtoAstlnHz8RLPIGYPHDP/FOZAGYSwO5cK0QaiNJfMJH/gda+Y2rzzSa+K9MlpTOtRLaDz2ZcI91HT9bAoXGaDSwASQAWsidckglUdyS6BuqXgusj8U1X5Q/v9udiUxHlctj7xWogF1vN8MQ5gPbow4GVXmS+KeMVicDp16WRck6wRlGHSZemOsPVIEu9pabNkTn4IY+dE4ULdhHuwtEWPx7jz+Rp+mHqDATIuayiip6nDWzPcWE074JqmlpuN8jmIUBnMvmudOtgHoe0xZFDcqjWcyMI1yeTNxTKcJI0fbciafNUsevAhLJjmmt/b6NoPyZWbtDAXGYRK3XSjSwPzChVmH9q3F/Spo9Ax4F059fPimG3dn8g2Ha32cuOrFb8HKdgwUTc7NTLhIfdCeLSlviqxLK/Hb40M+l7GhdJdelAx950irQA8bkMfVTt4v5EqEJT6c1XXWfZkl/iyMnydvJmQKWbwjfKV7LnVmMYZb74SOdGa/Br2bCVYJc1z8jbqUiuy2hSLtNhwNlv113aFLciHrGXcEgkLYLWyuSy1QMd35dpndWpgcVJb1jzPw9FeKtqsmCvXft3KkUEsK1tNPnNx/eDLkIijzrlqtYK3E5eHYQjCfPvRfuaDVB57+f2M4JTLckaBdZpeQhjyjyBzFXqPhzOWJalOUAItOsOVvhteMXLGIaEIMEUtfzWqYV1iAED7nhowD7e1ZMevMrH8uexQJLrjceVK02dqK1lBZwJrtgr6FUddpipUAbc1NEd38qWTU5o6+ETZ/+s9USzN7laNCbP6jTWz3ccd2DxvMv0IYP87ZpIuZAaaDDXz++hLq+Hvx+pfI/mSH3b4DR2qupaxBoST02Ebh6MbE1IQ+bUF9CDDNUmz8LLbivQAJ7V9NxnToYt5bnNgJP2CllECOD+XTK86ltNbJyVlguvJLKJ7FWetXc4yBrV21izImnmF3Yit9Pg0IXgXbHj+ygkcplbw4UO8axdfnvonkX37J801SnxiOBQTm3AEskbuHINvjoAhYRAtF8xNerL7MWbdK9j7vQHu7Ca6dmoL5lHvx+6lhjiUdpvTfWZCOwD9t2u9z23C7fDlysc8MtZfAtnmlZmNik0+kWZYyfzbVUwKUo+W4vvJFzR5Hx4myKeWRNqEgqBGfJUHTd1i4SuSNOb/jWUgnHoCAlAX1efZbtr7p3sw9qbpJwTAC9Qk0/D7nuKSMDTIyekl2qPXrM3/QORZEyWSdJi3r789dC5GD/xeVH5z/exJ5rTox4Ha3ddO1ho1oF6bk9lH2jDmxSCGNB3Oj9OZwVn7GTffeNTzGxzFmwl+v3hW/2SmwjzBdrcKJLNFeCK2sLqLRo7KMHgKS0kKf9/00kk6exiL6oDJYtoqW1VVSpcDj8W2cZKsnuCy6NBsMiOm1OtJJmiQNsYdy2phbJmXiSyzVsSgg9UFFa7qIKXGAwKS98P6t39KU3I1rNCVSRAtrUEnz+kmJNn2he+nrHLtRQLU9nMnFKPMXN/7bQUgxr42x5TkMuaGwZt/dbFAnhk1OI/ca6s8sd+mA1gu1S8REogMgnb4KvPIV20Gnn61iPcQ9sajG1K2sGLyOoZ/sfNrGGdRH1EUlPr5pPK0bhGgGXcGTb8+gjEbnHFpaaILleHgkDGgmNTB89H8uucuevaNawgGi4Ps0/gQjiMi9n8zC/RBX+SNUBuQtoATOIHxFrSKJzZGeyvSXHhGRUR6FI8mSr3ISbiKMRrt3kvjbaLgxlC5/jb5Ep6shav0BdoK39COq68cs+EBcUfBxqRfH5fr95whUKZxcAuWA4N6aD6A4cMuTbVF5b7byJdHkI8XEqgr6pYP/3A+suaWYQxEShgQ8BVaY2gXfxxL/8Jv8CeyMm3VUveC4hmAQ2aAnojmDplG2YuccsYxmvjVXu/b+R6Bt/jNO6Y8UPFnDqxmZZMz8Ka9DvjjJfuJP02vJW6RnhT2PSYY8YMKAGJa+2s7ogem7Tumjqa6BUmxSyWHlo1KvKgK+t8Mqd392ySLzFfj3EGcZN/0nDqduE/QAySGd5/SSL86ngT/9Dr3MHcTMX7nXjmpg1W4Ngn+YaLBsN71xz7m/08dndeWLmpVx90SCdaOyo9FT/i/BTeWUALgJti7J1DtpIFGTBAr3ehSAqUopiSM3LnmOk6ZxCBtd+rdtvchYYU665hk2Za7cOkfQekH4mTzFFJf34cq2ZsrfXF5q7o98aJ/YOzsu6sP0re6bL4+clOSATy5XuijQgF9dzd9Xwadv0uGiwdIVfjnYZ4+AqeONClCQxZv9qmRb2G/IsbZFjjQbY3JlnBYPLy8W/29lal61TvdJ7Qnz28V8/6Hlh5UxXk5xr0LVM9156M2agg0I9liYsbMVwcAbmufAsQtOKjGXyN83ZTr/HUL7mBkjw/BNKwLRrzls9ocvIwOtxqmKcKXioX0vM+28TPC52mJ3Dgysvfm+vqazUzs3dWN8745uH6V6/EHFQzFS/aStKV+x1nTVHCX6Z42oKbaTQObp+ms2r0OI1m9cpB3lrNWgP4TY1Q09/5PFv7vkH4wvjMRWOMQn+1GbW6y/KBFiGdjMK/xB9vA9J4pDyXJeR/N97UidSfl5plgdi1Owa1+yLEjNRwdIDbNqkRtxd2zhej99zHjwa40DSDMAgFHwD6EYOpg1A59dtUESz3+WAgtkpbGPJfwGLhXvELi4NCo7ycPExl65y7bwCppOvAnzNmRy2rFev0+PaIzKgTXoBttJ1q3n+T54/g3kOiJz/7yc9t6pVm8IraYEOP9c+n9q+5nct40+/TX6DClG3rDuzlIh9qWW3IkgLQC0Z02W/ZB60GOmkukQ16vxQVHNh9NJ/hMQfzLfqTp6F+wne+hu/3tRQh/mQ6Y7vL2JKQ/kSaHukW0Bgi4Ud93NXFkbXxPxZf9UZoRexS4wWgprtWN+gbST/0FYq5blNUZgF+oxITQr1Z1xUGcE95Zqc2W4ZcOLqRPOXUg6wO+H+VmvqLghAJWASdHPr3eS90iIyidTHVMO5qf2OuKzrAvi1N+OTjn8G8QVRBSIpmMHjNTLH/MFhiumVaFcTskeH6tjU3VrBCDcZ59njulOEdYKGOmnhZX2QIzdgMDTW/xa2VjnBk3Siam3TJ7KDw4lx4QXdAzlne6w9vSfXxCVxj4L2/AmvQP112oIbaXKL0RinfIkaB0ST1wN3K72LbtJXxnmd2B+yRnVwbR6WBzKxVmctmUyUiV7nEMXVNd4Ay24Y+f2IDxWf8j8f/MwRQRsaCACLeiQ+7di0UecxblbM18uCol0u4Pyn/TA/R5t4p+T8Ekt3YxcL/7E6V0DrnnlIHODtiR0vL6oK7z3NVfFtNeoRB+x4qG3TH+CX5qxL33UVPkRSyQB5tVplNeh+X8fvPhIzgeTi67nc5Rse1D3UfBzduurMdSj2pkhaLZYhGwnt3qzR8sJXti8PW7JagGS7Xc6c6I+WY3oYcHswMmD+MVyR0mInn89QqvXe2fwyqyrvSSfzaYPJh0DsmRF5JnSCZcnq2b6ojgJjfrm66Iwk7mNFQw6sI8mU84BRBONFkQUXuOOYSfPIA/SS7HhHKgi+EMyWlZlhgX2H2XpOS8Y5IulW4PcJ77KuOp7PZJYihyU6y9TweefFT+C+QyE0iT9GWpLUh6Z7jeni2yMe2IazXbk9uAp6T9xC0pWVOth5LybG/i2XmpZQLf77c5uf7kErtaM1APL68ASFWGz4IpMnFgRyMuvoKiIfxHBN8CgPstQdBCkUe549E0ryEcU/pWGzIKC+w5E1AfSHmlPwOPz8ficZP+bFT6PvLHX1Xy+vd/ZcTVa382D81tKNqLpdBjIoFqzJ/3+8JxCMCXyFgFvQGdTQlhixKxYyACBUJP5rJc06hBibmX5zjbSdjhaxSQ0cFx8VBpipvUALTWCgGef1fjr956Mxn+6oY1XlllHGDSs4N+19dRMSQmqNy7NVUlm0YqSLfkppnzrcpaVVD+Dz4tSrkB9nQ4/emXg+YRuW31tpNoLBkQMLsHZo8scViS5x8vScTxAZfHNZvZmQJY0bXoJWFPx/iG8cmLZDSf5JDigcyuuu8e6Rp0vnL/AIbaoPNfvAlHj/iGcvj71doUgSCUqHb88AhChJsg0UukCXH/C/uUEnxOti/IuJwviogcJlIx1SgXWVtd63R3r1CveXJsHPHb4Wv7PCEDJa0nL51zGXSr2F0mDIYzfCDlUQRQ1eG2+nvzOKagKk9CsqCLuR6rL4MNINOuRsDQVwQ9K6YjJF0iuzTmGbnMDK0/yUzbgJzwiFuiby2S07kTuNgOoOPVHuN7IYuzNiMkBr62NhxLVcVo8k+DQ5egI9rPjs/Z/423M183tLbRUF3w1+ui52b8aM5iObMj0Lo6Vp74JaFv69SgiNsQHHgtMgfg1uVc5N7BKTLKjm+FAqMpDkwkQbjK50JvOXAV6593wTA6flei591Xkz82IwQM1ioGAIQkG1aDnFYdg+8yLOe+hcmQIRUSSzkZLTyUlOZDi/DDG632K3MoVKBjc3kIececcfM3qJtL2+ovFEBFvfG9SD4Q3LpbdQ8TO2kjxeAmfJSrDXPLLSC/5M26IzXCV56YVlf23qW8NtDrd+tRErhV/UCM0tN2xr+8woiC3oNkgNSKiG1+5VmrBa4u6REg7h2qvaBifoi5J0TwkuIDpEZznEazIZN+rT06tc3XLINHKmTsPLWVGLfuZ1kKCWmWjO/7GjeWqMrjHd2nssP2eNlaZxSYC95TKLM/mIA57bilXoS1fA0btdzwPGjFEPtq1BqPbUXQlkWPd0ITUUD45FG7q4kYzpnvF/OkvzcOWZMmcgpPnq8ctQI/V38kVbP1263wsWChF6Yp8IywD+14KTtmGdGyORmVf3ICgKu5mJrHxZL6C58U9pliRl5WTTDdppJA4jrg/VkgaODfKoSQ2kv7UawV0Cd3iS7ANg+TZj4V9iMOaMj3u9pBhZ9ZR0F8N59hyKecqBmX5UwlG7VHmGAzE2gzyBc1+bgBbNISlw2aYdfPF8CDhTyudIq8v7ekQeuGT1ayge7otrO6V+0Snw9gj8NTAylmFlRpLKTXIWogiHTxW8D1bREsz3fdOBblkjFuanyMJ+/N725yz2EHSoBwzjy9r+/vXF82GgqoZWnGD4vUU6cbII4iCaNsGjoFihm3dBZwiImX90ir5UqbsJQGzKXLg7sWdR/HLX4MHs31Q09vg4kFcpyJ5kP0BO2FdVjUV85EpdEsVd2t8ao16xJceYbBDmJ9wQDAaAQuZcHqxS1dAsl9y1fudzrZE5SusWiVOU0sgdwWBl5X1YAk3YnQ74y7PBlXOSoCtuvoL6pOViczu0GCFb8hCLjgvLSSKOGN5+3/ENREHed+6MLutAE1+mT/29o1G+N3AvVztWj0TsMj5pHsvE02gOOOPEr9dEraNXINkTL0s20NialzHSYVw5zMrRG0Y/xe+/+y1YKQI6byTrNJCpDDqAwcwIqf3rl6pXLN3OoWgKLnU6cg/LtVXKLlKsU6HBA5wOe7DbzAp1liyuP1HS5UWJLhfFU7ioLM1p7CdwMlLtdlX1gMxyK1PxICHThH2syRh0eVSZUdHTWGaVwVsFQ6HiT87YC1T1Ap2WhfxMWvcUJRUS7Vy5Nk12TchLMkDfxtmTCSSAjLL4I50JGuYYs7BBMbqQclf9yWjKR2VjPpd8TnLRg/AKoUHE8Q+qotzuNmdsAuYwu8u0xmlO97Vup3wIUDl7hezYnqwT43jHsjq9Vb14U8/ZqTXGKc1GmtxspCNj467NNGhxtjFQCiEPBO8IJcDfjKAZVjY4p45Gi8612SeYAoN7uQYTy/Wi7H4MwHZ4NgUm9tAVT9fYZ02QikzU3ywlquJeZiqbmiqKS/lQ1n5FvH+8shtf7bmK/CtKXF0vzhfHdgPWE2Zi0qVbgTnZu0gef16gt5VQ8OOeL+Lf8ZRIPL/6sD9pVpcrlZHuZA4Tc2wSJcMBTvttfiRpI0VA0Z5DoG7tlrPyigZZMBFxF0DEMlaJ6DpFEAvOQiZTHPGFdYdUMzRJzgk22kgzPuCg8Rc+syOW2/Ta1AmcNfYS8tXn8A4T6A9kcso2ZTsJ2n9MZXcxn6qubO++nVyy7wy6CoIIi512KYJfPO60ST6nwca+5JvhvfvY49WkK4mvlg9MRHSE2cdV17OucxOT171WklTEYu8lW6w8nWR0pIF+Voi07Ak3cJXQgwifuhJv02mrlfauD3t6zD6Hi4kMwJxFJEfV6874/1u8tL12BxMnJkb5iB62IcxYBNHnqdyFiiZW/tbnwUJ7jUek+crvjKFo4tajB/JA39BiphvDqMjK8qFV2bW+9r1W/nhe3G6Z9ny8bGM2xEtg3qma7T5HYYlBOSSjt0pkRMsuAaBl1uhvXJ3CuDwnhKGDxicYIrOmlDt0qLPVOdByG/0SnRcNE57m29oYn6k/H+0dYg2jJznwsqwhzyqJ1EvoP455ut5gCW4gDRrz7BGUM/ZhYFD8u29lJg+6nWX8Eka+P40S7sI4Bz8pyoceQUuWIGgzObQASdsRFghBkpvW0j0Wzpn9KvY52lDYNl+ZDAQsTiWjS8rgMwvBsRK9N54k/uwxLMnp8szsgHb/OwHVnUTvhFg5P5cACdW9w0nOo+o3DpPsUBbPJYccLRrThAuaJstunzlSZPkvWVtjQJgpIn+qmfx3xLjrzu9Yd/p4qayIFaro/adIgomQfu0BDHMx7oeRE/quqM1Sfy+JEidUW5FYrvGze6i6SqKOVcc9qnTTh89YvNE7m/VSIkhBWZM5xcwcOKKLvMqyLzF9BM5AZeB0Jtq2+T7G3SrbGBS6JkVE34VidVtTXnAf8GK5AqKzB8L8qgnWoVfZbS0U6uQuc8fJwnTdk0uSc6HOIgbJIiJlifElq2r44soxP+OglK613fGGAmvp2pJD/UKVW/lOFOi6lrqMM1bAv4ST4mMi7MRhjfddFjWBItdWFPnW6KOvy505jjMyeYtGLTZBn1EgXxk6dB6lEjqOG8RaiDEvqxOTqOWL7V/Aj0zWiUx9hQxdxQq2dpnCXvihPP7sVkpNTlP5LQoej2kapV0jlKPC64yx5y5M0Br2HWsdemigMOJ6u30sEV096rAgDKeAZGcur+TK+mmC/+OzFnCOa3wrPEGTe0arlf6vd3A4qLrfiEUBBROOf6u5p8eCpc4ZNFPY1HjF9MmzbWZU17H+c/A9mixNR0uGZr9zRr5CJuG0Z2U3Q7G36WVROjO3nymQ5Yk8XaeaLxd3DNdFRda+/CfUbGdq8E2HvZ3y/YXpy9YCxa1da3LdoRbdeAWWVlqLhn172jyxRKhlw2++p9rmwRJ/SiN2DpW82T5blnWdwxbZwMhiQ9fj8pojf9FqbNtUm0AciRFkmMFy7F8s+IqkuZu2H3P6yAHa3cCFXdnav/6I22kbr/eLzNhMsgf95C5GNBTGbCb1iKQDHFEA8dZ92QH778p1PMJ8U71gScnVbGecm1NtfQwo4dwamU8HZgLbrsvP4D0gbBLyiqG1WIaM3BofD6cSS7u4FwYtMteWEdgT/Sh9uRS8FEvho2OpAsr1roYxtTJoEXKvp73UZWgqlOhJujKobKlkmyQiKVWasGdOLxCBgv8Wa8v0i1ADX7UiYzHmdUV4ZKA2F5bTNOQLyTEgg6LRh1luZ6xoeho8KXFFA4cgYqyrM4a5siOE9kObr3EneLRUCkdeAwN30cXHKbLLZq0um7VDTahSWaq+M935fh3/qz1pCryUlzdbu9Q037egkMKSDd2fpvjoyEgZadYDrs1N60f+kFsyG7DJdZVcOj7qzmatv9gFQRb5hGDY1sa2U4nLAIDHzbpW1xDqluW8axhIKVu+WLAz/7OSZBqrEeu3FTMH9C9LSpM5ZENkmIya/dP0qfRRwgF5tLeRJdkIK5jr0jECApVkshvPao+IbCdENQrk8ZHLM0TIUCWnZgi4WYfGjMsnU3mf1UTN+YmR2kxXQv8ZTUurxnYKhezLvpTbwdVocIvH/GQ8k71az8Yy58YsOIsSIHYzSVxrJoFznX6dYQDcSbmTB7owTKfdoRP2A7Cf3AI8hXX9JhS9Hc3ssCZ0qUyEmjrCe/0IqMfklPI2eliDkS7N9JGmVSu+cKx6eo5XwUDfDSNSYwtiQk9nhoRvCjgxsm+GaKHYMnC2og9QZXAy/BE1TIf9KU8cgtL/fErywWRWJVJErs3T8AT1DVgQ5ewXL3PtSj9qLG+zFADmnFVUY+XOsemzDgBpy7A13HFnEyN1aquwUkNq2XtpAvbZq/+D1tcqynfapQ+ydM63XXdalS4GfJM0OUyIklVV7IDSt3J0nBc1Lu3g23OvDYWEKcptrR7F6+NI4ZB8D9ATt14NLrt3xWGcjgiLu9eZ+Gn4TqBYt3Y+xrdb25S9Hnn1dAVyDny7BbIVj3Bf5OtiOWdF2uWYBmZ2vQc+0Wbb963jOtYpjRvU83CGQjyGiwzjs9xpNa+xRPnA4wOc5sP06PBVUJa4F7rjfUql2aaDEdOcf/xTxfkHmSRRJc5r3saLd8jouQZ7R61ctAs6iZa6iLd4mnzWhiLh+oTem1Cqvf+RL3tLtKn9bTS19GpM7AYXSn0ekQmx+31xrs5aFSs5ogaNjBKfAkQLsZezP2D40X/bupA8QL37AoOPd5tIZeWrr0TRZcfXwUvdZgKq1F8FTuTiEborbGXX/5fJKVHtsozCR1sC9ArRbi6DKI4+pPxZZPGtPuKkPK1rJLy42xRG75z3+LsQIe6HB4FoumHV3EhVP+mVF71nMECVwuT78k9UsFFVpgtJHxfrXtoKPPE9XtPhz2gBYFgliqOqw9pn2g443RU7dDTV1eDQ9Bf58BLWx50R8vl43IGdR1se5KzLL+j7ykEuoUzgyZt9ciZq6pYQ9fSqbhLDF08SGEaMy3bkSHdyCaKolQ1EENdB/srZZWiYJsNic/0nHeIwmf8KrAT5G0QfoCC2kyaaysbcdWeM/2uxNwCgfMmKhD4TteTht6khEM5QfloOIh+QKc/2HH2+lAlV0pxm+a9C19VcIiBnxUTtE1hgR4oAye/IWHzdDkjiJL2D+JZT/PHD9DBR3lgLkZfpYQaGtdA1hXHw0ekfIS/eAH1yq7Tz5qMB1NrYQZEWVi2fwSHMWd3+SIYanwU8fmxd/nnDNHXtzDxeAE8KdEJwleSq4POEQ2RGggxGza6nTKKsYJIB9AHGMXYO9fLgAadzrRU5W5GACzC9XrlzQl1rFFm2JwzPajhvsVtgn9KI5HrANHBsv9xM0+PzlaZJz7vdkYqtyCtoBfu08Azj0Mm8VARHK4q8t6Jx1F4tLSSmbHPI7lgM0NxgxJV/PeMvTtI+dWOoYqTcbNweNboOayySALI73JGeh73vbPV7ZheW0CymNSEkvQ/luh+oYKygk1CL+tX7JqdaLMqVGnKL26PB4GCjIL7KczFTytb1CzhNDQN5tIvGLEystbgwpICz3aJX6XlUTqgVzV25D1g1OPOSWpLbNAjOrs0hiDQvetVCtHj1UfcvE+8T2MZll/5LSkAQcx9b9sX/ZuQMweGL7uGsDqgBfsXuRxgDsLBtU87nOF9VPgrvMflVXJ5HFOQT8qrYk1yyloaDC0QIF5j6ZtfWLo/XLPSQLWTY/PM6RofhrxQmTfVJoHFP6yD8g4lLex9bw5xAw2qOSYwql5cX0ZEtsZ+YuPXclSOV7C8XJ/H6+oUax9tJLkyJHe30N56EzBHajtl4/+rDtO0gGFqUHUeXBjZbBHlQb8qSD8P8dpLgFXjMFjtcSpbbli3WQQp7C4TDAtfD/AD4hdyHm5+NziUwdtDHUwVr5n5ZWPK5Ushtubf3x+RmX6R/VnoGcHQIpn+lU/e3CZrdd2sk8cFyd0/G4xL823fYxxrDCsbdN22G0OHIQHejFtU/2Q3C4m3D42G6wns55Wk33YBbqMEYuTdCAbIuQMQflzkDIFA6/4Ub79I6ODMgzDXi6q4Yyk9GVm5v1cgKjZO1Rl16sVPh2eNC8yiEt2tIysp3r2fcsucUnQIL/bchMTsjaOIZ6A7uKf/wRerjP0q28DrDVkVl0Cvig4+APC7glg+br32anxLPdvBG/8rT72DVAqUVhFL4S08TD0rKg8oTibNy+8eGQPf3rz3UjPyc2w/XZPoLoGDnBtbvWwVqKKN3j8r5KCH95xP06LCiOcRCXir32glEkQN5aMgTXGzvKsa6ANBatmEIfLKF7G5VJp0wsvJb6250yUuJTzQKQacvSXguaxxve4DYHGcpTsKKHk4JnYkTtZqS935mBCanBXX/NGfMAvsJMk8yvoxXfBFgB4cQYYNcOAhXthVaPccAhDGTTfVGohQSMVzX1GqzOrUd2s9r8cihYKNIx1p02J92hfZmCWezIYk/rIt2/gy0KHqELc+Ny95/MYjflB3Zc4+BUfUkcwStQNdzI0Qhbm0SCY5nun3jNyEkcxatTKB94/FxJ39aw7gzc9GTF2sg7mSIvkBzmOok+Q0M0UaLr63SicUibLJIvAnNUjdQQQPJSEsXGO+RYXbw//ClI1pu8ddlWsYW3U6/TCoJjjmNRP2qRoziww/xTBZMdt7hfTymf9vt4TYsCdyaKC7jDg8lNa04aniKK4LLas0+ZfGR56RwlVxaB13bA7UrCxTaJNWYldpqaXZ6UNtp9IqTs46gaz+oWCrpjGzHCUEUCKbIQtq8i1I4dypS/wcpukNqiOfUeESRUzKqz8Vq2wU1mVduEu370rdof9wR94R1qXUojebbM7PToBX474TL+ZD06yd0yKASeaqncYAiUHb5dqGaK/B70T325Upm77uoCuKswLWHXnTcT0mTl20OH0CeTrwFNlwgPxVQWzjJT3IRy7llHbPYdPuVnQtX+A3MtejRT5dv9fWz3iKcY/oK7nwpCqZSSCi/jJBDNUhRxIB5qc4paXCAmEZVsvr3gNVL8mySwcNVgM+/mr7yeRh1t2USwpeYwWDwSPRlCkBte8VofmifQCZARxULGA2Z0sK61i03p7E1Pzj2pVIXLU6KLx20/m3MGOknVj7JlgQlLh/2p/O3ZFIBW7F/8+Et73GNkIes+77/zTAYk+mlZkNDuNTtU/JnV1C2BKMF9sgSvBxWN03EX8XMJZ7tReLaMNhRe9yGrwwfrCCjzZ2EW6baH+mzVjBsqYD01yP8LHSgxlHyBYrjeotS+763FfNWUJ/EfiXO8rezm6eKw/toN1VE4AnVouTTXZEIL2EjjmS3KnBHsj1+FOL2iUT61NbY5agpeIZ90BTzs744ME/MxoOYgX7PxdHYBALy6brf1/XXnwJUkyJAR0dQaIDOvWlP3K4FKyMWKlDm65YyJqT8DHIvly1v0v07Y/MbZS4qxoj7tMgovVXqClcykCc+OMSLharoBFoWJw9ah5xi47UjSPJJJJAWFhrmEI48Z3FKQBBalheUcrwNSBeFnDtuaNCc+YfywQVlPl+MHc4tV4lkiissH6WLT2cnI+0wXcKftA2Fv7Cwkr546l7oFYjZLAxgeY+2J1KcrnTwkpBqqEL5vpgQ2wNNk+ze8EHJictaKzQppNdwAM787uXplb5HCAiAncQ6ajWAt6gxh3OYp2+CoAJ1j+8MoS88tqoOjO8oZEfuy6N5FjKoZkp+vWhG4AAAA=';
'use strict';
(()=> {
const $=id=>document.getElementById(id),cv=$('game'),ctx=cv.getContext('2d'),mm=$('minimap').getContext('2d');
const W=60,H=42,T=32,classes=['Guerreiro','Arqueiro','Mago','Assassino','Tanque','Lanceiro','Samurai','Berserker'],rarity=['Comum','Incomum','Raro','Épico','Lendário'];
let coopCount=1,coopAllies=[];let regionNotice=-1,spawnClock=0,seed=21421,now=0,last=0,acc=0,world=[],enemies=[],loot=[],shots=[],particles=[],npcs=[],chests=[],player=null,gameState='login',modalOpen=false,joy={x:0,y:0},keys={},held={},camera={x:0,y:0},msgUntil=0,autoSave=0,screenShake=0,gameTime=0,killCount=0,bossSpawned=false,playerName='',selectedClass=0;
// Estado global dos reinos: declarado antes de qualquer inicialização do jogo.
let realmIndex=0,realmKills={},realmRewards={},realmQuestStage={},realmStats={};
let dragonDefeated=false,dragonActive=false,introSeen=false,introTimer=null,transitioning=false,dialogueNpc=null,dialogueStep=0;
const portal={x:51.5,y:20.5};let portalPulse=0;
const classicRealms=[
{name:'Vila de Eldoria',floor:'#37634e',detail:'#83a36b',level:1,mobs:['Slime','Orc','Lobo'],stone:'#48505a',race:'Humanos',quest:'Derrote 5 slimes da vila',goal:'Slime',need:5},
{name:'Bosque dos Elfos',floor:'#245d45',detail:'#6aaf75',level:2,mobs:['Lobo','Aranha','Orc'],stone:'#3e6654',race:'Elfos',quest:'Proteja os elfos de 5 aranhas',goal:'Aranha',need:5},
{name:'Caverna dos Cristais',floor:'#343d58',detail:'#7196bf',level:3,mobs:['Morcego','Golem','Fantasma'],stone:'#626e94',race:'Anões',quest:'Expulse 5 morcegos das minas',goal:'Morcego',need:5},
{name:'Deserto Escarlate',floor:'#ad895e',detail:'#ddbb83',level:4,mobs:['Demônio','Golem','Orc'],stone:'#81684e',race:'Nômades',quest:'Derrote 5 demônios das dunas',goal:'Demônio',need:5},
{name:'Montanhas dos Gigantes',floor:'#697b83',detail:'#c2cdd4',level:5,mobs:['Golem','Lobo','Morcego'],stone:'#38434d',race:'Gigantes',quest:'Destrua 5 golems de pedra',goal:'Golem',need:5},
{name:'Tundra Congelada',floor:'#a6cad8',detail:'#e2f6ff',level:6,mobs:['Lobo','Fantasma','Golem'],stone:'#6d98b0',race:'Povo da Neve',quest:'Derrote 5 fantasmas de gelo',goal:'Fantasma',need:5},
{name:'Cidade Antiga',floor:'#94836d',detail:'#d6bc8e',level:7,mobs:['Esqueleto','Fantasma','Aranha'],stone:'#635b54',race:'Espíritos Antigos',quest:'Purifique 5 esqueletos ancestrais',goal:'Esqueleto',need:5},
{name:'Pântano das Sombras',floor:'#405c4b',detail:'#8b9f65',level:8,mobs:['Aranha','Slime','Fantasma'],stone:'#394d45',race:'Homens-Lagarto',quest:'Derrote 5 aranhas do pântano',goal:'Aranha',need:5},
{name:'Terras de Fogo',floor:'#763d35',detail:'#f27a40',level:9,mobs:['Demônio','Golem','Orc'],stone:'#4a3036',race:'Draconianos',quest:'Derrote 5 demônios do vulcão',goal:'Demônio',need:5},
{name:'Trono do Dragão',floor:'#51465e',detail:'#b99bd2',level:10,mobs:['Demônio','Fantasma','Golem'],stone:'#282839',race:'Guardiões Dracônicos',quest:'Derrote o Dragão do Eclipse',goal:'Dragão',need:1}
];
// V16 — equilíbrio por dificuldade, sem alterar o formato dos salvamentos antigos.
const V16_DIFFICULTY={easy:{damage:.62,hp:.78,speed:.84,spawn:.7},normal:{damage:1,hp:1,speed:1,spawn:1},hard:{damage:1.38,hp:1.18,speed:1.12,spawn:1.25},nightmare:{damage:1.7,hp:1.38,speed:1.2,spawn:1.45},impossible:{damage:2.05,hp:1.6,speed:1.3,spawn:1.7}};
function v16Balance(){return V16_DIFFICULTY[settings.difficulty]||V16_DIFFICULTY.normal}
let v16EventClock=0,v16SecretClock=0;
function v16WorldEvents(dt){
 if(dungeonSession||!player)return;
 v16EventClock+=dt;v16SecretClock+=dt;
 if(v16EventClock>75){v16EventClock=0;const count=Math.min(6,2+Math.floor(realmIndex/3));let made=0;
  for(let i=0;i<count;i++){const a=Math.random()*Math.PI*2,r=7+Math.random()*4,x=player.x+Math.cos(a)*r,y=player.y+Math.sin(a)*r;
   if(passable(x,y)){const mob=realmInfo().mobs[Math.floor(Math.random()*realmInfo().mobs.length)];enemies.push(makeEnemy(x,y,mob));made++}}
  if(made){toast('EVENTO: Uma patrulha de monstros surgiu nas proximidades!');effect(player.x,player.y,'#e2a3ff',18)}
 }
 if(v16SecretClock>125){v16SecretClock=0;const a=Math.random()*Math.PI*2,x=player.x+Math.cos(a)*5,y=player.y+Math.sin(a)*5;
  if(passable(x,y)){player.gold+=12+realmIndex*4;effect(x,y,'#f3d39a',20);toast('SEGREDO DESCOBERTO: Ouro antigo! +'+(12+realmIndex*4)+' ouro');save()}}
}
let settings={scale:100,opacity:85,particles:true,shake:true,quality:'high',difficulty:'normal',volume:50,minimap:true,autosave:true};
try{settings={...settings,...JSON.parse(localStorage.getItem('eldoria_reborn_settings')||'{}')}}catch{}
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v)),dist=(a,b)=>Math.hypot(a.x-b.x,a.y-b.y);
function rand(){seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296}
function noise(x,y){let n=Math.imul(x,374761393)+Math.imul(y,668265263);n=Math.imul(n^(n>>>13),1274126177);return ((n^(n>>>16))>>>0)/4294967296}
function toast(t){$('notice').textContent=t;$('notice').classList.add('show');msgUntil=performance.now()+2400}
const gearCatalog={
 sword:{name:'Espada de Bronze',slot:'weapon',cls:'Guerreiro',atk:0,rarity:1,price:0},sword2:{name:'Espada de Aço',slot:'weapon',cls:'Guerreiro',atk:13,rarity:2,price:150},sword3:{name:'Espada do Dragão',slot:'weapon',cls:'Guerreiro',atk:35,rarity:4,price:850},
 bow:{name:'Arco de Carvalho',slot:'weapon',cls:'Arqueiro',atk:0,rarity:1,price:0},bow2:{name:'Arco de Caçador',slot:'weapon',cls:'Arqueiro',atk:12,rarity:2,price:155},bow3:{name:'Arco da Tempestade',slot:'weapon',cls:'Arqueiro',atk:33,rarity:4,price:870},
 staff:{name:'Cajado Arcano',slot:'weapon',cls:'Mago',atk:0,rarity:1,price:0},staff2:{name:'Cajado Rúnico',slot:'weapon',cls:'Mago',atk:15,rarity:2,price:165},staff3:{name:'Cajado Celestial',slot:'weapon',cls:'Mago',atk:38,rarity:4,price:920},
 helmet:{name:'Elmo de Batalha',slot:'helmet',def:4,rarity:2,price:120},helmet2:{name:'Elmo Real',slot:'helmet',def:11,rarity:3,price:420},
 armor:{name:'Armadura Reforçada',slot:'armor',def:7,rarity:2,price:190},armor2:{name:'Armadura Dracônica',slot:'armor',def:21,rarity:4,price:1000},
 shield:{name:'Escudo do Guardião',slot:'shield',def:5,rarity:2,price:145},shield2:{name:'Escudo de Obsidiana',slot:'shield',def:15,rarity:3,price:540},
 ring:{name:'Anel de Poder',slot:'ring',atk:7,rarity:2,price:260},ring2:{name:'Anel Ancestral',slot:'ring',atk:16,def:4,rarity:4,price:740},
 boots:{name:'Botas do Vento',slot:'boots',agility:7,rarity:2,price:230},boots2:{name:'Botas Lendárias',slot:'boots',agility:16,def:3,rarity:4,price:710}
};
function ensureEquipment(){player.equipment=player.equipment||{};player.forgeLevel=player.forgeLevel||0;player.forgeUpgrades=player.forgeUpgrades||{};player.forgeMaterials=player.forgeMaterials||0;player.inventory=player.inventory||[];if(!player.equipment.weapon){const starter=player.cls==='Arqueiro'?'bow':player.cls==='Mago'?'staff':'sword';player.equipment.weapon=player.inventory.some(i=>i.id===player.weapon)?player.weapon:starter}
for(const slot of ['helmet','armor','shield','ring','boots'])if(!player.equipment[slot]&&player.equipped?.[slot]){player.equipment[slot]=slot;/* equipamento antigo convertido sem alterar defesa-base */}
}
function gearStats(){if(!player)return {atk:0,def:0,agility:0};ensureEquipment();let stats={atk:player.forgeLevel*2,def:0,agility:0};for(const id of Object.values(player.equipment)){const g=gearCatalog[id];if(!g)continue;stats.atk+=(g.atk||0)+((player.forgeUpgrades?.[g.slot]||0)*(g.slot==='weapon'?2:g.slot==='ring'?1:0));stats.def+=(g.def||0)+((player.forgeUpgrades?.[g.slot]||0)*(['helmet','armor','shield','boots'].includes(g.slot)?2:0));stats.agility+=(g.agility||0)+((player.forgeUpgrades?.[g.slot]||0)*(g.slot==='boots'?1:0))}return stats}
function equipGear(id){const g=gearCatalog[id],item=player.inventory.find(i=>i.id===id&&i.count>0);if(!g||!item)return;if(g.cls&&g.cls!==player.cls&&!(g.cls==='Guerreiro'&&['Assassino','Tanque','Lanceiro','Samurai','Berserker'].includes(player.cls))){toast('Equipamento exclusivo para '+g.cls);return}ensureEquipment();player.equipment[g.slot]=id;if(g.slot==='weapon')player.weapon=id;toast(g.name+' equipado!');save();openModal('inventory')}
function forgeCost(){ensureEquipment();return Math.floor(65*Math.pow(1.5,player.forgeLevel))}
const FORGE_SLOTS={weapon:'Arma',helmet:'Elmo',armor:'Armadura',shield:'Escudo',ring:'Anel',boots:'Botas'};
function forgeSlotLevel(slot){ensureEquipment();return Math.max(0,player.forgeUpgrades[slot]||0)}
function forgeSlotCost(slot){const lv=forgeSlotLevel(slot);return Math.round((slot==='weapon'?85:slot==='armor'?90:65)*(1+lv*.46+lv*lv*.12)*(1+Math.min(realmIndex,9)*.06))}
function forgeSlotMaterials(slot){return Math.floor((forgeSlotLevel(slot)+1)/3)}
function forgeUpgrade(slot){ensureEquipment();if(!FORGE_SLOTS[slot])return;if(!player.equipment[slot]||!gearCatalog[player.equipment[slot]]){toast('Equipe um item neste espaço primeiro!');return}const lv=forgeSlotLevel(slot);if(lv>=15){toast('Equipamento no nível máximo de forja!');return}const gold=forgeSlotCost(slot),ore=forgeSlotMaterials(slot);if(player.gold<gold||player.forgeMaterials<ore){toast('Faltam ouro ou fragmentos de forja!');return}player.gold-=gold;player.forgeMaterials-=ore;player.forgeUpgrades[slot]=lv+1;toast(FORGE_SLOTS[slot]+' aprimorado para +'+(lv+1)+'!');save();openModal('smith')}
function forgeDismantle(id){ensureEquipment();const g=gearCatalog[id],item=player.inventory.find(i=>i.id===id);if(!g||!item||item.count<1)return;const worn=player.equipment[g.slot]===id;if(worn&&item.count<=1){toast('Não é possível desmontar seu último item equipado!');return}item.count--;if(item.count<=0)player.inventory=player.inventory.filter(i=>i!==item);const mats=Math.max(1,g.rarity-1),gold=Math.round(g.price*.12);player.forgeMaterials+=mats;player.gold+=gold;toast('Desmontado: +'+mats+' fragmentos e +'+gold+' ouro');save();openModal('smith')}
function purchase(id){const g=gearCatalog[id];const consumables={potion:{name:'Poção de Vida',price:20},ether:{name:'Poção de Mana',price:22},elixir:{name:'Elixir Maior',price:95},tonic:{name:'Tônico de Energia',price:40}};const product=g||consumables[id];if(!product)return;const price=product.price;if(player.gold<price){toast('Faltam '+(price-player.gold)+' moedas!');return}player.gold-=price;addItem({id,name:product.name,count:1,rarity:g?g.rarity:0});toast('Comprou '+product.name+'!');save();openModal('shop')}
function gearDrop(enemy){if(enemy.type==='Slime'||Math.random()>(enemy.elite?.68:.12))return;let pool=Object.keys(gearCatalog).filter(id=>gearCatalog[id].price>0&&(!gearCatalog[id].cls||gearCatalog[id].cls===player.cls||(gearCatalog[id].cls==='Guerreiro'&&['Assassino','Tanque','Lanceiro','Samurai','Berserker'].includes(player.cls))));pool=pool.filter(id=>gearCatalog[id].rarity<=Math.min(4,2+Math.floor(realmIndex/3)+(enemy.elite?1:0)));if(!pool.length)return;const id=pool[Math.floor(Math.random()*pool.length)],g=gearCatalog[id];addItem({id,name:g.name,count:1,rarity:g.rarity});toast('Drop de equipamento: '+g.name+'!')}
function itemIcon(id){if(id.includes('sword'))return '⚔';if(id.includes('bow'))return '🏹';if(id.includes('staff'))return '✦';if(id.includes('shield'))return '🛡';if(id.includes('armor'))return '🥋';if(id.includes('helmet'))return '⛑';if(id.includes('ring'))return '💍';if(id.includes('boots'))return '🥾';return id==='potion'?'🧪':'💠'}

// Eldoria 20.0: expansão modular; salva tudo em adventure.expansion.
function expansion(){if(!adventure.expansion||typeof adventure.expansion!=='object')adventure.expansion={};const e=adventure.expansion;e.daily=e.daily||{day:'',kills:0,claimed:false};e.weekly=e.weekly||{week:'',kills:0,claimed:false};e.titles=e.titles||{};e.chests=e.chests||{};e.enchants=e.enchants||{};e.specializations=e.specializations||{};e.bossPhases=e.bossPhases||0;e.combo=e.combo||0;e.comboClock=e.comboClock||0;e.eventClock=e.eventClock||0;e.petPowerCD=e.petPowerCD||0;return e}
function expansionReset(){const e=expansion(),day=new Date().toISOString().slice(0,10),week=Math.floor(Date.now()/604800000).toString();if(e.daily.day!==day)e.daily={day,kills:0,claimed:false};if(e.weekly.week!==week)e.weekly={week,kills:0,claimed:false}}
const ELD_ENCHANTS={fire:{name:'Fogo',color:'#ff8b52'},ice:{name:'Gelo',color:'#8be4ff'},poison:{name:'Veneno',color:'#a7ef80'},storm:{name:'Relâmpago',color:'#e2c4ff'}};
function enchantWeapon(kind){if(!ELD_ENCHANTS[kind])return;const e=expansion(),cost=180+realmIndex*60;if(player.gold<cost||player.forgeMaterials<2){toast('Encantamento exige '+cost+' ouro e 2 fragmentos.');return}player.gold-=cost;player.forgeMaterials-=2;e.enchants.weapon=kind;save();openModal('expansionForge');toast('Arma encantada: '+ELD_ENCHANTS[kind].name)}
function expansionAttack(enemy){const e=expansion();if(e.enchants.weapon&&Math.random()<.22){const kind=e.enchants.weapon;enemy.hp-=Math.max(1,Math.round((player.level+realmIndex*3)*.5));effect(enemy.x,enemy.y,ELD_ENCHANTS[kind].color,7);if(kind==='ice')enemy.recovery=Math.max(enemy.recovery||0,.45)}e.combo=Math.min(20,(e.combo||0)+1);e.comboClock=3.2;if(e.combo===10)toast('COMBO 10! Continue atacando!')}
function expansionKill(enemy){const e=expansion();expansionReset();e.daily.kills++;e.weekly.kills++;if(enemy.elite){e.titles.guardian=true;e.bossPhases++;}if(enemy.type==='Dragão')e.titles.dragon=true;if(Math.random()<(enemy.elite?.23:.045)){const id='treasure'+realmIndex;addItem({id,name:'Baú misterioso do reino '+(realmIndex+1),count:1,rarity:enemy.elite?4:2});toast('Você encontrou um baú misterioso!')}if(e.combo>=5){const extra=Math.min(30,e.combo)*2+realmIndex*2;player.xp+=extra;}if((e.daily.kills%10)===0)save()}
function expansionClaim(which){const e=expansion();expansionReset();const q=e[which],need=which==='daily'?15:80;if(q.claimed||q.kills<need)return;const gold=which==='daily'?120+realmIndex*30:600+realmIndex*80,xp=which==='daily'?160+realmIndex*90:850+realmIndex*160;player.gold+=gold;player.xp+=xp;q.claimed=true;toast('Recompensa: +'+gold+' ouro e +'+xp+' XP!');save();openModal('expansionQuests')}
function expansionChest(){const id='treasure'+realmIndex,item=player.inventory.find(i=>i.id===id&&i.count>0);if(!item){toast('Você não possui um baú deste reino.');return}item.count--;if(item.count===0)player.inventory=player.inventory.filter(i=>i!==item);const gold=70+realmIndex*45;player.gold+=gold;player.forgeMaterials+=1+Math.floor(realmIndex/3);if(Math.random()<.4){const pool=Object.entries(gearCatalog).filter(([k,g])=>g.price>0&&(!g.cls||g.cls===player.cls||(g.cls==='Guerreiro'&&['Assassino','Tanque','Lanceiro','Samurai','Berserker'].includes(player.cls))));if(pool.length){const [id,g]=pool[Math.floor(Math.random()*pool.length)];addItem({id,name:g.name,count:1,rarity:g.rarity})}}toast('Baú aberto! Ouro, fragmentos e possível equipamento.');save();openModal('inventory')}
function expansionSpecialize(){const e=expansion();if(player.level<30){toast('Especialização desbloqueada no nível 30.');return}if(e.specializations[player.cls])return;e.specializations[player.cls]=true;player.atk+=12;player.def+=6;player.maxHp+=50;player.hp+=50;toast('Especialização de '+player.cls+' desbloqueada!');save();openModal('expansionProgress')}
function expansionSell(id){const item=player.inventory.find(i=>i.id===id&&i.count>0),g=gearCatalog[id];if(!item||!g||g.price<=0)return;if(player.equipment?.[g.slot]===id&&item.count<=1){toast('Não venda o último item equipado.');return}item.count--;if(!item.count)player.inventory=player.inventory.filter(i=>i!==item);const amount=Math.round(g.price*.35);player.gold+=amount;toast('Equipamento vendido: +'+amount+' ouro');save();openModal('expansionMarket')}
function expansionPetPower(){const e=expansion();if(e.petPowerCD>0){toast('Habilidade do pet recarregando!');return}const pet=adventure.companion;if(!pet||pet==='none'){toast('Equipe um companheiro primeiro.');return}e.petPowerCD=25;const t=target();if(/Fada|Fênix/.test(pet)){player.hp=Math.min(player.maxHp,player.hp+Math.round(player.maxHp*.15));toast('Pet: cura especial!')}else if(/Golem/.test(pet)){adventure.petGuard=(adventure.petGuard||0)+Math.round(player.maxHp*.14);adventure.petGuardTime=5;toast('Pet: barreira especial!')}else if(/Coruja|Raposa/.test(pet)){player.mp=Math.min(player.maxMp,player.mp+Math.round(player.maxMp*.2));toast('Pet: mana restaurada!')}else if(t){damage(t,Math.round(25+player.level*1.5));toast('Pet: ataque especial!')}else toast('Pet preparado para a próxima batalha!');save()}
function expansionTick(dt){const e=expansion();e.comboClock=Math.max(0,e.comboClock-dt);if(!e.comboClock)e.combo=0;e.petPowerCD=Math.max(0,e.petPowerCD-dt);e.eventClock+=dt;if(e.eventClock>105&&!dungeonSession){e.eventClock=0;if(Math.random()<.5){const a=Math.random()*Math.PI*2,x=player.x+Math.cos(a)*5,y=player.y+Math.sin(a)*5;if(passable(x,y)){enemies.push(makeEnemy(x,y,realmInfo().mobs[Math.floor(Math.random()*3)]));toast('EVENTO: criatura errante!')}}else{player.gold+=25+realmIndex*8;toast('EVENTO: tesouro de viajante!')}}}

function save(){if(!player)return;try{localStorage.setItem('eldoria_reborn_save',JSON.stringify({player:dungeonSession?{...player,x:dungeonSession.x,y:dungeonSession.y}:player,realmIndex,realmKills,realmRewards,realmQuestStage,realmStats,dragonDefeated,adventure,gameTime,killCount,bossSpawned,chests:chests.map(c=>c.open)}))}catch{}}
function load(){try{return JSON.parse(localStorage.getItem('eldoria_reborn_save')||'null')}catch{return null}}
function settingsSave(){try{localStorage.setItem('eldoria_reborn_settings',JSON.stringify(settings))}catch{};applySettings()}
function applySettings(){document.documentElement.style.setProperty('--uiScale',settings.scale/100);$('joy').style.transform=`scale(${settings.scale/100})`;$('joy').style.transformOrigin='bottom left';$('buttons').style.transform=`scale(${settings.scale/100})`;$('buttons').style.transformOrigin='bottom right';$('controls').style.opacity=settings.opacity/100;$('minimap').style.display=settings.minimap?'':'none'}
function page(html){document.body.classList.remove('eldoria-playing','eldoria-rotation-dismissed');$('page').innerHTML=html;$('overlay').classList.remove('hidden')}
function loginPage(){gameState='login';page(`<div style="font-size:48px">✦</div><h1>CRÔNICAS DE ELDORIA</h1><p>Um novo mundo espera por você.</p><input id="nameInput" maxlength="18" placeholder="Nome do aventureiro" value="${playerName.replace(/[<>"']/g,'')}"><button id="loginRotateBtn" type="button" class="loginRotateBtn rotateMagic"><span class="rotateMagicIcon" aria-hidden="true"><span class="rotateMagicPhone"></span><span class="rotateMagicArrow">↻</span></span><span class="rotateMagicWords"><strong id="rotateBtnTitle">GIRAR A TELA</strong><small id="rotateBtnCaption">Toque para jogar na horizontal</small></span><span class="rotateMagicSpark" aria-hidden="true">✦</span></button><button class="primary" id="loginBtn" style="width:100%">ENTRAR NO REINO</button><p class="small">Jogo local · Seu progresso fica salvo neste navegador</p>`);$('loginRotateBtn').onclick=async()=>{await requestEldoriaLandscape();if(matchMedia('(orientation:portrait)').matches){const hint=document.querySelector('#orientationDetail');if(hint)hint.textContent='Se não girar, libere a rotação automática nas configurações do celular.'}updateLoginOrientation()};updateLoginOrientation();$('loginBtn').onclick=()=>{playerName=$('nameInput').value.trim().slice(0,18)||'Aventureiro';menuPage()};}
function menuPage(){gameState='menu';document.body.classList.remove('eldoria-playing');const saved=load();page(`<div style="font-size:36px;color:#d8b97d">✧ ⚔ ✧</div><h1>ELDORIA</h1><p>O chamado dos reinos esquecidos</p><div class="menuGrid"><button class="primary" id="continueBtn" ${saved?'':'disabled'}>▶ CONTINUAR</button><button id="newBtn">✦ NOVA AVENTURA</button><button id="menuSettings">⚙ CONFIGURAÇÕES</button><button id="helpBtn">✧ SOBRE ELDORIA</button></div><p class="small">Exploração · Classes · Inventário · Missões · Chefões</p>`);$('continueBtn').onclick=()=>enterAdventure(true);$('newBtn').onclick=classPage;$('menuSettings').onclick=()=>openModal('settings');$('helpBtn').onclick=()=>openModal('help')}
function classPage(){
 gameState='class';coopCount=1;coopAllies=[];
 page(`<h2>ESCOLHA SUA CLASSE</h2><p>Uma aventura para um jogador.</p><div class="classGrid">${classes.map((c,i)=>`<div class="classCard ${i===selectedClass?'selected':''}" data-class="${i}"><div style="font-size:31px">${['⚔','🏹','✦','🗡','🛡','🔱','⚔','🪓'][i]}</div><b>${c}</b><span class="small">${['Espada · Defesa','Arco · Precisão','Cajado · Magia','Adagas · Velocidade','Escudo · Resistência','Lança · Alcance','Katana · Técnica','Machado · Fúria'][i]}</span></div>`).join('')}</div><div class="classActions"><button id="classBack">VOLTAR</button><button class="primary" id="classGo">COMEÇAR AVENTURA</button></div>`);
 document.querySelectorAll('[data-class]').forEach(el=>el.onclick=()=>{selectedClass=+el.dataset.class;classPage()});
 $('classBack').onclick=menuPage;
 $('classGo').onclick=()=>enterAdventure(false);
}

function summonDragonIntro(){if(introSeen||dragonDefeated||realmIndex!==9)return;introSeen=true;gameState='cutscene';const el=$('dragonIntro');el.classList.remove('show');void el.offsetWidth;el.classList.add('show');introTimer=setTimeout(()=>{el.classList.remove('show');if(gameState==='cutscene')gameState='playing';toast('DRAGÃO DO ECLIPSE — a batalha começou!')},5100)}
// Sistemas de aventura adicionais; estado persistido com o salvamento antigo.
let adventure={talents:{},points:0,companion:'none',companionCD:0,achievements:{},dungeons:{},weather:0,weatherClock:0,questChoice:{},sound:true};
const talents={
Guerreiro:[{id:'guard',name:'Muralha de Ferro',desc:'Reduz o dano recebido em 15%',max:3},{id:'cleave',name:'Lâmina Giratória',desc:'Aumenta o alcance e dano do poder',max:3},{id:'rage',name:'Fúria de Batalha',desc:'Ataques causam mais dano',max:3}],
Arqueiro:[{id:'pierce',name:'Flechas Precisas',desc:'Aumenta o dano das flechas',max:3},{id:'rapid',name:'Chuva de Flechas',desc:'Mais projéteis na habilidade',max:3},{id:'swift',name:'Passos Leves',desc:'Movimento mais rápido',max:3}],
Mago:[{id:'arcane',name:'Poder Arcano',desc:'Aumenta o dano mágico',max:3},{id:'nova',name:'Nova Elemental',desc:'Mais dano na explosão arcana',max:3},{id:'mana',name:'Fonte Mística',desc:'Regeneração maior de mana',max:3}]};
for(const [cls,names] of Object.entries({Assassino:['Golpe Sombrio','Passos Silenciosos','Veneno Mortal'],Tanque:['Fortaleza','Pele de Ferro','Provocação'],Lanceiro:['Alcance Estendido','Estocada','Guarda de Lança'],Samurai:['Corte Relâmpago','Disciplina','Contra-ataque'],Berserker:['Fúria Crescente','Machado Pesado','Resistência Selvagem']})){talents[cls]=names.map((name,i)=>({id:({Assassino:['shadow','silent','poison'],Tanque:['fortress','iron','taunt'],Lanceiro:['reach','thrust','spearGuard'],Samurai:['lightning','discipline','counter'],Berserker:['frenzy','heavy','savage']})[cls][i],name,desc:['Melhora dano e alcance de ataques','Aprimora mobilidade ou defesa','Fortalece a técnica especial'][i],max:5}))}
function talentLevel(id){return adventure.talents[id]||0}
function talentAttackBonus(){const c=player?.cls;return 1+(.07*talentLevel(({Assassino:'shadow',Tanque:'fortress',Lanceiro:'thrust',Samurai:'lightning',Berserker:'heavy'})[c]))}
function talentSkillBonus(){const c=player?.cls;return 1+(.13*talentLevel(({Assassino:'poison',Tanque:'taunt',Lanceiro:'reach',Samurai:'counter',Berserker:'frenzy'})[c]))}
function talentDefenseBonus(){const c=player?.cls;return 1+(.065*talentLevel(({Assassino:'silent',Tanque:'iron',Lanceiro:'spearGuard',Samurai:'discipline',Berserker:'savage'})[c]))}
function receiveHit(raw){if(!player||gameState!=='playing'||player.invuln>0)return false;const cs=player.combatStats||{};if(Math.random()<(cs.evade||0)*.02){effect(player.x,player.y,'#9feaff',7);toast('ESQUIVOU!');player.invuln=.2;return false}const blocked=Math.random()<(cs.block||0)*.03;const armor=Math.max(0,player.def+gearStats().def);const realmDanger=1+realmIndex*.24;const mitigated=Math.max(raw*.52,raw/(1+armor/85));const dmg=Math.max(2,Math.round(mitigated/talentDefenseBonus()*v16Balance().damage*realmDanger*(blocked?.5:1)));let actualDmg=dmg;if((adventure.petGuardTime||0)>0&&(adventure.petGuard||0)>0){const absorbed=Math.min(actualDmg,adventure.petGuard);actualDmg-=absorbed;adventure.petGuard-=absorbed;}if(blocked)toast('BLOQUEIO!');player.hp=Math.max(0,player.hp-actualDmg);player.hit=.42;player.invuln=.32;player.damageFlash=.42;effect(player.x,player.y,'#ff4343',16);soundFx('hit');if(actualDmg>=18)toast('−'+actualDmg+' HP');if(settings.shake)screenShake=.13;if(player.hp<=0){player.gold=Math.max(0,player.gold-Math.max(20,Math.ceil(player.gold*.07)));player.hp=player.maxHp;player.mp=Math.round(player.maxMp*.4);player.x=dungeonSession?3.5:8.5;player.y=dungeonSession?3.5:8.5;player.invuln=2;toast('Você foi derrotado! Voltou ao ponto seguro com HP completo e perdeu parte do ouro.');save()}return true}

function achieve(id,label){if(adventure.achievements[id])return;adventure.achievements[id]=true;const el=$('achievementPop');el.textContent='★ CONQUISTA: '+label;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),3500);if(player){player.gold+=50;save()}}
function soundFx(kind){if(!adventure.sound||!settings.volume)return;try{const Audio=window.AudioContext||window.webkitAudioContext;if(!Audio)return;const ac=soundFx.ctx||(soundFx.ctx=new Audio());if(ac.state==='suspended')ac.resume().catch(()=>{});const osc=ac.createOscillator(),gain=ac.createGain(),t=ac.currentTime;osc.type=kind==='hit'?'triangle':'sine';osc.frequency.setValueAtTime(kind==='portal'?460:kind==='win'?650:kind==='hit'?130:340,t);osc.frequency.exponentialRampToValueAtTime(kind==='portal'?900:kind==='win'?950:kind==='hit'?65:200,t+.14);gain.gain.setValueAtTime(.045*(settings.volume/100),t);gain.gain.exponentialRampToValueAtTime(.001,t+.17);osc.connect(gain).connect(ac.destination);osc.start(t);osc.stop(t+.18)}catch{}}
function questFlavor(){const r=realmInfo();return ['O povo de '+r.race+' precisa da sua ajuda.','Explore o terreno e procure caminhos secretos.','Investigue os rumores de criaturas incomuns.','Proteja os habitantes e retorne ao mentor.'][realmIndex%4]}
let dungeonSession=null;
const dungeonTitles=['Cripta dos Sinos','Labirinto das Raízes','Salões de Cristal','Tumba das Dunas','Fortaleza dos Colossos','Templo do Gelo','Biblioteca Perdida','Santuário Submerso','Coração do Vulcão','Abismo do Eclipse'];
function dungeonReady(){return player&&Math.hypot(player.x-26.5,player.y-32.5)<2.5}
function dungeonTransition(message,callback){const el=$('portalTransition');if(el){el.classList.add('show');el.querySelector('h2').textContent=message;el.querySelector('p').textContent='As runas despertam... atravessando o portal';}gameState='transition';soundFx('portal');setTimeout(()=>{callback();if(el)el.classList.remove('show');gameState='playing';},1350)}
function dungeonMaze(){const grid=Array.from({length:H},()=>Array(W).fill(2));let x=3,y=3;grid[y][x]=0;let stack=[[x,y]],rng=991+realmIndex*331;const random=()=>{rng=(rng*1664525+1013904223)>>>0;return rng/4294967296};while(stack.length){const [cx,cy]=stack[stack.length-1];const dirs=[[2,0],[-2,0],[0,2],[0,-2]].sort(()=>random()-.5);let options=dirs.filter(([dx,dy])=>{let nx=cx+dx,ny=cy+dy;return nx>1&&ny>1&&nx<W-2&&ny<H-2&&grid[ny][nx]===2});if(options.length){const [dx,dy]=options[0];grid[cy+dy/2][cx+dx/2]=0;grid[cy+dy][cx+dx]=0;stack.push([cx+dx,cy+dy])}else stack.pop()}
const carve=(cx,cy,r=2)=>{for(let yy=cy-r;yy<=cy+r;yy++)for(let xx=cx-r;xx<=cx+r;xx++)if(xx>0&&yy>0&&xx<W-1&&yy<H-1)grid[yy][xx]=0};
carve(3,3,2);carve(W-6,H-6,4);
for(let i=0;i<12;i++){let xx=5+Math.floor(random()*(W-10)),yy=5+Math.floor(random()*(H-10));if(grid[yy][xx]===0)carve(xx,yy,1)}
return grid}
function dungeonSwitches(){const candidates=[];for(let y=6;y<H-7;y++)for(let x=6;x<W-7;x++)if(world[y][x]===0&&Math.hypot(x-3,y-3)>12&&Math.hypot(x-(W-6),y-(H-6))>7)candidates.push({x:x+.5,y:y+.5,lit:false});const picks=[];for(const index of [Math.floor(candidates.length*.15),Math.floor(candidates.length*.52),Math.floor(candidates.length*.86)])if(candidates[index])picks.push(candidates[index]);return picks}
function enterDungeon(){if(!player||gameState!=='playing')return;if(dungeonSession){toast('Você já está dentro da masmorra.');return}if(!dungeonReady()){toast('Encontre a entrada da masmorra ao sul (X:26, Y:32).');return}if(adventure.dungeons[realmIndex]){toast('Esta masmorra já foi concluída!');return}closeModal();dungeonTransition(dungeonTitles[realmIndex],()=>{dungeonSession={world,enemies,npcs,chests,loot,shots,particles,x:player.x,y:player.y,realm:realmIndex,switches:[],bossAwake:false,completed:false};world=dungeonMaze();enemies=[];npcs=[];chests=[];loot=[];shots=[];particles=[];player.x=3.5;player.y=3.5;player.invuln=2;dungeonSession.switches=dungeonSwitches();adventure.dungeonActive=realmIndex;adventure.dungeonRemaining=1;toast('Encontre os 3 selos rúnicos e desperte o guardião!');updateHUD()})}
function activateDungeonSwitch(){if(!dungeonSession)return false;const sw=dungeonSession.switches.find(q=>!q.lit&&dist(player,q)<1.7);if(sw){sw.lit=true;effect(sw.x,sw.y,'#b5faff',22);soundFx('win');let n=dungeonSession.switches.filter(q=>q.lit).length;toast('Selo ativado: '+n+'/'+dungeonSession.switches.length);if(n===dungeonSession.switches.length){let boss=makeEnemy(W-6.5,H-6.5,realmIndex===9?'Dragão':'Titã');boss.dungeon=true;boss.hp=Math.round((8500+realmIndex*1900)*v16Balance().hp);boss.maxHp=boss.hp;boss.speed*=1.12;boss.specialTimer=2;enemies.push(boss);dungeonSession.bossAwake=true;toast('O GUARDIÃO DO LABIRINTO DESPERTOU!')}return true}return false}
function exitDungeon(){if(!dungeonSession)return;const ds=dungeonSession;dungeonSession=null;world=ds.world;enemies=ds.enemies;npcs=ds.npcs;chests=ds.chests;loot=ds.loot;shots=ds.shots;particles=ds.particles;player.x=ds.x;player.y=ds.y;player.invuln=2;adventure.dungeonActive=-1;adventure.dungeonRemaining=0;save();toast(ds.completed?'Masmorra concluída! Tesouros obtidos.':'Você retornou ao reino.');updateHUD()}
function dungeonInteract(){if(!dungeonSession||gameState!=='playing')return false;if(activateDungeonSwitch())return true;if(dist(player,{x:3.5,y:3.5})<3.2){if(dungeonSession.completed)toast('Guardião derrotado! Voltando ao reino com as recompensas.');dungeonTransition('Portal de Retorno',exitDungeon);return true}if(!dungeonSession.bossAwake){toast('Ative os três selos. O portal azul no início permite sair quando quiser.');return true}toast('Portal azul: volte ao início da masmorra para retornar ao reino.');return true}
const PET_RANKS=[
 {name:'Dragão Imperador',rank:1,price:620,mult:1.7,color:'#c99aff',icon:'♛'},
 {name:'Fênix Jovem',rank:2,price:510,mult:1.5,color:'#ffae65',icon:'✹'},
 {name:'Tigre de Gelo',rank:3,price:420,mult:1.4,color:'#9ce9ff',icon:'❄'},
 {name:'Golem Miniatura',rank:4,price:340,mult:1.3,color:'#a8d1c6',icon:'⬟'},
 {name:'Lobo Guardião',rank:5,price:270,mult:1.22,color:'#a7b9c9',icon:'◆'},
 {name:'Raposa Mística',rank:6,price:210,mult:1.14,color:'#ec9d62',icon:'✧'},
 {name:'Coruja Lunar',rank:7,price:160,mult:1.07,color:'#b4a8e6',icon:'☾'},
 {name:'Fada da Luz',rank:8,price:120,mult:1,color:'#f1d78c',icon:'✦'}
];
const PET_ROLES={
 'Lobo Guardião':{role:'dano',damage:1.2,cooldown:1.8,color:'#cbdbe9',desc:'Dano constante • ataques rápidos'},
 'Dragão Imperador':{role:'dano',damage:1.65,cooldown:3.2,color:'#ff9a5b',desc:'Dano explosivo • ataques lentos'},
 'Fada da Luz':{role:'cura',damage:0,cooldown:3.2,color:'#ffeb9c',desc:'Cura dedicada • não ataca'},
 'Fênix Jovem':{role:'cura',damage:.55,cooldown:3.3,color:'#ffbe62',desc:'Cura leve e dano moderado'},
 'Golem Miniatura':{role:'defesa',damage:.25,cooldown:5,color:'#bdc4ca',desc:'Escudo temporário • pouco dano'},
 'Coruja Lunar':{role:'mana',damage:0,cooldown:3.1,color:'#d9f4ff',desc:'Recuperação de mana • não ataca'},
 'Raposa Mística':{role:'hibrido',damage:.72,cooldown:2.4,color:'#bd8aff',desc:'Dano e recuperação leve de mana'},
 'Tigre de Gelo':{role:'controle',damage:.7,cooldown:2.6,color:'#9de8ff',desc:'Atrasa ataques inimigos • dano moderado'}
};
function petInfo(name){return PET_RANKS.find(p=>p.name===name)||PET_RANKS[7]}
function petForm(level){return level>=16?'Lendário':level>=12?'Adulto':level>=8?'Adolescente':level>=4?'Filhote':'Recém-nascido'}
function migratePets(){if(!adventure)return; if(adventure.companion==='Draconete')adventure.companion='Dragão Imperador';for(const key of ['ownedPets','petProgress']){if(adventure[key]?.Draconete){adventure[key]['Dragão Imperador']=adventure[key]['Dragão Imperador']||adventure[key].Draconete;delete adventure[key].Draconete}}}
function petProgress(){migratePets();if(!adventure.petProgress)adventure.petProgress={};let name=adventure.companion;if(name==='none')return null;if(!adventure.petProgress[name])adventure.petProgress[name]={level:1,xp:0};return adventure.petProgress[name]}
function petNeed(level){return Math.round(10+level*6+Math.pow(level,1.5)*2)}
function petStage(level){return level>=16?4:level>=12?3:level>=8?2:level>=4?1:0}
function petGain(amount){const pet=petProgress();if(!pet||pet.level>=16)return;pet.xp+=amount;while(pet.level<16&&pet.xp>=petNeed(pet.level)){pet.xp-=petNeed(pet.level);pet.level++;if([4,8,12,16].includes(pet.level)){toast(adventure.companion+' evoluiu: '+petForm(pet.level)+'!');effect(player.x,player.y,petInfo(adventure.companion).color,36);soundFx('win')}else toast(adventure.companion+' chegou ao nível '+pet.level)}if(pet.level===16)pet.xp=0}
function choosePet(name){if(!player)return;migratePets();if(!PET_RANKS.some(p=>p.name===name))return;if(adventure.companion===name){toast('Esse pet já está acompanhando você!');return}if(!adventure.ownedPets)adventure.ownedPets={};const cost=petInfo(name).price;if(!adventure.ownedPets[name]){if(player.gold<cost){toast('Você precisa de '+cost+' moedas para adotar esse pet.');return}player.gold-=cost;adventure.ownedPets[name]=true}adventure.companion=name;petProgress();toast(name+' entrou para sua equipe!');achieve('friend','Primeiro companheiro');save()}
function recruitCompanion(){if(adventure.companion!=='none'){adventure.companion='none';toast('Companheiro descansando. A evolução foi preservada.');save()}}
function weatherName(){return ['Céu limpo','Chuva','Neblina','Neve','Cinzas'][adventure.weather]}
function weatherForRealm(){return realmIndex===5?3:realmIndex===8?4:realmIndex===7?2:realmIndex===3?0:(Math.floor(gameTime/90)+realmIndex)%3}
function realmInfo(){return classicRealms[realmIndex]}
function portalNear(){return !dungeonSession&&player&&Math.hypot(player.x-portal.x,player.y-portal.y)<2.8}
function travelPortal(){if(!portalNear())return false;
if(transitioning)return true;
if(realmIndex===classicRealms.length-1){toast('Este é o último reino. Encontre e derrote o Dragão do Eclipse!');return true}
if(!realmRewards[realmIndex]){toast('Portal selado. Ele será ativado quando as missões do reino estiverem concluídas.');return true}
const next=realmIndex+1;effect(player.x,player.y,'#a4a5ff',18);soundFx('portal');transitioning=true;gameState='transition';
const overlay=$('realmLoading');overlay.classList.add('show');$('loadingTitle').textContent=classicRealms[next].name.toUpperCase();$('loadingSubtitle').textContent='Novo terreno, obstáculos e inimigos · '+classicRealms[next].race+' · Nível '+classicRealms[next].level;
const begun=performance.now(),duration=1750;
function advance(t){let f=Math.min(1,(t-begun)/duration);$('loadProgress').style.width=Math.round(f*100)+'%';$('loadingPercent').textContent=Math.round(f*100)+'%';
if(f<1){requestAnimationFrame(advance);return}
adventure.dungeonActive=-1;realmIndex=next;makeWorld();if(realmIndex===1)achieve('traveler','Primeira travessia');if(realmIndex===5)achieve('halfway','Cinco reinos explorados');soundFx('portal');player.x=8.5;player.y=8.5;player.invuln=1.5;player.hp=Math.min(player.maxHp,player.hp+30);player.mp=player.maxMp;camera.x=player.x*T-innerWidth/2;camera.y=player.y*T-innerHeight/2;regionNotice=-1;dragonActive=false;transitioning=false;gameState='playing';overlay.classList.remove('show');save();toast('Novo reino: '+realmInfo().name);if(realmIndex===9)setTimeout(summonDragonIntro,400)}
requestAnimationFrame(advance);return true}
const backPortal={x:6.5,y:20.5};
function backPortalNear(){return !dungeonSession&&player&&realmIndex>0&&Math.hypot(player.x-backPortal.x,player.y-backPortal.y)<2.2}
function regroupAllies(){}
function returnRealm(){if(!backPortalNear()||transitioning)return false;const previous=realmIndex-1;transitioning=true;gameState='transition';const overlay=$('realmLoading');overlay.classList.add('show');$('loadingTitle').textContent='RETORNANDO AO MAPA '+(previous+1);$('loadingSubtitle').textContent=classicRealms[previous].name;$('loadProgress').style.width='100%';$('loadingPercent').textContent='100%';setTimeout(()=>{realmIndex=previous;makeWorld();player.x=47.5;player.y=20.5;player.invuln=2;regroupAllies();regionNotice=-1;gameState='playing';transitioning=false;overlay.classList.remove('show');save();toast('Mapa '+(realmIndex+1)+' / '+classicRealms.length+' · '+realmInfo().name)},900);return true}
function questStats(){return realmStats[realmIndex]||(realmStats[realmIndex]={kills:{},total:0,chests:0,explored:false,npc:false})}
function questsForRealm(){const r=realmInfo(),m=r.mobs;return [
{title:'A ameaça inicial',description:'Derrote '+(6+realmIndex*2)+' '+m[0]+'s',kind:'kill',target:m[0],need:6+realmIndex*2},
{title:'Defesa dos habitantes',description:'Derrote '+(7+realmIndex*2)+' '+m[1]+'s',kind:'kill',target:m[1],need:7+realmIndex*2},
{title:'Tesouro perdido',description:'Encontre e abra 2 baús neste reino',kind:'chests',need:2},
{title:'Reconhecimento',description:'Explore o lado leste do mapa',kind:'explored',need:1},
{title:'O perigo aumenta',description:'Derrote '+(10+realmIndex*3)+' '+m[2]+'s',kind:'kill',target:m[2],need:10+realmIndex*3},
{title:'Conselho dos povos',description:'Converse com o mentor deste reino',kind:'npc',need:1},
{title:'Provação final',description:realmIndex===9?'Derrote o Dragão do Eclipse':'Derrote '+(22+realmIndex*5)+' monstros neste reino',kind:realmIndex===9?'dragon':'total',need:realmIndex===9?1:22+realmIndex*5}
]}
function questProgress(q){const st=questStats();return q.kind==='kill'?(st.kills[q.target]||0):q.kind==='chests'?st.chests:q.kind==='explored'?(st.explored?1:0):q.kind==='npc'?(st.npc?1:0):q.kind==='dragon'?(dragonDefeated?1:0):st.total}
function completeRealmQuest(){let stage=realmQuestStage[realmIndex]||0;if(stage>=7){toast('Todas as missões já foram concluídas!');return}const q=questsForRealm()[stage];if(questProgress(q)<q.need){toast('Complete o objetivo antes de resgatar!');return}realmQuestStage[realmIndex]=stage+1;player.gold+=35+realmIndex*12+stage*8;player.xp+=Math.round((36+realmIndex*12+stage*12)*(1+realmIndex*.12));if(stage===6){realmRewards[realmIndex]=true;player.maxHp+=25;player.hp=player.maxHp;player.maxMp+=12;player.mp=player.maxMp;toast('7 missões concluídas! Portal liberado!')}else toast('Missão '+(stage+1)+'/7 concluída! Próxima missão desbloqueada.');save()}
function endingSequence(){if(dragonDefeated)return;dragonDefeated=true;gameState='ending';save();const el=$('ending');el.classList.add('show');const c=$('endingCanvas');const dpr=Math.min(devicePixelRatio||1,2);c.width=innerWidth*dpr;c.height=innerHeight*dpr;const ec=c.getContext('2d');ec.scale(dpr,dpr);let start=performance.now();
function animate(t){if(gameState!=='ending')return;let w=innerWidth,h=innerHeight,time=(t-start)/1000;ec.fillStyle='rgba(6,8,25,.23)';ec.fillRect(0,0,w,h);
for(let i=0;i<65;i++){let x=(Math.sin(i*7.83+time*.5)*.5+.5)*w,y=h-((time*(45+i%7*14)+i*49)%(h+80)),radius=1+(i%5);ec.fillStyle=['#ffe1a1','#b7d7ff','#eaa3f5'][i%3];ec.beginPath();ec.arc(x,y,radius,0,Math.PI*2);ec.fill()}
if(time<4){ec.strokeStyle='rgba(255,235,168,'+Math.max(0,.65-time/6)+')';ec.lineWidth=6+time*9;ec.beginPath();ec.arc(w/2,h/2,time*95,0,Math.PI*2);ec.stroke()}
requestAnimationFrame(animate)}requestAnimationFrame(animate)}
const regions=[{name:'Vale do Amanhecer',start:0,end:19,level:1,ground:'#37634e',detail:'#6c9962'},{name:'Bosque Sombrio',start:20,end:39,level:3,ground:'#285345',detail:'#638e7a'},{name:'Terras Vulcânicas',start:40,end:59,level:6,ground:'#60403e',detail:'#b46c50'}];
function regionAt(x){return Math.min(2,Math.max(0,Math.floor(x/20)))}
function enemyType(x,i){const r=regionAt(x);return r===0?['Slime','Orc','Esqueleto','Lobo'][i%4]:r===1?['Aranha','Fantasma','Esqueleto','Orc','Lobo'][i%5]:['Demônio','Golem','Morcego','Fantasma','Orc'][i%5]}
function makeWorld(){seed=21421+realmIndex*141;world=Array.from({length:H},(_,y)=>Array.from({length:W},(_,x)=>{let n=noise(x+realmIndex*83,y+realmIndex*43);if(x===0||y===0||x===W-1||y===H-1)return 2;if(Math.hypot(x-8,y-8)<6||Math.hypot(x-portal.x,y-portal.y)<3)return 0;if(x>26&&x<39&&y>10&&y<25)return n>.82?2:3;if(x>42&&x<57&&y>10&&y<32)return n>.91?2:4;if(n>.93)return 2;if(n>.79)return 1;return 0}));for(let y=5;y<12;y++)for(let x=5;x<13;x++)world[y][x]=0;for(let y=18;y<24;y++)for(let x=48;x<55;x++)world[y][x]=0;
for(let x=8;x<52;x++)for(let y=19;y<=21;y++)world[y][x]=3;
for(let y=8;y<=20;y++)for(let x=7;x<=9;x++)world[y][x]=3;
for(let y=17;y<=23;y++)for(let x=48;x<=53;x++)world[y][x]=3;
for(const [bx,by] of [[16,9],[30,8],[17,29],[34,29]])for(let yy=by-2;yy<=by+2;yy++)for(let xx=bx-3;xx<=bx+3;xx++)world[yy][xx]=0;
// Obstáculos reais por bioma: cada portal gera uma geografia diferente.
for(let y=3;y<H-3;y++)for(let x=12;x<W-4;x++){
 const clearPath=(y>=18&&y<=22)||(x>=7&&x<=10)||(x>=47&&x<=54&&y>=16&&y<=25);
 const nearHouse=[[16,9],[30,8],[17,29],[34,29]].some(([hx,hy])=>Math.abs(x-hx)<5&&Math.abs(y-hy)<4);
 if(clearPath||nearHouse||Math.hypot(x-35.5,y-20.5)<5)continue;
 let k=noise(x+realmIndex*113,y-realmIndex*71),r=realmIndex;
 if(r===1&&k>.76)world[y][x]=1; // bosque denso
 else if(r===2&&k>.78)world[y][x]=2; // rochas da caverna
 else if(r===3&&k>.87)world[y][x]=2; // dunas rochosas
 else if(r===4&&k>.71)world[y][x]=2; // penhascos
 else if(r===5&&k>.81)world[y][x]=2; // gelo sólido
 else if(r===6&&k>.83)world[y][x]=2; // ruínas
 else if(r===7&&k>.77)world[y][x]=1; // árvores do pântano
 else if(r===8&&k>.82)world[y][x]=2; // rocha vulcânica
 else if(r===9&&k>.84)world[y][x]=2; // pilares do trono
}


npcs=[{x:7.5,y:5.5,name:['Mestre Rowan','Sábio Élfico','Ancião Anão','Xamã Nômade','Chefe Gigante','Oráculo Glacial','Cronista Antigo','Guardião Lagarto','Mestre Draconiano','Arauto do Eclipse'][realmIndex],role:'mentor'},{x:11.5,y:8.5,name:'Mercador '+realmInfo().race,role:'shop'},{x:7.5,y:11.5,name:'Ferreiro do Reino',role:'smith'}];
chests=[{x:15.5,y:7.5,open:false},{x:32.5,y:17.5,open:false},{x:45.5,y:30.5,open:false}];for(const c of chests)world[Math.floor(c.y)][Math.floor(c.x)]=0;
enemies=[];for(let i=0;i<28;i++){let x=12+rand()*45,y=3+rand()*35;if(passable(x,y)&&Math.hypot(x-8,y-8)>8)enemies.push(makeEnemy(x,y,realmInfo().mobs[i%realmInfo().mobs.length]))}
shots=[];particles=[];classVfx=[];loot=[];bossSpawned=false;
if(realmIndex===9&&!dragonDefeated){enemies.push(makeEnemy(35.5,20.5,'Dragão'));dragonActive=true}
}
function makeEnemy(x,y,type){const power=realmIndex,baseHp=type==='Dragão'?26000:type==='Guardião'?3700+realmIndex*540:type==='Titã'?6500+realmIndex*850:(type==='Orc'?68:type==='Esqueleto'?47:32)+power*38,hp=Math.round(baseHp*(1+realmIndex*.23+realmIndex*realmIndex*.018)*v16Balance().hp*([1,1.48,1.93,2.32][Math.min(4,Math.max(1,coopCount))-1])*(type==='Dragão'||type==='Guardião'||type==='Titã'?1.65:1));return {x,y,type,bossRealm:realmIndex,hp,maxHp:hp,speed:(type==='Dragão'?1.48:type==='Guardião'||type==='Titã'?1.4+power*.04:type==='Orc'?1.55+power*.055:1.55+power*.06)*v16Balance().speed,hit:0,attack:0,dir:0,phase:rand()*6,specialTimer:type==='Dragão'?5:9,charge:0,recovery:0,warningX:x,warningY:y,attackPattern:0,attackAngle:0,phaseLevel:1,elite:type==='Dragão'||type==='Guardião'||type==='Titã',gear:type==='Orc'?'machado':type==='Esqueleto'?'espada':type==='Demônio'?'tridente':type==='Golem'?'martelo':type==='Lobo'?'presas':type==='Aranha'?'veneno':type==='Morcego'?'garras':type==='Dragão'?'coroa':type==='Fantasma'?'orbe':'escudo',alert:0}}
function initialPlayer(){const c=classes[selectedClass];const bonus={Assassino:[105,80,16,3,12],Tanque:[245,55,8,15,3],Lanceiro:[155,70,14,7,7],Samurai:[125,85,17,5,9],Berserker:[175,55,19,4,6]}[c]||[c==='Guerreiro'?145:100,c==='Mago'?120:70,10,4,5];return {name:playerName,cls:c,x:8.5,y:8.5,dir:0,anim:0,attackAnim:0,castAnim:0,hit:0,hp:bonus[0],maxHp:bonus[0],mp:bonus[1],maxMp:bonus[1],xp:0,level:1,gold:65,statPoints:0,regenLevel:0,regenClock:0,combatStats:{critical:0,block:0,evade:0,manaRegen:0,lifesteal:0},atk:bonus[2],def:bonus[3],agility:bonus[4],inventory:[{id:'potion',name:'Poção de Vida',count:3,rarity:0},{id:'ether',name:'Poção de Mana',count:2,rarity:0},{id:c==='Arqueiro'?'bow':c==='Mago'?'staff':'sword',name:c==='Arqueiro'?'Arco de Carvalho':c==='Mago'?'Cajado Arcano':'Espada de Bronze',count:1,rarity:1}],weapon:c==='Arqueiro'?'bow':c==='Mago'?'staff':'sword',quest:0,questKills:0,dash:0,attackCD:0,skillCD:0,invuln:0,stamina:100}}
let entryLoadingBusy=false;
function enterAdventure(continueSave){
 if(entryLoadingBusy)return;
 entryLoadingBusy=true;
 // Não força rotação ao iniciar: isso evita a tela virar e voltar.
 // O botão GIRAR A TELA continua disponível na tela de nome.
 const overlay=document.getElementById('entryLoading');
 const fill=document.getElementById('entryFill');
 const count=document.getElementById('entryCount');
 const title=document.getElementById('entryTitle');
 const message=document.getElementById('entryMessage');
 if(!overlay||!fill||!count||!title||!message){try{start(continueSave);}finally{entryLoadingBusy=false;}return;}
 title.textContent=continueSave?'RETORNANDO A ELDORIA':'SUA LENDA COMEÇA';
 fill.style.width='0%';count.textContent='0%';
 overlay.classList.add('active');
 const phrases=continueSave?['Recuperando sua jornada...','Reunindo seus companheiros...','Abrindo os portões do reino...']:['As antigas runas despertam...','Preparando sua classe...','Os reinos aguardam seu herói...'];
 const began=performance.now(),duration=3400;
 function step(t){
  const f=Math.min(1,(t-began)/duration);
  const progress=Math.round(100*(1-Math.pow(1-f,1.4)));
  fill.style.width=progress+'%';count.textContent=progress+'%';
  message.textContent=phrases[Math.min(2,Math.floor(f*3))];
  if(f<1){requestAnimationFrame(step);return;}
  try{start(continueSave);}catch(error){console.error('Erro ao iniciar aventura:',error);alert('Não foi possível iniciar a aventura. Tente novamente.');}
  overlay.classList.remove('active');entryLoadingBusy=false;
 }
 requestAnimationFrame(step);
}
function start(continueSave){dungeonSession=null;const data=continueSave?load():null;realmIndex=clamp(data?.realmIndex||0,0,classicRealms.length-1);realmKills=data?.realmKills||{};realmRewards=data?.realmRewards||{};realmQuestStage=data?.realmQuestStage||{};realmStats=data?.realmStats||{};dragonDefeated=!!data?.dragonDefeated;introSeen=false;adventure={talents:{},points:0,companion:'none',companionCD:0,achievements:{},dungeons:{},weather:0,weatherClock:0,questChoice:{},sound:true,...(data?.adventure||{})};player=data?.player||initialPlayer();player.invuln=0;player.hit=0;if(data?.adventure?.talents&&['Assassino','Tanque','Lanceiro','Samurai','Berserker'].includes(player.cls)){const ids=({Assassino:['shadow','silent','poison'],Tanque:['fortress','iron','taunt'],Lanceiro:['reach','thrust','spearGuard'],Samurai:['lightning','discipline','counter'],Berserker:['frenzy','heavy','savage']})[player.cls];ids.forEach((id,i)=>{const previous=adventure.talents['extra'+i]||0;if(previous&&!adventure.talents[id])adventure.talents[id]=previous});}if(!classes.includes(player.cls))player.cls='Guerreiro';for(const [k,fallback] of Object.entries({maxHp:100,maxMp:70,atk:10,def:4,agility:5,level:1})){if(!Number.isFinite(player[k]))player[k]=fallback}player.combatStats=player.combatStats||{};for(const k of ['critical','block','evade','manaRegen','lifesteal'])player.combatStats[k]=clamp(Math.floor(Number(player.combatStats[k])||0),0,5);if(!Number.isFinite(player.regenLevel))player.regenLevel=0;player.regenLevel=clamp(Math.floor(player.regenLevel),0,5);player.regenClock=0;if(!Number.isFinite(player.hp))player.hp=player.maxHp;if(!Number.isFinite(player.mp))player.mp=player.maxMp;if(!Number.isFinite(player.x)||!Number.isFinite(player.y)||player.x<1||player.y<1||player.x>=W-1||player.y>=H-1){player.x=8.5;player.y=8.5;}coopCount=1;coopAllies=[];makeWorld();player.name=player.name||playerName;player.hp=clamp(player.hp,1,player.maxHp);player.mp=clamp(player.mp,0,player.maxMp);player.inventory=player.inventory||[];ensureQuickPotions();expansionReset();adventure.points=Math.max(0,adventure.points||0);ensureEquipment();player.weapon=player.weapon||(player.cls==='Arqueiro'?'bow':player.cls==='Mago'?'staff':'sword');if(data){gameTime=data.gameTime||0;killCount=data.killCount||0;bossSpawned=!!data.bossSpawned;regionNotice=-1;data.chests?.forEach((v,i)=>{if(chests[i])chests[i].open=!!v});if(bossSpawned)enemies.push(makeEnemy(35.5,20.5,'Guardião'))}else{gameTime=0;killCount=0;regionNotice=-1;realmKills={};realmRewards={};realmQuestStage={};realmStats={};dragonDefeated=false}gameState='playing';document.body.classList.add('eldoria-playing');updateEldoriaOrientation();$('expeditionBar').style.display='flex';$('overlay').classList.add('hidden');closeModal();resize();camera.x=player.x*T*Math.min(1.2,Math.max(.86,innerHeight/480))-innerWidth/2;camera.y=player.y*T*Math.min(1.2,Math.max(.86,innerHeight/480))-innerHeight/2;applySettings();toast(`Bem-vindo a Eldoria, ${player.name}!`);updateHUD();if(realmIndex===9&&!dragonDefeated)setTimeout(summonDragonIntro,650)}
function passable(x,y,r=.26){return [[-r,-r],[r,-r],[-r,r],[r,r]].every(([dx,dy])=>{let tx=Math.floor(x+dx),ty=Math.floor(y+dy);return tx>=0&&ty>=0&&tx<W&&ty<H&&world[ty][tx]!==2&&!(world[ty][tx]===1&&(realmIndex===1||realmIndex===7))})}
function move(obj,dx,dy){if(passable(obj.x+dx,obj.y))obj.x+=dx;if(passable(obj.x,obj.y+dy))obj.y+=dy}
function target(){let best=null,d=7;for(const e of enemies){let t=dist(player,e);if(t<d){best=e;d=t}}return best}
function direction(){let t=target();if(t&&dist(player,t)<8){let dx=t.x-player.x,dy=t.y-player.y,m=Math.hypot(dx,dy)||1;return {x:dx/m,y:dy/m}}return [{x:0,y:1},{x:-1,y:0},{x:0,y:-1},{x:1,y:0}][player.dir]||{x:0,y:1}}
function effect(x,y,color,n=8){if(!settings.particles)return;n=Math.min(n,settings.quality==='low'?5:(matchMedia('(pointer:coarse)').matches?10:18));if(particles.length>(matchMedia('(pointer:coarse)').matches?75:115))return;for(let i=0;i<n;i++){let a=Math.random()*Math.PI*2,s=.4+Math.random()*2;particles.push({x,y,vx:Math.cos(a)*s,vy:Math.sin(a)*s,life:.35+Math.random()*.4,color})}}
function damage(e,d){const bonus=player?.combatStats||{};const critical=Math.random()<(bonus.critical||0)*.03;if(critical){d*=1.65;e.critFlash=.35;}d=Math.max(1,Math.round(d*(1+regionAt(e.x)*0.02)));if((bonus.lifesteal||0)>0&&player?.hp>0&&player.hp<player.maxHp)player.hp=Math.min(player.maxHp,player.hp+Math.max(1,Math.floor(d*(bonus.lifesteal||0)*.01)));if(e.hp<=0)return;e.hp-=d;if(e.hp>0&&expansion().enchants.weapon&&Math.random()<.18){const kind=expansion().enchants.weapon;e.hp-=Math.round(3+player.level*.4);effect(e.x,e.y,ELD_ENCHANTS[kind].color,5);if(kind==='ice')e.recovery=Math.max(e.recovery||0,.4)}if(e.elite&&e.hp>0&&e.hp<e.maxHp*.5&&!e.secondPhase){e.secondPhase=true;e.speed*=1.25;e.specialTimer=Math.min(e.specialTimer||5,2);toast('SEGUNDA FASE! O chefe ficou mais agressivo!');effect(e.x,e.y,'#fca0ff',22)}e.hit=.18;if(e.elite&&Math.random()<.3)soundFx('hit');effect(e.x,e.y,'#ffe4a5',6);if(e.hp<=0){expansionKill(e);killCount++;player.questKills++;const qs=questStats();qs.kills[e.type]=(qs.kills[e.type]||0)+1;qs.total++;if(e.dungeon&&dungeonSession){dungeonSession.completed=true;adventure.dungeons[realmIndex]=true;player.gold+=500+realmIndex*160;addItem({id:'elixir',name:'Elixir Maior',count:4,rarity:2});achieve('dungeon','Explorador de masmorras');toast('GUARDIÃO VENCIDO! +ouro e 4 elixires. Volte ao início para sair.')}else if(e.dungeon&&adventure.dungeonActive===realmIndex){adventure.dungeonRemaining=Math.max(0,(adventure.dungeonRemaining||1)-1);if(adventure.dungeonRemaining===0){adventure.dungeons[realmIndex]=true;adventure.dungeonActive=-1;player.gold+=180+realmIndex*30;addItem({id:'elixir',name:'Elixir Maior',count:2,rarity:2});toast('Masmorra concluída! Recompensa recebida.');achieve('dungeon','Explorador de masmorras')}}if(e.type===realmInfo().goal)realmKills[realmIndex]=(realmKills[realmIndex]||0)+1;
if(e.type==='Dragão'){achieve('dragon','Lenda dos Dez Reinos');soundFx('win');questStats().dragon=1;effect(e.x,e.y,'#ffdc80',80);endingSequence();return;}const recommendedLevel=Math.max(1,Number(realmInfo().level)||1);
const xpMultiplier=(1+realmIndex*.65)*(1+Math.min(1.25,Math.max(0,recommendedLevel-1)*.045));
const levelCatchup=1+Math.min(.65,Math.max(0,player.level-recommendedLevel)*.018);
let gain=Math.round((e.elite?260:e.type==='Orc'?55:38)*xpMultiplier*levelCatchup);
player.xp+=gain;player.gold+=e.elite?160:4+Math.floor(Math.random()*8);effect(e.x,e.y,'#d6e9ff',18);toast(e.elite?'Guardião derrotado! Tesouro lendário!':`+${gain} XP`);if(e.elite){player.gold+=75+realmIndex*35;player.xp+=Math.round((110+realmIndex*38)*xpMultiplier);toast('Recompensa do chefe: moedas e experiência bônus!');addItem({id:'relic',name:'Relíquia do Guardião',count:1,rarity:4});const legendary=['Guerreiro','Assassino','Tanque','Lanceiro','Samurai','Berserker'].includes(player.cls)?'sword3':player.cls==='Arqueiro'?'bow3':'staff3';addItem({id:legendary,name:gearCatalog[legendary].name,count:1,rarity:4});}gearDrop(e);if(Math.random()<.25)addItem({id:'potion',name:'Poção de Vida',count:1,rarity:0});while(player.xp>=player.level*65){player.xp-=player.level*65;player.level++;adventure.points++;if(player.level===5)achieve('veteran','Veterano de Eldoria');player.maxHp+=12;player.maxMp+=8;player.hp=player.maxHp;player.mp=player.maxMp;player.statPoints+=2;toast(`Nível ${player.level}! +2 pontos de atributo`)}save()}}
function shoot(x,y,dx,dy,type,dmg,speed=9){shots.push({x,y,vx:dx*speed,vy:dy*speed,type,dmg,life:1.3,r:type==='arrow'?.12:.22,enemy:false});effect(x,y,type==='arrow'?'#f5d59d':'#80e5ff',3)}
function attack(){if(!player||gameState!=='playing'||modalOpen||player.attackCD>0)return;const p=player,dir=direction();p.attackAnim=.24;expansion().comboClock=3.2;p.attackCD=({Assassino:.18,Tanque:.47,Lanceiro:.37,Samurai:.26,Berserker:.43,Guerreiro:.32,Arqueiro:.58,Mago:.72}[p.cls]||.32);if(!['Arqueiro','Mago'].includes(p.cls)){for(const e of enemies){let dx=e.x-p.x,dy=e.y-p.y,d=Math.hypot(dx,dy);if(d<(p.cls==='Lanceiro'?2.8:1.7)&&(dx*dir.x+dy*dir.y)/Math.max(.01,d)>(p.cls==='Tanque'?-0.3:.05))damage(e,(20+p.level*3+p.atk+gearStats().atk)*(1+talentLevel('rage')*.11)*({Assassino:.68,Tanque:.85,Lanceiro:1.03,Samurai:1.12,Berserker:1.38}[p.cls]||1)*(p.cls==='Berserker'?(1+(.65*(1-p.hp/p.maxHp)))*(p.berserkTime>0?1.25:1):1)*talentAttackBonus())}effect(p.x+dir.x*.7,p.y+dir.y*.7,({Guerreiro:'#ffd47d',Assassino:'#c58dff',Tanque:'#92d8ff',Lanceiro:'#91e9f4',Samurai:'#ff9baf',Berserker:'#ff7450'})[p.cls]||'#fce2a0',14)}else if(p.cls==='Arqueiro'){shoot(p.x+dir.x*.55,p.y+dir.y*.55,dir.x,dir.y,'arrow',(21+p.level*3+p.agility+gearStats().atk)*(1+talentLevel('pierce')*.12))}else if(p.mp>=4){p.mp-=4;shoot(p.x+dir.x*.5,p.y+dir.y*.5,dir.x,dir.y,'magic',(26+p.level*4+p.atk+gearStats().atk)*(1+talentLevel('arcane')*.13),7.5);p.castAnim=.35}else toast('Mana insuficiente!')}

// Animações temporárias das oito habilidades, renderizadas em Canvas sem imagens externas.
let classVfx=[];
function addClassVfx(kind,x,y,dx=0,dy=1){
 if(classVfx.length>12)classVfx.shift();
 classVfx.push({kind,x,y,dx,dy,age:0,life:kind==='Berserker'?1.05:kind==='Tanque'?.95:.65});
}
function drawClassVfx(at,unit){
 const coarse=matchMedia('(pointer:coarse)').matches;
 ctx.save();
 for(const v of classVfx){
  const [x,y]=at(v.x,v.y),t=Math.min(1,v.age/v.life),fade=(1-t),r=unit;
  if(x<-r*5||x>innerWidth+r*5||y<-r*5||y>innerHeight+r*5)continue;
  ctx.globalAlpha=fade*.88;ctx.lineCap='round';ctx.lineJoin='round';
  const arc=(radius,start,end,color,width=4)=>{ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();ctx.arc(x,y,radius,start,end);ctx.stroke()};
  const line=(x1,y1,x2,y2,color,width=4)=>{ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke()};
  const a=Math.atan2(v.dy,v.dx);
  switch(v.kind){
   case 'Guerreiro':
    for(let k=0;k<3;k++)arc(r*(.4+t*2.8-k*.24),0,Math.PI*2,k%2?'#ffe5a5':'#ff9d48',Math.max(1,5-k));
    break;
   case 'Arqueiro':
    for(let k=-1;k<=1;k++){const angle=a+k*.20,px=x+Math.cos(angle)*r*(.4+t*2.6),py=y+Math.sin(angle)*r*(.4+t*2.6);line(px-Math.cos(angle)*r*.65,py-Math.sin(angle)*r*.65,px,py,'#ffe4a4',3);line(px,py,px-Math.cos(angle+.6)*r*.18,py-Math.sin(angle+.6)*r*.18,'#fff8da',2)}
    break;
   case 'Mago':
    arc(r*(.35+t*2.3),0,Math.PI*2,'#7be6ff',5);for(let k=0;k<8;k++){let q=k*Math.PI/4+t*.4;const px=x+Math.cos(q)*r*(.35+t*2),py=y+Math.sin(q)*r*(.35+t*2);ctx.fillStyle=k%2?'#b9f7ff':'#76a9ff';ctx.fillRect(px-3,py-3,6,6)}
    break;
   case 'Assassino':
    for(let k=0;k<3;k++){let o=(k-1)*r*.22;line(x-v.dx*r*(1.8-t)+o,y-v.dy*r*(1.8-t)-r*.4,x+v.dx*r*(.4+t)+o,y+v.dy*r*(.4+t)+r*.4,'#b98bff',5-k)}
    break;
   case 'Tanque':
    ctx.fillStyle='rgba(120,205,255,.12)';ctx.strokeStyle='#b9efff';ctx.lineWidth=5;ctx.beginPath();ctx.ellipse(x,y-r*.22,r*(.65+t*.32),r*(.9+t*.35),0,0,Math.PI*2);ctx.fill();ctx.stroke();arc(r*(.6+t*1.4),0,Math.PI*2,'#9bc9e6',2);
    break;
   case 'Lanceiro':
    for(let k=-1;k<=1;k++){let side=k*r*.16;line(x-v.dx*r*.5-v.dy*side,y-v.dy*r*.5+v.dx*side,x+v.dx*r*(1.4+t*1.4)-v.dy*side,y+v.dy*r*(1.4+t*1.4)+v.dx*side,'#b4fff1',k===0?6:2)}
    break;
   case 'Samurai':
    ctx.translate(x,y);ctx.rotate(a);ctx.strokeStyle='#ffd3e4';ctx.lineWidth=7;ctx.beginPath();ctx.arc(0,0,r*(.8+t*1.3),-.95,1.05);ctx.stroke();ctx.strokeStyle='#fff';ctx.lineWidth=2;ctx.stroke();ctx.rotate(-a);ctx.translate(-x,-y);
    break;
   case 'Berserker':
    for(let k=0;k<5;k++){const q=k*Math.PI*2/5+t*.7;line(x+Math.cos(q)*r*.3,y+Math.sin(q)*r*.3,x+Math.cos(q)*r*(.85+t*.9),y+Math.sin(q)*r*(.85+t*.9),k%2?'#ffcc70':'#ff6c55',5)}
    arc(r*(.5+t*.7),0,Math.PI*2,'#ff775b',3);
    break;
  }
  if(!coarse&&settings.quality==='high'){ctx.globalAlpha=fade*.18;ctx.fillStyle='#fff';ctx.beginPath();ctx.arc(x,y,r*(.3+t*.4),0,Math.PI*2);ctx.fill()}
 }
 ctx.restore();
}

// Poder exclusivo de cada classe: dano e utilidade, com custo e recarga próprios.
const CLASS_POWERS={Guerreiro:['Onda Sísmica',20,6],Arqueiro:['Rajada de Flechas',20,7],Mago:['Explosão Arcana',25,8],Assassino:['Passo das Sombras',18,7],Tanque:['Muralha de Ferro',20,11],Lanceiro:['Investida Perfurante',18,7],Samurai:['Corte Relâmpago',22,8],Berserker:['Fúria de Batalha',25,12]};
function skill(){
 if(!player||gameState!=='playing'||modalOpen||player.skillCD>0)return;
 const p=player,d=direction(),cfg=CLASS_POWERS[p.cls]||CLASS_POWERS.Guerreiro;
 if(p.mp<cfg[1]){toast('Precisa de '+cfg[1]+' de mana!');return}
 p.mp-=cfg[1];p.skillCD=cfg[2];p.castAnim=.48;addClassVfx(p.cls,p.x,p.y,d.x,d.y);
 const base=23+p.level*2.7+p.atk*.6+gearStats().atk;
 const hit=(range,scale,cone=false,slow=0)=>{let count=0;for(const e of enemies){if(e.hp<=0)continue;const dx=e.x-p.x,dy=e.y-p.y,dist=Math.hypot(dx,dy)||.01;if(dist>range||(cone&&(dx*d.x+dy*d.y)/dist<.35))continue;damage(e,Math.round(base*scale*talentSkillBonus()));if(slow)e.recovery=Math.max(e.recovery||0,slow);count++}return count};
 switch(p.cls){
 case 'Guerreiro':hit(3,1.05,false,.45);effect(p.x,p.y,'#ffb764',18);break;
 case 'Arqueiro':for(const a of [-.20,0,.20]){const t=Math.atan2(d.y,d.x)+a;shoot(p.x,p.y,Math.cos(t),Math.sin(t),'arrow',Math.round(base*.9),10)}break;
 case 'Mago':for(let i=0;i<8;i++){const t=i*Math.PI/4;shoot(p.x,p.y,Math.cos(t),Math.sin(t),'magic',Math.round(base*.78),7)}effect(p.x,p.y,'#7ae6ff',16);break;
 case 'Assassino':{const tx=p.x+d.x*2.5,ty=p.y+d.y*2.5;if(passable(tx,ty)){effect(p.x,p.y,'#c58bff',12);p.x=tx;p.y=ty}hit(1.7,1.38);p.invuln=Math.max(p.invuln,.35);effect(p.x,p.y,'#b994ff',12);break}
 case 'Tanque':{adventure.petGuard=(adventure.petGuard||0)+Math.round(p.maxHp*.16);adventure.petGuardTime=5;hit(2, .65,false,.55);effect(p.x,p.y,'#b8e9ff',16);break}
 case 'Lanceiro':{for(let i=1;i<=3;i++){const tx=p.x+d.x*.65,ty=p.y+d.y*.65;if(passable(tx,ty)){p.x=tx;p.y=ty}}hit(2.6,1.16,true,.25);effect(p.x,p.y,'#a6f7ec',13);break}
 case 'Samurai':{hit(3,1.48,true,.5);p.invuln=Math.max(p.invuln,.28);effect(p.x+d.x,p.y+d.y,'#ffb5ce',15);break}
 case 'Berserker':{p.berserkTime=5;hit(2.4,1.16);effect(p.x,p.y,'#ff805c',17);break}
 }
 toast(cfg[0]+'!');
}

function dodge(){if(!player||gameState!=='playing'||player.dash>0||modalOpen)return;if(player.stamina<18){toast('Sem energia para esquivar!');return}player.dash=.34;player.invuln=.40+talentLevel('silent')*.035;player.stamina-=18;effect(player.x,player.y,'#c5f9ff',10)}
function addItem(item){const old=player.inventory.find(i=>i.id===item.id);if(old)old.count+=item.count;else player.inventory.push({...item});}
const POTION_NAMES={potion:'Poção de Vida',ether:'Poção de Mana',elixir:'Elixir Maior',tonic:'Tônico de Energia'};
function ensureQuickPotions(){if(!player)return;const q=player.quickPotions;if(!Array.isArray(q))player.quickPotions=['potion','ether'];else player.quickPotions=[0,1].map(i=>POTION_NAMES[q[i]]?q[i]:null)}
function equipQuickPotion(slot,id){ensureQuickPotions();if(![0,1].includes(slot)||!POTION_NAMES[id])return;player.quickPotions[slot]=id;save();openModal('inventory');toast(POTION_NAMES[id]+' equipada no atalho '+(slot+1))}
function quickPotion(slot){if(!player||gameState!=='playing'||modalOpen)return;ensureQuickPotions();const id=player.quickPotions[slot];if(!id){toast('Equipe uma poção pela mochila.');return}const item=player.inventory.find(i=>i.id===id&&i.count>0);if(!item){toast('Sem '+POTION_NAMES[id]+' na mochila!');return}useItem(id,true)}
function refreshQuickPotions(){if(!player)return;ensureQuickPotions();for(let i=0;i<2;i++){const el=document.getElementById('quickPotion'+i);if(!el)continue;const id=player.quickPotions[i],n=player.inventory.find(v=>v.id===id)?.count||0;el.innerHTML='<span class="potionIcon">'+(id==='potion'?'❤':id==='ether'?'✦':id==='elixir'?'✚':id==='tonic'?'⚡':'+')+'</span><span class="potionCount">'+n+'</span>';el.title=id?POTION_NAMES[id]+' ('+n+')':'Equipe uma poção na mochila';el.classList.toggle('empty',!n)}}
function useItem(id,quick=false){const item=player.inventory.find(i=>i.id===id&&i.count>0);if(!item)return;
if(gearCatalog[id]){equipGear(id);return}
if(id==='potion'){if(player.hp>=player.maxHp){toast('Vida já está cheia!');return}player.hp=Math.min(player.maxHp,player.hp+65)}
else if(id==='ether'){if(player.mp>=player.maxMp){toast('Mana já está cheia!');return}player.mp=Math.min(player.maxMp,player.mp+50)}
else if(id==='elixir'){player.hp=Math.min(player.maxHp,player.hp+180);player.mp=Math.min(player.maxMp,player.mp+90)}
else if(id==='tonic'){player.stamina=Math.min(100,player.stamina+80)}
else{toast('Relíquia de missão: guarde este item!');return}
item.count--;if(item.count<=0)player.inventory=player.inventory.filter(i=>i!==item);toast('Item utilizado!');save();refreshQuickPotions();if(!quick)openModal('inventory')}
const realmDialogues=[
{tone:'Vila acolhedora',mentor:['Bem-vindo à Vila de Eldoria, viajante. Aqui até os heróis começam pequenos.','As criaturas se aproximam dos campos. Ajude os moradores antes que a noite caia.','Observe os ataques, proteja a vila e prove que merece atravessar o portal.'],shop:['Entre, entre! Tenho remédios fresquinhos e boas ofertas para quem protege a vila.','Se você voltar machucado, uma poção custa menos que uma derrota.','Escolha com calma. Nossa vila precisa de você inteiro.'],smith:['Ora, uma arma tão gasta! Sente-se perto da forja.','O aço simples também vence batalhas quando a mão é firme.','Traga ouro e farei sua lâmina brilhar como o sol da manhã.']},
{tone:'Conselho élfico',mentor:['Silêncio, forasteiro. As árvores do Bosque dos Elfos escutam cada palavra.','Aranhas profanaram nossos caminhos sagrados. Pise com cuidado entre as raízes.','Não lute com pressa: mova-se como o vento e ataque quando a floresta permitir.'],shop:['Que a luz das folhas acompanhe seus passos.','Nossos elixires são preparados com orvalho e ervas do bosque.','Leve somente o necessário; a natureza aprecia o equilíbrio.'],smith:['O metal dos elfos não grita sob o martelo: ele canta.','Uma arma leve é mais valiosa que uma espada que você mal consegue erguer.','Permita-me aperfeiçoar seu equipamento com a precisão das estrelas.']},
{tone:'Salões anões',mentor:['Pelas barbas dos ancestrais! Outro aventureiro nas minas!','Os morcegos invadiram os túneis e os cristais começaram a vibrar.','Fique longe das paredes instáveis. Aqui a coragem precisa de uma boa armadura.'],shop:['Ha! Ouro! Finalmente alguém que entende de negócios!','Tenho poções fortes e suprimentos dignos dos salões de pedra.','Não pechinche demais, ou meus ancestrais vão reclamar.'],smith:['Escute esse som: TANG! Isso é aço de verdade!','Minhas melhorias aguentam o peso de um golem.','Quanto mais poderosa a arma, mais caro o minério. É assim que funciona!']},
{tone:'Tradição nômade',mentor:['Que as dunas escondam seus rastros, viajante.','O deserto não perdoa a arrogância. Demônios caminham onde antes havia oásis.','Aprenda a recuar quando a areia tremer. A paciência salva mais que a força.'],shop:['Água, remédios e histórias: tudo tem valor nas dunas.','Meus produtos viajaram por caravanas sob três luas.','Compre antes da tempestade; no deserto não existe segunda oportunidade.'],smith:['O fogo do deserto tempera as melhores lâminas.','Uma arma resistente não teme areia nem calor.','Traga suas moedas e deixarei sua arma pronta para a travessia.']},
{tone:'Voz dos gigantes',mentor:['PEQUENO GUERREIRO! SUA VOZ MAL CHEGA À MINHA CINTURA!','AS MONTANHAS ESTÃO ACORDANDO. GOLEMS BLOQUEIAM OS PASSOS ANTIGOS.','NÃO ENFRENTE A PEDRA DE FRENTE. DESVIE, ESPERE E GOLPEIE!'],shop:['PEQUENINO! TENHO ITENS GRANDES E PREÇOS JUSTOS!','SEUS BOLSOS SÃO MINÚSCULOS, MAS SUA CORAGEM PARECE ENORME!','ESCOLHA ALGO FORTE O BASTANTE PARA SUBIR A MONTANHA!'],smith:['HA! SUA ESPADA PARECE UM PALITO!','UM BOM MARTELO PODE TRANSFORMAR ATÉ FERRO FRACO EM ARMA DE HERÓI!','TRAGA OURO. EU TRAGO O TROVÃO DA FORJA!']},
{tone:'Sussurros glaciais',mentor:['Fale baixo... o gelo guarda ecos de batalhas antigas.','Os espíritos da neve vagam entre os ventos congelados.','Quando o frio tocar seus ossos, mantenha a calma. A pressa quebra como vidro.'],shop:['Aproxime-se da chama azul, viajante.','Guardo poções aquecidas para quem ousa cruzar a tundra.','Que a neve nunca apague a sua esperança.'],smith:['O aço canta diferente sob temperaturas tão baixas.','Temperarei sua arma no gelo eterno, se você tiver ouro suficiente.','Um golpe preciso vale mais que cem movimentos desesperados.']},
{tone:'Ecos da cidade antiga',mentor:['Você caminha sobre ruas que já pertenceram a reis esquecidos.','Os esqueletos protegem segredos que nem a morte conseguiu apagar.','Honre as ruínas. Cada pedra conta uma história e cada batalha cobra um preço.'],shop:['Há muito tempo, este mercado recebia caravanas de todos os reinos.','Agora vendo relíquias e suprimentos a quem ainda tem coragem de entrar.','Não confunda o brilho de um objeto com seu verdadeiro valor.'],smith:['Estas ferramentas foram herdadas de ferreiros de outra era.','O metal antigo possui marcas que só os pacientes conseguem compreender.','Posso restaurar sua arma, mas nenhum ouro compra a sabedoria perdida.']},
{tone:'Clãs do pântano',mentor:['Sss... estranho de pele seca, por que pisa em nossa água?','Aranhas gigantes tomaram os ninhos do nosso clã.','Pise onde a lama não borbulha. O pântano engole os descuidados, sss!'],shop:['Sss... minhas poções não têm cheiro agradável, mas funcionam.','Os caçadores do clã trocaram ervas raras por estes frascos.','Compre logo, antes que os mosquitos levem tudo!'],smith:['Sss... ossos, escamas e ferro podem formar proteção poderosa.','Sua armadura faz barulho demais na lama. Vamos reforçá-la.','Traga ouro e respeite as tradições do clã.']},
{tone:'Juramento draconiano',mentor:['Pelo sangue das primeiras chamas, você chegou longe.','Nossos ancestrais juraram vigiar o fogo. Agora demônios profanam os vulcões.','Quando o chão brilhar, desvie. O verdadeiro guerreiro domina o próprio medo.'],shop:['O calor destrói mercadorias comuns. As minhas foram forjadas para resistir.','Tenho elixires para batalhas que fariam reis abandonar suas coroas.','Prepare-se: além deste reino, o próprio destino aguarda.'],smith:['As chamas daqui derretem metais que você nunca viu.','Sua arma pode carregar um fragmento do poder dracônico.','Mas poder tem preço, aventureiro. Está pronto para pagá-lo?']},
{tone:'Último juramento',mentor:['Então você chegou ao Trono do Dragão... poucos sobreviveram até aqui.','O Dragão do Eclipse conhece o medo de todos que o enfrentam.','Observe suas três fases. Desvie das marcas no chão, sobreviva e ataque durante a recuperação.'],shop:['Não sei se haverá outro cliente depois de você.','Separei minhas melhores poções para esta última batalha.','Volte vitorioso. Quero poder contar sua história.'],smith:['Esta pode ser a última arma que minhas mãos irão melhorar.','Cada golpe da forja é um juramento contra a escuridão.','Vá, campeão. Que o aço resista e seu coração não recue.']}
];
function npcSpeech(){const n=dialogueNpc,r=realmInfo(),d=realmDialogues[realmIndex]||realmDialogues[0];let lines=d[n.role]||d.mentor;
if(n.role==='mentor'&&(realmQuestStage[realmIndex]||0)>0)lines=[lines[0],`Você já superou ${(realmQuestStage[realmIndex]||0)} das sete provas de ${r.name}.`,lines[2]];
return lines.map(t=>t.replaceAll('{realm}',r.name).replaceAll('{race}',r.race).replaceAll('{name}',n.name))}
function npcDecision(){if(!dialogueNpc||dialogueNpc.role!=='mentor')return;const r=realmInfo();modal('Decisão — '+r.name,`<p>${questFlavor()}</p><p>Como você pretende ajudar o povo de ${r.race}?</p><div class="row"><button data-act="choice:guard">Proteger os habitantes</button><button data-act="choice:hunt">Caçar os invasores</button></div><p class="small">A escolha concede um bônus único por reino e fica registrada no salvamento.</p>`);document.querySelectorAll('[data-act]').forEach(b=>b.onclick=()=>action(b.dataset.act))}
function showNpcDialogue(){if(!dialogueNpc)return;const lines=npcSpeech(),line=lines[Math.min(dialogueStep,lines.length-1)];modal(dialogueNpc.name+` · ${realmDialogues[realmIndex].tone}`,`<p style="font-size:16px;line-height:1.65;min-height:76px">“${line}”</p><p class="small">${Math.min(dialogueStep+1,lines.length)}/${lines.length}</p><div class="row"><button data-act="dialogueNext">${dialogueStep<lines.length-1?'Continuar ▶':'Encerrar conversa'}</button>${dialogueStep>=lines.length-1?`<button data-act="dialogueOption">${dialogueNpc.role==='mentor'?'Ver missões':dialogueNpc.role==='shop'?'Abrir loja':'Melhorar arma'}</button>`:''}</div>`);document.querySelectorAll('[data-act]').forEach(b=>b.onclick=()=>action(b.dataset.act))}
function secretLocation(){const spots=[[13,10],[44,8],[17,33],[49,30],[29,13],[11,27],[42,26],[24,37]];const spot=spots[realmIndex%spots.length];for(let r=0;r<7;r++)for(let a=0;a<12;a++){const x=clamp(Math.floor(spot[0]+Math.cos(a*Math.PI/6)*r),2,W-3),y=clamp(Math.floor(spot[1]+Math.sin(a*Math.PI/6)*r),2,H-3);if(passable(x+.5,y+.5))return {x:x+.5,y:y+.5}}return {x:8.5,y:8.5}}
function secretNear(){if(dungeonSession||!player||adventure.secretCaches?.[realmIndex])return false;return dist(player,secretLocation())<1.8}
function claimSecret(){adventure.secretCaches=adventure.secretCaches||{};adventure.secretCaches[realmIndex]=true;const reward=110+realmIndex*32;player.gold+=reward;player.xp+=35+realmIndex*8;effect(player.x,player.y,'#f9d784',18);toast('SEGREDO DESCOBERTO! +'+reward+' moedas e XP');save()}
function interact(){if(!player||modalOpen||gameState!=='playing')return;if(dungeonSession){dungeonInteract();return}if(dungeonReady()){enterDungeon();return}if(returnRealm())return;if(travelPortal())return;if(secretNear()){claimSecret();return}for(const n of npcs)if(dist(player,n)<2){if(n.role==='mentor')questStats().npc=true;dialogueNpc=n;dialogueStep=0;showNpcDialogue();return}for(const c of chests)if(!c.open&&dist(player,c)<1.8){c.open=true;questStats().chests++;const reward=35+realmIndex*7+Math.floor(Math.random()*35);player.gold+=reward;addItem({id:Math.random()<.35?'ether':'potion',name:'Suprimento encontrado',count:2,rarity:0});toast('Baú encontrado: +'+reward+' moedas e 2 suprimentos!');save();return}toast('Aproxime-se de um NPC ou baú para interagir.')}
function buy(id,cost){if(player.gold<cost){toast('Ouro insuficiente!');return}player.gold-=cost;addItem({id,name:id==='potion'?'Poção de Vida':'Poção de Mana',count:1,rarity:0});save();openModal('shop')}
function upgrade(which){const extra=['critical','block','evade','manaRegen','lifesteal'];if(extra.includes(which)){player.combatStats=player.combatStats||{};if((player.combatStats[which]||0)>=5){toast('Atributo no nível máximo!');return}if(player.statPoints<=0){toast('Sem pontos disponíveis!');return}player.statPoints--;player.combatStats[which]=(player.combatStats[which]||0)+1;save();openModal('stats');return}if(player.statPoints<=0){toast('Sem pontos disponíveis!');return}if(which==='regen'&&(player.regenLevel||0)>=5){toast('Regeneração já está no nível máximo (5)!');return}player.statPoints--;if(which==='regen'){player.regenLevel=Math.min(5,(player.regenLevel||0)+1);toast('Recuperação de vida: nível '+player.regenLevel+'/5');}else if(which==='forca')player.atk+=2;else if(which==='defesa')player.def+=2;else player.agility+=2;save();openModal('stats')}
function modal(title,content){$('modalTitle').textContent=title;$('modalClose').style.display=(dialogueNpc&&title.startsWith(dialogueNpc.name+' ·'))?'none':'';$('modalContent').innerHTML=content;$('modal').classList.add('open');modalOpen=true;gameState=gameState==='playing'?'paused':gameState}
function closeModal(){$('modal').classList.remove('open');modalOpen=false;if(player&&gameState==='paused')gameState='playing'}
function compareGear(id){const g=gearCatalog[id];if(!g)return '';ensureEquipment();const oldId=player.equipment[g.slot],old=gearCatalog[oldId]||{atk:0,def:0,agility:0};const names={atk:'Ataque',def:'Defesa',agility:'Agilidade'};let total=0;const lines=['atk','def','agility'].map(k=>{const delta=(g[k]||0)-(old[k]||0);total+=delta;return `<span style="color:${delta>0?'#79e9a4':delta<0?'#ff9292':'#aeb9c8'}">${names[k]} ${delta>0?'+':''}${delta}</span>`}).join(' · ');return `<div class="small" style="margin-top:4px">Comparado a <b>${oldId?old.name:'nenhum equipamento'}</b>: ${lines} · <b style="color:${total>0?'#79e9a4':total<0?'#ff9292':'#cdd9e9'}">${oldId===id?'EQUIPADO':total>0?'MELHOR':total<0?'PIOR':'EQUIVALENTE'}</b></div>`}
function openModal(type){const menuType=gameState==='menu'||gameState==='class'||gameState==='login';const btn=(label,action)=>`<button data-act="${action}">${label}</button>`;let title='',body='';
if(type==='expansionHub'){title='Novidades de Eldoria';body='<p>Novos sistemas de progressão, comércio, tesouros e poderes.</p><div class="menuGrid">'+btn('Missões diárias e semanais','expansionQuests')+btn('Encantamentos','expansionForge')+btn('Especialização e títulos','expansionProgress')+btn('Mercado de venda','expansionMarket')+btn('Poder do pet','expansionPet')+'</div>'}
else if(type==='expansionQuests'){title='Contratos de Eldoria';expansionReset();const e=expansion();body=`<div class="item"><div class="grow"><b>Caçada diária</b><p>${e.daily.kills}/15 monstros derrotados</p></div>${btn(e.daily.claimed?'Resgatado':'Resgatar','expansionClaim:daily')}</div><div class="item"><div class="grow"><b>Caçada semanal</b><p>${e.weekly.kills}/80 monstros derrotados</p></div>${btn(e.weekly.claimed?'Resgatado':'Resgatar','expansionClaim:weekly')}</div>`}
else if(type==='expansionForge'){title='Encantamentos da Arma';ensureEquipment();const e=expansion();body=`<p>Encantamento atual: <b>${ELD_ENCHANTS[e.enchants.weapon]?.name||'Nenhum'}</b>. Exige 2 fragmentos e ${180+realmIndex*60} ouro.</p>`+Object.entries(ELD_ENCHANTS).map(([id,x])=>`<div class="item"><div class="grow"><b>${x.name}</b><div class="small">Chance de dano elemental; gelo pode atrasar inimigos.</div></div>${btn('Encantar','expansionEnchant:'+id)}</div>`).join('')}
else if(type==='expansionProgress'){title='Especialização e Títulos';const e=expansion();body=`<p>Especialização da classe <b>${player.cls}</b> — disponível no nível 30. Bônus único: +12 ATQ, +6 DEF e +50 HP.</p>${btn(e.specializations[player.cls]?'Já desbloqueada':'Especializar','expansionSpecialize')}<p>Títulos conquistados: ${e.titles.guardian?'Guardião Vencido · ':''}${e.titles.dragon?'Lenda do Dragão':''}${!e.titles.guardian&&!e.titles.dragon?'Ainda nenhum':''}</p><p class="small">O reino 10 mantém seu desfecho original; os desafios avançados continuam nas masmorras e nas caçadas.</p>`}
else if(type==='expansionMarket'){title='Mercado de Trocas';body=`<p>Venda equipamentos extras por 35% do preço original. Ouro: ${player.gold}</p>`+player.inventory.filter(i=>gearCatalog[i.id]&&gearCatalog[i.id].price>0).map(i=>`<div class="item"><div class="grow">${i.name} (${i.count})</div>${btn('Vender · '+Math.round(gearCatalog[i.id].price*.35)+' ouro','expansionSell:'+i.id)}</div>`).join('')}
else if(type==='expansionPet'){title='Poder do Companheiro';const e=expansion();body=`<p>Companheiro: <b>${adventure.companion||'Nenhum'}</b></p><p>Habilidade especial: cura, escudo, mana ou ataque conforme o pet. Recarga: ${Math.ceil(e.petPowerCD)} segundos.</p>${btn('Ativar poder','expansionPetPower')}`}
else if(type==='expansionChest'){title='Baús Misteriosos';body=`<p>Baús podem cair de monstros e chefes. Eles concedem ouro, fragmentos e chance de equipamento.</p>`+player.inventory.filter(i=>i.id.startsWith('treasure')).map(i=>`<div class="item"><div class="grow">${i.name} (${i.count})</div>${btn('Abrir','expansionOpenChest:'+i.id)}</div>`).join('')}
else if(type==='settings'){title='Configurações';body=`<div class="setting">Tamanho dos controles <input type="range" id="sScale" min="70" max="130" value="${settings.scale}"></div><div class="setting">Transparência do HUD <input type="range" id="sOpacity" min="35" max="100" value="${settings.opacity}"></div><div class="setting">Partículas <input type="checkbox" id="sParticles" ${settings.particles?'checked':''}></div><div class="setting">Tremor de câmera <input type="checkbox" id="sShake" ${settings.shake?'checked':''}></div><div class="setting">Minimapa <input type="checkbox" id="sMinimap" ${settings.minimap?'checked':''}></div><div class="setting">Salvamento automático <input type="checkbox" id="sAutosave" ${settings.autosave?'checked':''}></div><div class="setting">Qualidade <select id="sQuality"><option value="high">Alta</option><option value="low">Econômica</option></select></div><div class="setting">Dificuldade <select id="sDifficulty"><option value="easy">Fácil</option><option value="normal">Normal</option><option value="hard">Difícil</option><option value="nightmare">Pesadelo</option><option value="impossible">Impossível</option></select></div><div class="setting">Volume (sons futuros) <input type="range" id="sVolume" min="0" max="100" value="${settings.volume}"></div><section class="eldoriaOrientationPanel"><div class="eldoriaOrientationHeader"><span class="eldoriaOrientationGlyph">▣</span><div><strong>ORIENTAÇÃO DA TELA</strong><small>Explore Eldoria com uma visão mais ampla</small></div></div><button type="button" class="eldoriaOrientationButton" id="settingsRotateBtn"><span class="eldoriaPhoneScene" aria-hidden="true"><span class="eldoriaPhoneGlow"></span><span class="eldoriaPhoneDevice"><i class="eldoriaPhoneSpeaker"></i><i class="eldoriaPhoneScreen">✦</i><i class="eldoriaPhoneHome"></i></span><span class="eldoriaPhoneOrbit">↻</span></span><span><b>GIRAR PARA HORIZONTAL</b><small>Ativar tela cheia e tentar girar</small></span><span class="eldoriaOrientationArrow">↻</span></button><p id="settingsRotateStatus" class="eldoriaOrientationStatus">A rotação depende das permissões do seu navegador.</p></section><div class="row">${btn('Restaurar padrões','reset')}${btn('Salvar e fechar','saveSettings')}</div><p class="small">A orientação horizontal depende da permissão do navegador. O volume está reservado para a futura trilha sonora.</p>`}
else if(type==='inventory'){title='Mochila e Equipamentos';ensureEquipment();const bonus=gearStats();body=`<div class="quick-potion-panel"><b>ATALHOS DE POÇÕES</b><p class="small">Toque em Equipar 1 ou Equipar 2 ao lado de uma poção. Use os dois botões na tela durante o combate.</p><div class="row">${player.quickPotions.map((id,i)=>`<span class="quick-slot">${i+1}: ${POTION_NAMES[id]||'Vazio'} · ${player.inventory.find(v=>v.id===id)?.count||0} un.</span>`).join('')}</div></div><p>Ouro: <b>${player.gold}</b> · Bônus equipados: <b>+${bonus.atk} ataque · +${bonus.def} defesa · +${bonus.agility} agilidade</b></p>`+player.inventory.map(i=>{const g=gearCatalog[i.id],equipped=g&&player.equipment[g.slot]===i.id,stats=g?[['ATQ',g.atk],['DEF',g.def],['AGI',g.agility]].filter(v=>v[1]).map(v=>'+'+v[1]+' '+v[0]).join(' · '):'';return `<div class="item"><span>${itemIcon(i.id)}</span><div class="grow"><b>${i.name}</b><div class="small">${rarity[i.rarity]||'Comum'} · ${i.count} un. ${stats?'· '+stats:''} ${equipped?'· EQUIPADO':''}</div>${g?compareGear(i.id):''}</div>${POTION_NAMES[i.id]?`<div class="quick-equip-actions"><button data-act="quickEquip:0:${i.id}" ${player.quickPotions[0]===i.id?'disabled':''}>${player.quickPotions[0]===i.id?'No 1':'Equipar 1'}</button><button data-act="quickEquip:1:${i.id}" ${player.quickPotions[1]===i.id?'disabled':''}>${player.quickPotions[1]===i.id?'No 2':'Equipar 2'}</button><button data-use="${i.id}">Usar</button></div>`:`<button data-use="${i.id}">${g?(equipped?'Equipado':'Equipar'):'Guardar'}</button>`}</div>`}).join('')+`<div class="row">${btn('Atributos','stats')}${btn('Ferreiro','smith')}${btn('Missões','quests')}${btn('Baús','expansionChest')}</div>`}
else if(type==='quests'){title='Missões do Reino';const r=realmInfo(),stage=realmQuestStage[realmIndex]||0,quests=questsForRealm();body=`<p><b>${r.name}</b> · Povo: ${r.race} · ${stage}/7 missões concluídas</p>`+quests.map((q,i)=>{const prog=Math.min(q.need,questProgress(q));const status=i<stage?'✓ Concluída':i>stage?'🔒 Bloqueada':`${prog}/${q.need}`;return `<div class="item" style="opacity:${i>stage?.55:1}"><div class="grow"><b>${i+1}. ${q.title}</b><p>${q.description} · ${status}</p></div>${i===stage&&prog>=q.need?btn('Resgatar','claimRealm'):''}</div>`}).join('')+`<p class="small">${realmRewards[realmIndex]?'Portal liberado!':'Conclua as sete missões em ordem para liberar o próximo portal.'}</p>`}
else if(type==='talents'){title='Árvore de Talentos';body=`<p>Classe: <b>${player.cls}</b> · Pontos disponíveis: <b>${adventure.points}</b></p>`+talents[player.cls].map(t=>`<div class="item"><div class="grow"><b>✦ ${t.name}</b><div class="small">${t.desc} · ${talentLevel(t.id)}/${t.max}</div></div><button data-act="talent:${t.id}" ${adventure.points<=0||talentLevel(t.id)>=t.max?'disabled':''}>Evoluir</button></div>`).join('')+'<p class="small">Ganhe um ponto de talento a cada nível alcançado.</p>'}
else if(type==='companion'){title='Companheiros e Evolução';migratePets();const pet=petProgress(),stage=pet?petStage(pet.level):0;const petName=adventure.companion;body=`<div class="pet-hero"><b>✦ EVOLUÇÃO DOS COMPANHEIROS</b><p>As formas mudam nos níveis <strong>4 · 8 · 12</strong>. A transformação secreta <strong>LENDÁRIA</strong> é desbloqueada no nível <strong>16</strong>.</p>${pet?`<div class="pet-stage-banner">${petName} · ${petForm(pet.level)} · NV ${pet.level}/16</div><div class="pet-xp-track"><i style="width:${pet.level===16?100:Math.round(pet.xp/petNeed(pet.level)*100)}%"></i></div><small>Experiência ${pet.level===16?'MÁXIMA':pet.xp+' / '+petNeed(pet.level)} · Próxima evolução: ${pet.level<4?'NV 4':pet.level<8?'NV 8':pet.level<12?'NV 12':pet.level<16?'NV 16':'Completa'}</small>`:'<p>Adote um companheiro para começar sua jornada.</p>'}</div><p class="small">Cada pet possui uma função estratégica. O preço é pago uma vez e a evolução de cada pet é salva.</p><div class="pet-rank-grid">${PET_RANKS.map(p=>{const lv=adventure.petProgress?.[p.name]?.level||1;const owned=adventure.ownedPets?.[p.name];return `<div class="pet-rank-card ${adventure.companion===p.name?'selected':''}" style="--pet-accent:${p.color}"><div class="pet-rank-head"><span>#${p.rank}</span><span class="pet-rank-icon">${p.icon}</span></div><b>${p.name}</b><div class="small">${PET_ROLES[p.name]?.desc||"Companheiro"}</div><div class="small">${petForm(lv)} · NV ${lv}/16</div><div class="pet-form-steps"><span class="${lv>=4?'done':''}">4</span><span class="${lv>=8?'done':''}">8</span><span class="${lv>=12?'done':''}">12</span><span class="${lv>=16?'done':''}">★16</span></div>${btn(adventure.companion===p.name?'Em equipe':owned?'Equipar':'Adotar · '+p.price+' ouro','pet:'+p.name)}</div>`}).join('')}</div>${petName!=='none'?btn('Deixar pet descansar','recruit'):''}`}
else if(type==='dungeon'){title=dungeonTitles[realmIndex];body=dungeonSession?`<p>Você está no labirinto. Selos: ${dungeonSession.switches.filter(x=>x.lit).length}/3.</p><p>Explore as passagens, ative os selos e enfrente o chefe. Volte ao início para sair.</p>${btn('Continuar exploração','close')}`:`<p>Entrada ao sul do reino, X:26, Y:32.</p><p>Uma masmorra exclusiva com labirinto, três selos rúnicos e um chefe de enorme resistência. Derrote-o para receber uma recompensa especial.</p><p>${adventure.dungeons[realmIndex]?'Concluída neste reino!':'Ainda não concluída.'}</p>${btn('Entrar na masmorra','enterDungeon')}`}
else if(type==='achievements'){title='Conquistas';const all=[['friend','Primeiro companheiro'],['traveler','Primeira travessia'],['halfway','Cinco reinos explorados'],['veteran','Veterano de Eldoria'],['dungeon','Explorador de masmorras'],['dragon','Lenda dos Dez Reinos']];body=all.map(([id,label])=>`<div class="item"><span>${adventure.achievements[id]?'🏆':'🔒'}</span><div class="grow">${label}</div><b>${adventure.achievements[id]?'Concluída':'Pendente'}</b></div>`).join('')}
else if(type==='shop'){title='Mercado de Equipamentos';ensureEquipment();const entries=[...['potion','ether','elixir','tonic'].map(id=>({id,name:({potion:'Poção de Vida',ether:'Poção de Mana',elixir:'Elixir Maior',tonic:'Tônico de Energia'})[id],price:({potion:20,ether:22,elixir:95,tonic:40})[id]})),...Object.entries(gearCatalog).filter(([id,g])=>g.price>0&&(!g.cls||g.cls===player.cls)).map(([id,g])=>({id,...g}))];body=`<p>Seu ouro: <b>${player.gold}</b> · Armas da classe ${player.cls} e equipamentos gerais.</p>`+entries.map(g=>`<div class="item"><span>${itemIcon(g.id)}</span><div class="grow"><b>${g.name}</b><div class="small">${[['ATQ',g.atk],['DEF',g.def],['AGI',g.agility]].filter(v=>v[1]).map(v=>'+'+v[1]+' '+v[0]).join(' · ')||'Consumível'} · ${g.price} ouro</div></div><button data-act="buy:${g.id}" ${player.gold<g.price?'disabled':''}>Comprar</button></div>`).join('')}
else if(type==='smith'){title='Ferreiro — Oficina de Equipamentos';ensureEquipment();const gs=gearStats();const slotList=Object.entries(FORGE_SLOTS).map(([slot,name])=>{const id=player.equipment[slot],g=gearCatalog[id],lv=forgeSlotLevel(slot),cost=forgeSlotCost(slot),ore=forgeSlotMaterials(slot),stat=slot==='weapon'?'+2 ATQ':slot==='ring'?'+1 ATQ':slot==='boots'?'+2 DEF / +1 AGI':'+2 DEF',available=!!g&&lv<15&&player.gold>=cost&&player.forgeMaterials>=ore;return `<div class="item" style="align-items:center;gap:12px"><span style="font-size:24px">${itemIcon(id||slot)}</span><div class="grow"><b>${name} ${g?'+'+lv:'— vazio'}</b><div class="small">${g?g.name:'Equipe um item pela mochila'} · ${stat} por melhoria</div><div class="small">${lv>=15?'Nível máximo':cost+' ouro'+(ore?' + '+ore+' fragmento(s)':'')} · máximo +15</div></div><button data-act="forgeSlot:${slot}" ${available?'':'disabled'}>Aprimorar</button></div>`}).join('');const salvage=player.inventory.filter(i=>gearCatalog[i.id]&&gearCatalog[i.id].price>0&&(player.equipment[gearCatalog[i.id].slot]!==i.id||i.count>1)).map(i=>`<div class="item"><span>${itemIcon(i.id)}</span><div class="grow"><b>${gearCatalog[i.id].name}</b><div class="small">${i.count} unidade(s) · +${Math.max(1,gearCatalog[i.id].rarity-1)} fragmentos</div></div><button data-act="dismantle:${i.id}">Desmontar 1</button></div>`).join('');body=`<div class="forgeSummary"><b>OFICINA DO FERREIRO</b><p>Ouro: <b>${player.gold}</b> · Fragmentos: <b>${player.forgeMaterials}</b></p><p>Seus bônus: <b>+${gs.atk} ATQ · +${gs.def} DEF · +${gs.agility} AGI</b></p><p class="small">Legado da antiga forja: +${player.forgeLevel*2} ATQ permanente, preservado.</p></div><h3>Aprimorar equipamentos</h3><p class="small">Cada espaço tem seu próprio nível de forja. Trocar de item mantém o nível do espaço. Custos crescem gradualmente e exigem fragmentos em níveis altos.</p>${slotList}<h3>Reciclar equipamentos</h3><p class="small">Desmonte itens extras para obter fragmentos e recuperar um pouco de ouro. Seu último equipamento equipado fica protegido.</p>${salvage||'<p class="small">Sem equipamentos extras para desmontar.</p>'}<div class="row">${btn('Abrir mochila','inventory')}${btn('Visitar mercado','shop')}</div>`}
else if(type==='mentor'){title='Mestre Rowan';body=`<p>“${realmInfo().race} precisam da sua ajuda. Conclua as sete missões do diário e avance pelo portal!”</p>${btn('Ver missões','quests')}${btn('Atributos','stats')}`}
else if(type==='stats'){title='Atributos';body=`<p>${player.name} · ${player.cls} · Nível ${player.level}</p><p>Vida ${Math.ceil(player.hp)}/${player.maxHp} · Mana ${Math.ceil(player.mp)}/${player.maxMp}</p><p>Pontos livres: <b>${player.statPoints}</b></p><div class="item"><div class="grow">Força: ${player.atk}</div>${btn('+2','forca')}</div><div class="item"><div class="grow">Defesa: ${player.def}</div>${btn('+2','defesa')}</div><div class="item"><div class="grow">Agilidade: ${player.agility}</div>${btn('+2','agilidade')}</div><div class="item"><div class="grow"><b>Recuperação de Vida: ${player.regenLevel||0}/5</b><div class="small">Recupera ${player.regenLevel||0} HP a cada 5 segundos, até o nível máximo 5.</div></div>${(player.regenLevel||0)>=5?'<button disabled>Máximo</button>':btn('+1','regen')}</div>`+[['critical','Crítico','+3% de chance por nível'],['block','Bloqueio','+3% de chance por nível'],['evade','Esquiva','+2% de chance por nível'],['manaRegen','Recuperação de MP','+0,3 MP por segundo por nível'],['lifesteal','Roubo de Vida','+1% do dano por nível']].map(([id,name,desc])=>`<div class="item"><div class="grow"><b>${name}: ${(player.combatStats?.[id]||0)}/5</b><div class="small">${desc}</div></div>${(player.combatStats?.[id]||0)>=5?'<button disabled>Máximo</button>':btn('+1',id)}</div>`).join('') }
else if(type==='map'){title='Mapa de Eldoria';body=`<p>${realmInfo().name} · Portal ao leste do mapa</p><canvas id="bigmap" width="480" height="300" style="max-width:100%;height:auto;background:#0b2430;border-radius:10px"></canvas><p class="small">Ponto dourado: você · Vermelho: inimigos · Azul: moradores · Masmorra ao sul</p>`}
else if(type==='pause'){title='Menu da Aventura';body=`<div class="adventure-menu-intro">✦ <strong>JORNADA DE ELDORIA</strong><small>Seu destino, seus aliados e suas conquistas</small></div><div class="menuGrid eldoria-menu-grid">${btn('💾 Salvar','save')}${btn('✦ Talentos','talents')}${btn('🏆 Conquistas','achievements')}${btn('✦ Novidades','expansionHub')}${btn('🏠 Menu principal','mainMenu')}</div>`}
else if(type==='help'){title='A História de Eldoria';body=`<img class="eldoriaLoreImg" src="${ELDORIA_LORE_IMAGE}" alt="Castelo de Eldoria iluminado sob a lua, entre montanhas e cachoeiras"><div class="loreText"><p><b>Eldoria</b> nasceu da união entre os antigos reinos, guardiões das florestas, montanhas e fontes de magia. Durante séculos, seus povos viveram em paz, protegidos por portais que ligavam as terras conhecidas.</p><p>Mas a escuridão voltou a despertar. Criaturas esquecidas emergiram das masmorras, antigos chefões retomaram seus domínios e o poder do Dragão do Eclipse ameaça romper o equilíbrio dos dez reinos.</p><p>Agora, um novo aventureiro deve atravessar os portais, conhecer os habitantes, conquistar equipamentos lendários e formar laços com companheiros mágicos. Cada reino esconde uma parte da verdade.</p><p><b>O destino de Eldoria está em suas mãos.</b></p></div>`}
modal(title,body);document.querySelectorAll('[data-act]').forEach(b=>b.onclick=()=>action(b.dataset.act));document.querySelectorAll('[data-use]').forEach(b=>b.onclick=()=>useItem(b.dataset.use));
if(type==='settings'){const rotateButton=$('settingsRotateBtn');if(rotateButton){rotateButton.addEventListener('click',async()=>{const status=$('settingsRotateStatus');rotateButton.disabled=true;if(status)status.textContent='Solicitando tela horizontal...';try{await requestEldoriaLandscape();const horizontal=matchMedia('(orientation:landscape)').matches;if(status)status.textContent=horizontal?'Tela horizontal ativada!':'Se a tela não girou, habilite a rotação automática do celular ou abra o jogo no navegador.'}catch(e){if(status)status.textContent='O navegador não permitiu girar. Ative a rotação do celular.'}finally{rotateButton.disabled=false}})}}
if(type==='settings'){for(const [id,key,event,fn] of [['sScale','scale','input',Number],['sOpacity','opacity','input',Number],['sParticles','particles','change',null],['sShake','shake','change',null],['sMinimap','minimap','change',null],['sAutosave','autosave','change',null],['sQuality','quality','change',String],['sDifficulty','difficulty','change',String],['sVolume','volume','input',Number]]){const el=$(id);if(key==='quality'||key==='difficulty')el.value=settings[key];el.addEventListener(event,()=>{settings[key]=el.type==='checkbox'?el.checked:fn(el.value);settingsSave()})}}
if(type==='map')drawMap($('bigmap').getContext('2d'),480,300);
if(menuType)gameState='menu'}
function action(a){
if(a.startsWith('expansionClaim:')){expansionClaim(a.split(':')[1]);return}
if(a.startsWith('expansionEnchant:')){enchantWeapon(a.split(':')[1]);return}
if(a.startsWith('expansionSell:')){expansionSell(a.split(':')[1]);return}
if(a.startsWith('expansionOpenChest:')){const id=a.split(':')[1],old=realmIndex;const ix=Number(id.slice(8));if(Number.isInteger(ix)&&ix>=0&&ix<classicRealms.length){const item=player.inventory.find(i=>i.id===id&&i.count>0);if(item){item.count--;if(!item.count)player.inventory=player.inventory.filter(v=>v!==item);player.gold+=70+ix*45;player.forgeMaterials+=1+Math.floor(ix/3);toast('Baú aberto! Ouro e fragmentos!');save()}}openModal('expansionChest');return}
if(a==='expansionSpecialize'){expansionSpecialize();return}
if(a==='expansionPetPower'){expansionPetPower();openModal('expansionPet');return}
if(a.startsWith('expansion')&&['expansionHub','expansionQuests','expansionForge','expansionProgress','expansionMarket','expansionPet','expansionChest'].includes(a)){openModal(a);return}
if(a.startsWith('quickEquip:')){const [,slot,id]=a.split(':');equipQuickPotion(Number(slot),id);return}if(a==='npcDecision'){npcDecision();return}if(a.startsWith('choice:')){const choice=a.slice(7);if(!adventure.questChoice[realmIndex]){adventure.questChoice[realmIndex]=choice;if(choice==='guard'){player.maxHp+=12;player.hp+=12;toast('Pacto de proteção: +12 vida máxima!')}else{player.atk+=2;toast('Pacto de caça: +2 ataque!')}save()}else toast('Você já fez sua escolha neste reino.');dialogueNpc=null;closeModal();return}if(a.startsWith('talent:')){const id=a.slice(7),t=talents[player.cls].find(v=>v.id===id);if(t&&adventure.points>0&&talentLevel(id)<t.max){adventure.points--;adventure.talents[id]=talentLevel(id)+1;soundFx('win');save()}openModal('talents');return}if(a.startsWith('pet:')){choosePet(a.slice(4));openModal('companion');return}if(a==='recruit'){recruitCompanion();openModal('companion');return}if(a==='enterDungeon'){closeModal();enterDungeon();return}if(a.startsWith('buy:')){purchase(a.slice(4));return}if(a==='dialogueNext'){dialogueStep++;if(dialogueStep>=npcSpeech().length){dialogueNpc=null;closeModal()}else showNpcDialogue();return}if(a==='dialogueOption'){const role=dialogueNpc?.role;dialogueNpc=null;openModal(role==='shop'?'shop':role==='smith'?'smith':'quests');return}if(a==='close'){closeModal();return}if(a==='saveSettings'){settingsSave();closeModal();toast('Configurações salvas!');return}if(a==='reset'){settings={scale:100,opacity:85,particles:true,shake:true,quality:'high',difficulty:'normal',volume:50,minimap:true,autosave:true};settingsSave();openModal('settings');return}if(a==='fullscreen'){const el=document.documentElement;if(!document.fullscreenElement)el.requestFullscreen?.().then(()=>screen.orientation?.lock?.('landscape').catch(()=>{})).catch(()=>toast('Tela cheia indisponível neste navegador'));else document.exitFullscreen?.();return}if(a==='mainMenu'){save();closeModal();menuPage();return}if(a==='save'){save();toast('Progresso salvo!');return}if(a==='claimRealm'){completeRealmQuest();openModal('quests');return}if(a==='claimQuest'){if(player.questKills<8)return;player.questKills-=8;player.gold+=90;const questXP=Math.round(70*(1+realmIndex*.28));player.xp+=questXP;toast('Missão concluída! +90 ouro e +'+questXP+' XP');save();openModal('quests');return}if(a==='buyPotion'||a==='buyEther'){buy(a==='buyPotion'?'potion':'ether',a==='buyPotion'?20:22);return}if(a.startsWith('forgeSlot:')){forgeUpgrade(a.slice(10));return}if(a.startsWith('dismantle:')){forgeDismantle(a.slice(10));return}if(a==='forge'){const cost=forgeCost();if(player.gold<cost){toast('Ouro insuficiente!');return}player.gold-=cost;player.forgeLevel++;toast('Forja nível '+player.forgeLevel+'! +2 de ataque');save();openModal('smith');return}if(['forca','defesa','agilidade','regen','critical','block','evade','manaRegen','lifesteal'].includes(a)){upgrade(a);return}openModal(a)}
function updateHUD(){refreshQuickPotions();if(!player)return;const hpBar=$('hpbar');if(hpBar)hpBar.style.filter=(player.damageFlash||0)>0?'brightness(1.8) saturate(1.5)':'none';$('hname').textContent=`${player.name.toUpperCase()} · NV ${player.level}`;$('hclass').textContent=`${player.cls} · ${gearCatalog[player.weapon]?.name||'Arma'}`;$('hpbar').style.width=100*player.hp/player.maxHp+'%';$('mpbar').style.width=100*player.mp/player.maxMp+'%';$('xpbar').style.width=100*player.xp/(player.level*65)+'%';$('hstat').textContent=`🪙 ${player.gold.toLocaleString('pt-BR')} · ${realmInfo().name}`;$('hudHpText').textContent=`HP ${Math.ceil(player.hp)} / ${Math.ceil(player.maxHp)}`;$('hudMpText').textContent=`MP ${Math.ceil(player.mp)} / ${Math.ceil(player.maxMp)}`;$('hudXpText').textContent=`NV ${player.level} · XP ${Math.floor(player.xp)} / ${player.level*65}`;$('quickStats').textContent=player.statPoints>0?`⚔ ATRIBUTOS · +${player.statPoints} PONTOS`:'⚔ ATRIBUTOS';let boss=enemies.find(e=>e.elite&&e.hp>0);$('boss').style.display=boss&&dist(player,boss)<11?'block':'none';if(boss){$('bossname').textContent=eldoriaBossDef(boss).name;$('bosslife').style.width=100*boss.hp/boss.maxHp+'%';$('bosslife').style.background='linear-gradient(90deg,'+eldoriaBossDef(boss).color+','+eldoriaBossDef(boss).glow+')';$('boss').style.borderColor=eldoriaBossDef(boss).glow}}
function tick(dt){if(!player||gameState!=='playing'||modalOpen)return;gameTime+=dt;for(let i=classVfx.length-1;i>=0;i--){classVfx[i].age+=dt;if(classVfx[i].age>=classVfx[i].life)classVfx.splice(i,1)}expansionTick(dt);adventure.weather=weatherForRealm();adventure.dayPhase=(Math.sin(gameTime/85)+1)/2;if(player.x>35)questStats().explored=true;autoSave+=dt;if(autoSave>15){autoSave=0;if(settings.autosave)save()}if(!dungeonSession&&realmIndex!==9&&!bossSpawned&&gameTime>100&&player.x>22){bossSpawned=true;enemies.push(makeEnemy(35.5,20.5,'Guardião'));toast('O Guardião das Ruínas despertou!')}v16WorldEvents(dt);if(realmIndex!==regionNotice){regionNotice=realmIndex;toast(`${realmInfo().name} · Nível recomendado ${realmInfo().level} · Perigo +${Math.round(realmIndex*24)}%`)}
player.isWalking=false;let dx=joy.x+(keys['d']||keys['arrowright']?1:0)-(keys['a']||keys['arrowleft']?1:0),dy=joy.y+(keys['s']||keys['arrowdown']?1:0)-(keys['w']||keys['arrowup']?1:0),mag=Math.hypot(dx,dy);if(mag>.05){dx/=Math.max(1,mag);dy/=Math.max(1,mag);const speed=(player.dash>0?9:3.9+talentLevel('swift')*.28+talentLevel('silent')*.13)*dt;move(player,dx*speed,dy*speed);player.anim+=dt*11;player.isWalking=true;if(Math.abs(dx)>Math.abs(dy))player.dir=dx>0?3:1;else player.dir=dy>0?0:2}player.attackCD=Math.max(0,player.attackCD-dt);player.skillCD=Math.max(0,player.skillCD-dt);player.berserkTime=Math.max(0,(player.berserkTime||0)-dt);player.attackAnim=Math.max(0,player.attackAnim-dt);player.castAnim=Math.max(0,player.castAnim-dt);player.dash=Math.max(0,player.dash-dt);player.invuln=Math.max(0,player.invuln-dt);player.hit=Math.max(0,player.hit-dt);player.damageFlash=Math.max(0,(player.damageFlash||0)-dt);player.mp=Math.min(player.maxMp,player.mp+dt*(.7+talentLevel('mana')*.25+(player.combatStats?.manaRegen||0)*.3));if((player.regenLevel||0)>0&&player.hp>0&&player.hp<player.maxHp){player.regenClock=(player.regenClock||0)+dt;if(player.regenClock>=5){const pulses=Math.floor(player.regenClock/5);player.regenClock-=pulses*5;player.hp=Math.min(player.maxHp,player.hp+pulses*Math.min(5,player.regenLevel));}}else player.regenClock=0;player.stamina=Math.min(100,player.stamina+dt*8);

if(adventure.companion!=='none'){
 adventure.companionCD=Math.max(0,(adventure.companionCD||0)-dt);
 if(adventure.companionCD<=0){
  const name=adventure.companion,pet=petProgress(),lv=pet?.level||1;
  const cfg=PET_ROLES[name]||PET_ROLES['Lobo Guardião'];
  const foe=enemies.filter(e=>e.hp>0&&dist(player,e)<5).sort((a,b)=>dist(player,a)-dist(player,b))[0];
  const hurt=player.hp<player.maxHp,lowMana=player.mp<player.maxMp;
  if(foe||((cfg.role==='cura'||cfg.role==='defesa')&&hurt)||((cfg.role==='mana'||cfg.role==='hibrido')&&lowMana)){
   const power=5+Math.min(player.level,70)*.42+lv*1.15;
   let dealt=0;
   if(foe&&cfg.damage>0){dealt=Math.max(2,Math.round(power*cfg.damage));damage(foe,dealt);effect(foe.x,foe.y,cfg.color,7)}
   if(name==='Fada da Luz'){
    const heal=Math.round(5+lv*.65);player.hp=Math.min(player.maxHp,player.hp+heal);effect(player.x,player.y,'#ffeb9c',8);
   }else if(name==='Fênix Jovem'){
    player.hp=Math.min(player.maxHp,player.hp+Math.round(2+lv*.35));
   }else if(name==='Golem Miniatura'){
    adventure.petGuard=Math.min(28,8+lv*1.15);adventure.petGuardTime=4;effect(player.x,player.y,'#bdc4ca',9);
   }else if(name==='Coruja Lunar'){
    player.mp=Math.min(player.maxMp,player.mp+Math.round(7+lv*.7));effect(player.x,player.y,'#d9f4ff',6);
   }else if(name==='Raposa Mística'){
    player.mp=Math.min(player.maxMp,player.mp+Math.round(2+lv*.25));
   }else if(name==='Tigre de Gelo'&&foe){
    foe.attack=Math.max(foe.attack||0,.65+lv*.035);effect(foe.x,foe.y,'#9de8ff',10);
   }
   petGain(1);adventure.companionCD=cfg.cooldown;
  }
 }
}
adventure.petGuardTime=Math.max(0,(adventure.petGuardTime||0)-dt);
if(adventure.petGuardTime<=0)adventure.petGuard=0;
const activeBoss=enemies.find(e=>e.elite&&e.hp>0&&!e.dungeon);
const bossArena=!!activeBoss&&dist(player,activeBoss)<10;
for(const e of enemies){if(e.hp<=0)continue;if(!e.elite&&dist(player,e)>19){e.attack=Math.max(0,e.attack-dt);continue;}
if(bossArena&&!e.elite){const away=Math.hypot(e.x-activeBoss.x,e.y-activeBoss.y);if(away<8.5){const dx=e.x-activeBoss.x,dy=e.y-activeBoss.y,len=Math.max(.01,Math.hypot(dx,dy));move(e,dx/len*dt*2.5,dy/len*dt*2.5);}continue;}
if(e.elite){
const nextPhase=e.hp/e.maxHp<=.33?3:e.hp/e.maxHp<=.67?2:1;
if(nextPhase>e.phaseLevel){e.phaseLevel=nextPhase;e.speed*=1.13;effect(e.x,e.y,eldoriaBossDef(e).glow,32);toast(e.type==='Dragão'?'O DRAGÃO ENTROU NA FASE '+nextPhase+'!':'O chefe ficou enfurecido!');if(settings.shake)screenShake=.22}
e.specialTimer-=dt;e.recovery=Math.max(0,(e.recovery||0)-dt);
if(e.specialTimer<=0&&e.charge<=0&&dist(player,e)<9){e.charge=e.phaseLevel>=3?1.18:e.phaseLevel===2?1.5:1.85;e.attackPattern=(e.attackPattern+1)%(e.dungeon||e.type==='Dragão'?5:3);e.warningX=e.attackPattern===1?player.x:e.x;e.warningY=e.attackPattern===1?player.y:e.y;e.attackAngle=Math.atan2(player.y-e.y,player.x-e.x);e.recovery=0;e.specialTimer=Math.max(1.85,(e.type==='Dragão'?5.2:7)-e.phaseLevel*.85);toast(e.attackPattern===0?eldoriaBossDef(e).skill+'! Afaste-se!':e.attackPattern===1?'METEORO MARCADO! Saia da área!':e.attackPattern===2?'RAJADA FRONTAL! Saia da linha!':e.attackPattern===3?'ANEL EXPLOSIVO! Fique perto ou longe!':'CRUZ ARCANA! Evite os eixos!')}
if(e.charge>0){e.charge-=dt;if(e.charge<=0){e.recovery=.85;const radius=e.type==='Dragão'?3.3:2.3;const bossVisual=eldoriaBossDef(e);effect(e.x,e.y,bossVisual.glow,Math.min(40,16+e.phaseLevel*8));e.animStrike=.75;e.bossPulse=1;
if((e.attackPattern===0?Math.hypot(player.x-e.x,player.y-e.y)<radius:e.attackPattern===1?Math.hypot(player.x-e.warningX,player.y-e.warningY)<radius:e.attackPattern===3?(Math.hypot(player.x-e.x,player.y-e.y)>1.8&&Math.hypot(player.x-e.x,player.y-e.y)<4.5):e.attackPattern===4?(Math.abs(player.x-e.x)<.85||Math.abs(player.y-e.y)<.85):((player.x-e.x)*Math.cos(e.attackAngle)+(player.y-e.y)*Math.sin(e.attackAngle)>0&&((player.x-e.x)*Math.cos(e.attackAngle)+(player.y-e.y)*Math.sin(e.attackAngle))<7&&Math.abs(-(player.x-e.x)*Math.sin(e.attackAngle)+(player.y-e.y)*Math.cos(e.attackAngle))<.85))&&player.invuln<=0){receiveHit((e.type==='Dragão'?170:95)+realmIndex*8);}}}
}
e.bossPulse=Math.max(0,(e.bossPulse||0)-dt*2);e.hit=Math.max(0,e.hit-dt);e.critFlash=Math.max(0,(e.critFlash||0)-dt);e.attack-=dt;e.phase+=dt*(e.type==='Morcego'?10:e.type==='Aranha'?7:e.type==='Lobo'?7:5);e.aiClock=(e.aiClock||0)+dt;e.walkAnim=(e.walkAnim||0)+dt*7;e.animStrike=Math.max(0,(e.animStrike||0)-dt);
let d=dist(player,e);
// IA 18.5: estados estáveis, direção suavizada e separação entre inimigos.
if(!e.elite){
 const hpRatio=e.hp/Math.max(1,e.maxHp);
 if(hpRatio<=.23&&!e.fleeing){e.fleeing=true;e.fleeTimer=4.5;}
 if(e.fleeing){e.fleeTimer=Math.max(0,(e.fleeTimer||0)-dt);if(e.fleeTimer===0&&hpRatio>.40)e.fleeing=false;}
}
if(e.charge<=0&&e.recovery<=0&&d<(e.type==='Fantasma'?9:7.8)){
 const ranged=['Fantasma','Morcego'].includes(e.type);
 const preferred=e.elite?1.22:ranged?2.25:e.type==='Esqueleto'?1.05:.80;
 const enter=preferred+.43,leave=preferred-.35;
 let state=e.aiState||'approach';
 if(e.fleeing)state=d>6.5?'hold':'retreat';
 else if(state==='approach'&&d<=enter)state='hold';
 else if(state==='retreat'&&d>=preferred+.18)state='hold';
 else if(state==='hold'&&d>enter+.45)state='approach';
 else if(state==='hold'&&ranged&&d<leave)state='retreat';
 else if(state==='hold'&&!ranged&&d<.46)state='retreat';
 e.aiState=state;
 const sign=state==='approach'?1:state==='retreat'?-1:0;
 let tx=0,ty=0;
 if(sign&&d>.01){tx=(player.x-e.x)/d*sign;ty=(player.y-e.y)/d*sign;}
 // Evita que vários inimigos ocupem exatamente o mesmo espaço.
 let sx=0,sy=0;
 for(const other of enemies){if(other===e||other.hp<=0||other.elite)continue;const ox=e.x-other.x,oy=e.y-other.y,ds=ox*ox+oy*oy;if(ds>.0001&&ds<.85*.85){const f=(.85-Math.sqrt(ds))/.85;sx+=ox/Math.sqrt(ds)*f;sy+=oy/Math.sqrt(ds)*f;}}
 tx+=sx*.65;ty+=sy*.65;
 const len=Math.hypot(tx,ty);if(len>1){tx/=len;ty/=len;}
 // Inércia evita que a direção se inverta em cada quadro.
 const blend=Math.min(1,dt*5.5);
 e.steerX=(e.steerX||0)+(tx-(e.steerX||0))*blend;
 e.steerY=(e.steerY||0)+(ty-(e.steerY||0))*blend;
 let vx=e.steerX,vy=e.steerY;
 const speed=e.speed*dt*(adventure.dayPhase>.72?1.08:1);
 if(Math.hypot(vx,vy)>.025){
   // Primeiro tenta avançar; se bloqueado, desliza nos eixos antes de contornar.
   const nx=e.x+vx*speed,ny=e.y+vy*speed;
   if(passable(nx,ny,.16))move(e,vx*speed,vy*speed);
   else if(passable(nx,e.y,.16))move(e,vx*speed,0);
   else if(passable(e.x,ny,.16))move(e,0,vy*speed);
   else{
     if(e.aiSide===undefined)e.aiSide=(Math.sin(e.x*7+e.y*3)>0?1:-1);
     let ax=-vy*e.aiSide,ay=vx*e.aiSide;
     if(passable(e.x+ax*speed,e.y+ay*speed,.16))move(e,ax*speed,ay*speed);
     else if(passable(e.x-ax*speed,e.y-ay*speed,.16)){e.aiSide*=-1;move(e,-ax*speed,-ay*speed);}
     else{e.steerX*=.5;e.steerY*=.5;}
   }
 }
}
if(!e.fleeing&&e.charge<=0&&e.recovery<=0&&d<(e.type==='Dragão'?2.65:e.elite?2.05:1.65)&&e.attack<=0){
 e.attack=e.type==='Dragão'?.95:e.elite?1.15:e.type==='Morcego'?1.0:1.4;
 e.animStrike=.28;
 if(player.invuln<=0){const base=e.type==='Dragão'?120+realmIndex*8:e.elite?72+realmIndex*6:e.type==='Orc'?39+realmIndex*3:31+realmIndex*3.2;receiveHit(base);}
}
}
for(let i=shots.length-1;i>=0;i--){const s=shots[i];s.x+=s.vx*dt;s.y+=s.vy*dt;s.life-=dt;if(s.life<=0||!passable(s.x,s.y,.05)){effect(s.x,s.y,'#d5f7ff',3);shots.splice(i,1);continue}let hit=false;for(const e of enemies)if(e.hp>0&&dist(s,e)<(e.elite?.65:.43)){damage(e,s.dmg);hit=true;break}if(hit){effect(s.x,s.y,s.type==='arrow'?'#ffe4a8':'#8bdfff',8);shots.splice(i,1)}}
for(let i=particles.length-1;i>=0;i--){let p=particles[i];p.x+=p.vx*dt;p.y+=p.vy*dt;p.life-=dt;if(p.life<=0)particles.splice(i,1)}enemies=enemies.filter(e=>e.hp>0);if(shots.length>90)shots.splice(0,shots.length-90);if(!bossArena&&enemies.length<Math.round(30*v16Balance().spawn)&&Math.random()<dt*(.85+realmIndex*.065)*v16Balance().spawn){let x=12+Math.random()*44,y=4+Math.random()*34;if(passable(x,y)&&Math.hypot(x-player.x,y-player.y)>8)enemies.push(makeEnemy(x,y,realmInfo().mobs[Math.floor(Math.random()*realmInfo().mobs.length)]))}updateHUD()}
function resize(){const dpr=Math.min(devicePixelRatio||1,settings.quality==='low'?1:(matchMedia('(pointer:coarse)').matches?1.1:1.35));cv.width=Math.floor(innerWidth*dpr);cv.height=Math.floor(innerHeight*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);ctx.imageSmoothingEnabled=false}
function rect(x,y,w,h,c){ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),Math.ceil(w),Math.ceil(h))}
function circle(x,y,r,c){ctx.fillStyle=c;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill()}

// ELDORIA 16.1 — VISUAIS ORIGINAIS: sprites vetoriais pixelados desenhados no Canvas.
// Os dez reinos possuem chefes com silhueta, paleta e poderes diferentes.
const ELDORIA_BOSSES=[
 {name:'REI DAS RAÍZES',kind:'treant',color:'#68b56b',glow:'#b7ff8b',skill:'RAÍZES ESPINHOSAS'},
 {name:'RAINHA ARACNÍDEA',kind:'spider',color:'#9b75d1',glow:'#edb5ff',skill:'TEIA VENENOSA'},
 {name:'SENTINELA DE GELO',kind:'frost',color:'#79cbe5',glow:'#d8ffff',skill:'LANÇAS GLACIAIS'},
 {name:'TITÃ DO DESERTO',kind:'sand',color:'#d7a05c',glow:'#ffe1a0',skill:'TEMPESTADE DE AREIA'},
 {name:'LICH DO CREPÚSCULO',kind:'lich',color:'#b283ef',glow:'#e5b4ff',skill:'CRUZ SOMBRIA'},
 {name:'GOLEM DO TROVÃO',kind:'storm',color:'#6b9fdc',glow:'#a7eaff',skill:'RAIO CELESTIAL'},
 {name:'CAVALEIRO DE SANGUE',kind:'knight',color:'#d56b78',glow:'#ffbdba',skill:'LÂMINA ESCARLATE'},
 {name:'GUARDIÃO DO PÂNTANO',kind:'swamp',color:'#6da785',glow:'#b7f7b5',skill:'ONDA TÓXICA'},
 {name:'FÊNIX ANCESTRAL',kind:'phoenix',color:'#ee9c52',glow:'#ffe28b',skill:'CHUVA DE BRASAS'},
 {name:'DRAGÃO DO ECLIPSE',kind:'dragon',color:'#ce576a',glow:'#ffae78',skill:'CHAMA DO ECLIPSE'}
];
const ELDORIA_MOB_COLORS={Orc:['#608b4a','#b2d476'],Esqueleto:['#c6c8b7','#f7f2d7'],Slime:['#3f9e85','#9dffe1'],Lobo:['#777b86','#d2d4d6'],Aranha:['#6d4b7f','#d1a0f3'],Fantasma:['#6db5c2','#e0ffff'],Demônio:['#b34b56','#ffa37e'],Golem:['#77818c','#c2d7de'],Morcego:['#675c8b','#c5b2ed']};
function eldoriaBossDef(e){return ELDORIA_BOSSES[Math.max(0,Math.min(9,e.bossRealm??realmIndex))]}
function eldoriaPixelCreature(e,x,y,unit){
 const boss=!!e.elite,def=boss?eldoriaBossDef(e):null,colors=boss?[def.color,def.glow]:(ELDORIA_MOB_COLORS[e.type]||['#669a87','#c6e8c5']);
 const scale=Math.max(.58,Math.min(1.18,unit/38))*(boss?(e.type==='Dragão'?1.75:1.45):.84); // Tamanhos limitados para não cobrir o mapa
 const clock=gameTime* (boss?2.7:4.5)+(e.x||0)*.7;
 const bob=Math.sin(clock)*(boss?2.2:1.3);
 const animHit=(e.hit||0)>0,animCast=(e.charge||0)>0,animStrike=(e.attack||0)>.7;
 const px=(a,b,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(a),Math.round(b),Math.ceil(w),Math.ceil(h))};
 ctx.save();ctx.translate(Math.round(x),Math.round(y+bob));
 if(boss){ctx.save();ctx.globalAlpha=.11+.08*Math.sin(clock*2);ctx.fillStyle=def.glow;ctx.beginPath();ctx.ellipse(0,-17,30+Math.sin(clock)*4,38+Math.sin(clock)*4,0,0,Math.PI*2);ctx.fill();ctx.restore()}
 ctx.scale(scale*(animHit?1.09:1),scale*(animHit?.93:1));
 ctx.rotate(animStrike?Math.sin(clock*9)*.045:animCast?Math.sin(clock*6)*.025:Math.sin(clock)*.008);
 ctx.imageSmoothingEnabled=false;
 const main=e.hit>0?'#fff8e0':colors[0],light=colors[1],shadow='#25313d';
 // Cada espécie tem silhueta própria, não apenas recoloração.
 const kind=boss?def.kind:e.type;
 // Animação de espécie: corpo e apêndices acompanham ciclos independentes.
 const beat=Math.sin(clock*2), stride=Math.round(Math.sin(clock*1.7)*3);
 if(kind==='Morcego'){
   // Asa articulada com dois segmentos, orelhas, focinho e olhos vivos.
   const flap=Math.round(Math.sin(clock*2.7)*10);
   px(-26,-24+flap,13,8,main);px(-32,-19+flap,9,7,light);px(-15,-20+Math.round(flap*.45),9,10,main);
   px(13,-24+flap,13,8,main);px(23,-19+flap,9,7,light);px(6,-20+Math.round(flap*.45),9,10,main);
   px(-10,-23,20,19,main);px(-10,-31,7,12,light);px(3,-31,7,12,light);
   px(-7,-18,5,4,'#ff779a');px(2,-18,5,4,'#ff779a');px(-3,-11,6,5,shadow);
   px(-7,-3,5,7,shadow);px(2,-3,5,7,shadow);
 }else if(kind==='Lobo'){
   // Mesmo modelo frontal do pet Lobo Guardião, com paleta de lobo selvagem.
   // Mantém a mesma silhueta e as mesmas proporções, trocando apenas as cores.
   const passo=Math.round(Math.sin(clock*2.2)*2);
   const pelagem='#92745e',orelha='#785e50',rosto='#d5b49a',olho='#f7c46e',pata='#5b493f';
   px(-13,-8,26,19,pelagem);
   px(-11,-21,8,15,orelha);px(3,-21,8,15,orelha);
   px(-9,-9,18,14,rosto);
   px(-7,-4,4,4,olho);px(3,-4,4,4,olho);
   px(-3,2,6,4,'#302923');
   px(-11,9+passo,8,6,pata);px(3,9-passo,8,6,pata);
   px(12,-3+Math.round(Math.sin(clock)*2),9,5,pelagem);
   if(animStrike){px(-4,6,8,3,'#f1e1cc')}
 }else if(kind==='dragon'){
   const flap=Math.round(Math.sin(clock*2.2)*7),jaw=animCast?6:Math.round((Math.sin(clock*1.3)+1)*1.5);
   const bone='#24172f',edge='#48213e',scales=animHit?'#fff1d6':'#9b355a',crest='#ed6a79',glow='#ffcc78';
   // Cauda longa segmentada, com ponta em losango.
   px(-4,5,8,13,bone);px(0,14,8,10,scales);px(5,21,9,7,edge);px(10,26,8,6,crest);
   // Asas gigantes recortadas, dobradas em três juntas de cada lado.
   for(const side of [-1,1]){
     const sx=side<0?-1:1;
     px(sx<0?-42:15,-36+flap,27,9,bone);px(sx<0?-49:23,-32+flap,24,13,scales);
     px(sx<0?-44:25,-20+flap,20,11,edge);px(sx<0?-37:22,-12+flap,14,10,crest);
     px(sx<0?-50:43,-33+flap,7,11,glow);
     px(sx<0?-42:36,-12+flap,8,7,scales);
   }
   // Corpo blindado e peitoral com placas dracônicas.
   px(-17,-29,34,37,bone);px(-14,-31,28,34,scales);
   px(-10,-19,20,9,edge);px(-9,-8,18,9,crest);px(-6,-7,12,5,glow);
   // Patas e garras, sem braços humanos.
   px(-19,-4,10,16,edge);px(9,-4,10,16,edge);
   for(const xx of [-17,-12,11,16])px(xx,9,4,7,glow);
   // Pescoço, focinho alongado e chifres pontudos.
   px(-11,-45,22,21,bone);px(-9,-44,18,22,scales);
   px(-17,-52,8,17,edge);px(9,-52,8,17,edge);
   px(-20,-57,7,12,glow);px(13,-57,7,12,glow);
   px(-12,-39,24,12,edge);px(-9,-37,18,10,crest);
   px(-14,-32,28,11,bone);px(-12,-32,24,8,scales);
   px(-9,-40,6,5,glow);px(3,-40,6,5,glow);
   px(-7,-29+jaw,14,4,bone);px(-5,-25+jaw,10,3,glow);
   if(animCast){px(-5,-23,10,13,'#ff8c4a');px(-9,-14,18,8,'#ffcf67');px(-3,-6,6,10,'#fff1a5')}
 }else if(kind==='phoenix'){
   const flap=Math.round(Math.sin(clock*2.5)*5);
   // Asas recortadas e cabeça de criatura, sem aparência de humano.
   for(const side of [-1,1]){
     px(side<0?-28:11,-28+flap,17,8,main);px(side<0?-34:22,-24+flap,12,7,light);
     px(side<0?-25:14,-16+flap,12,8,main);
   }
   px(-13,-25,26,23,shadow);px(-10,-24,20,22,main);px(-8,-31,16,11,light);
   px(-12,-35,7,10,main);px(5,-35,7,10,main);
   px(-8,-25,5,4,shadow);px(3,-25,5,4,shadow);
   px(-5,-12,10,7,light);px(-4,-5,8,9,main);
   if(kind==='dragon'){px(-13,-39,5,9,'#e7c29d');px(8,-39,5,9,'#e7c29d');px(3,3,6,9,main)}
   else{px(-5,-44,10,12,'#ffe18a');px(-8,4,7,9,'#ffb54e');px(1,4,7,9,'#ffdf70')}
 }else if(['spider','Aranha'].includes(kind)){
   // Aracnídeo visto de cima: abdômen oval atrás, cefalotórax à frente e oito patas articuladas.
   // Apenas pixels retangulares: sem traços arredondados ou formas humanas.
   const crawl=Math.round(Math.sin(clock*2.1)*3),crawl2=Math.round(Math.sin(clock*2.1+Math.PI)*3);
   const shell=main,edge=shadow,shine=light,leg='#43344e';
   // Patas atrás do corpo (quatro de cada lado, três segmentos cada).
   for(let side of [-1,1]){
     for(let i=0;i<4;i++){
       const yy=-25+i*8,phase=(i%2===0?crawl:crawl2);
       const bx=side*11, mx=side*(19+i%2*3),tx=side*(29+(i===0||i===3?3:0));
       px(Math.min(bx,mx),yy+phase,Math.abs(mx-bx)+3,4,leg);
       px(Math.min(mx,tx),yy-6+phase,Math.abs(tx-mx)+3,4,shell);
       px(tx-2,yy-6+phase,4,10,shine);
       px(tx-2,yy+2+phase,4,4,edge);
     }
   }
   // Abdômen largo na parte superior, com borda escura e manchas simétricas.
   px(-13,-36,26,5,edge);px(-17,-31,34,20,edge);px(-14,-33,28,22,shell);
   px(-9,-30,18,5,shine);px(-9,-22,6,5,edge);px(3,-22,6,5,edge);
   px(-5,-15,10,4,shine);
   // Corpo frontal mais estreito, afastado do abdômen.
   px(-10,-12,20,17,edge);px(-8,-11,16,14,shell);
   px(-7,-8,5,5,'#ff6c91');px(2,-8,5,5,'#ff6c91');
   px(-6,-7,2,2,'#fff6dd');px(3,-7,2,2,'#fff6dd');
   px(-4,-2,3,3,'#ff6c91');px(1,-2,3,3,'#ff6c91');
   // Duas quelíceras pontiagudas abaixo dos olhos.
   px(-8,3,5,5,edge);px(3,3,5,5,edge);
   px(-7,6,3,6,'#e8d8c9');px(4,6,3,6,'#e8d8c9');
   if(animCast){px(-2,12,4,5,'#a8ff87');px(-1,17,2,4,'#ddffc2')}
 }else if(['treant','swamp'].includes(kind)){
   px(-10,-24,20,25,main);px(-17,-21,8,20,main);px(9,-21,8,20,main);px(-12,-32,24,13,light);
   px(-16,-36,12,10,main);px(4,-38,13,11,main);px(-6,-20,4,4,'#ffe2a4');px(3,-20,4,4,'#ffe2a4');
   px(-9,1,7,7,shadow);px(2,1,7,7,shadow);
 }else if(['frost','sand','storm','Golem'].includes(kind)){
   const shake=Math.round(Math.sin(clock*1.8)*2);
   px(-14,-23,28,24,shadow);px(-11,-27,22,26,main);
   px(-22,-21+shake,10,17,light);px(12,-21-shake,10,17,light);
   px(-9,-37,18,13,light);px(-7,2,7,9,shadow);px(1,2,7,9,shadow);
   px(-6,-31,4,4,shadow);px(2,-31,4,4,shadow);
   px(-4,-18,8,10,kind==='frost'?'#d9faff':kind==='storm'?'#ffe28c':light);
   if(kind==='frost'){px(-13,-42,6,10,'#e4ffff');px(7,-42,6,10,'#e4ffff')}
   if(kind==='storm'){px(-3,-44,6,13,'#ffe17a')}
   if(kind==='sand'){px(-12,-40,24,5,'#e9ca8d')}
 }else if(['lich','knight','Esqueleto','Demônio','Orc'].includes(kind)){
   const step=Math.round(Math.sin(clock*1.7)*2);
   const skull=kind==='Esqueleto'?'#e7e4d4':light;
   px(-11,-24,22,25,shadow);px(-9,-23,18,23,main);
   px(-15,-21+step,6,16,light);px(9,-21-step,6,16,light);
   px(-9,-35,18,14,skull);px(-8,2+step,7,8,shadow);px(1,2-step,7,8,shadow);
   px(-6,-29,4,5,kind==='lich'?'#f3a4ff':shadow);px(2,-29,4,5,kind==='lich'?'#f3a4ff':shadow);
   if(kind==='Esqueleto'){px(-4,-22,8,3,shadow);px(-7,-12,14,3,skull);px(-4,-9,8,3,shadow)}
   if(kind==='knight'){px(-12,-40,24,7,main);px(-3,-43,6,6,light);px(13,-29,5,30,'#dce2e5');px(11,-33,9,6,'#fff1b3')}
   if(kind==='lich'){px(-13,-39,26,7,shadow);px(-3,-45,6,8,'#e2adff');px(13,-29,4,31,'#b59aff');px(11,-34,8,8,'#ebc2ff')}
   if(kind==='Orc'){px(-14,-30,6,8,main);px(8,-30,6,8,main);px(-6,-19,4,4,'#f5e6c1');px(2,-19,4,4,'#f5e6c1')}
   if(kind==='Demônio'){px(-12,-40,7,12,light);px(5,-40,7,12,light);px(-4,-17,8,7,'#ffb48d')}
 }else if(kind==='Slime'){
   px(-11,-15,22,16,main);px(-8,-20,16,6,light);px(-6,-12,4,4,shadow);px(3,-12,4,4,shadow);
 }else if(kind==='Fantasma'){
   // Espírito clássico em pixel art: cabeça arredondada em degraus,
   // corpo de lençol e borda inferior ondulada; nada de máscara robótica.
   const wave=Math.round(Math.sin(clock*1.25)*3),hand=Math.round(Math.sin(clock*1.7)*2);
   ctx.save();ctx.globalAlpha=.88+.08*Math.sin(clock*1.4);
   const rim='#3c819c',body=animHit?'#fff8e0':'#9bd7e4',hi='#d9f7fa',shade='#5ca6bc';
   // Silhueta em degraus, sem contorno preto retangular.
   px(-8,-37,16,4,rim);px(-13,-33,26,5,rim);px(-17,-28,34,27,rim);
   px(-14,-30,28,28,body);px(-10,-34,20,6,body);
   px(-7,-36,14,4,hi);px(-11,-28,7,15,hi);
   // Braços flutuantes discretos, conectados à túnica.
   px(-22,-18+hand,8,7,rim);px(-25,-13+hand,8,6,body);
   px(14,-18-hand,8,7,rim);px(17,-13-hand,8,6,body);
   // Olhos de espírito, não olhos mecânicos.
   px(-9,-23,6,9,'#17394f');px(3,-23,6,9,'#17394f');
   px(-7,-22,3,5,'#e5ffff');px(4,-22,3,5,'#e5ffff');
   px(-2,-12,4,5,shade);
   // Barrado irregular da túnica e três pontas de névoa.
   px(-14,-3,28,7,body);px(-14,4,9,6,body);px(-5,4+wave,10,9,body);
   px(5,4-wave,9,7,body);px(-12,8,6,5,shade);px(6,8-wave,5,5,shade);
   px(-3,13+wave,6,5,shade);
   if(animCast||animStrike){px(-28,-16+hand,5,5,'#b5ffff');px(23,-16-hand,5,5,'#b5ffff')}
   ctx.restore();
 }else{
   px(-11,-19,22,19,main);px(-8,-28,16,12,light);px(-8,1,6,6,shadow);px(2,1,6,6,shadow);px(-6,-23,4,4,shadow);px(2,-23,4,4,shadow);
 }
 // Detalhes específicos de cada guardião: armadura, coroa, rosto e artefatos.
 if(boss){
  const rune=Math.round(Math.sin(clock*2)*3), gold='#f4d58e';
  if(kind==='treant'){px(-13,-40,26,12,'#355c3a');px(-23,-43,10,17,main);px(13,-43,10,17,main);px(-17,-51,7,14,light);px(10,-51,7,14,light);px(-7,-28,5,5,gold);px(3,-28,5,5,gold);px(-6,-8,12,5,'#453b29')}
  if(kind==='spider'){px(-14,-44,28,9,shadow);px(-11,-48,22,6,main);px(-7,-45,5,5,gold);px(3,-45,5,5,gold);px(-18,-10,8,7,light);px(10,-10,8,7,light)}
  if(kind==='frost'){px(-18,-42,36,8,light);px(-13,-51,9,13,'#e6ffff');px(4,-51,9,13,'#e6ffff');px(-8,-25,16,7,'#163c65');px(-3,-24,6,5,'#e6ffff')}
  if(kind==='sand'){px(-21,-33,42,8,'#8c6037');px(-15,-44,30,11,light);px(-8,-28,16,6,'#4d3b31');px(-22,-8,9,17,gold);px(13,-8,9,17,gold)}
  if(kind==='lich'){px(-19,-41,38,11,shadow);px(-12,-51,24,15,main);px(-7,-32,5,5,'#8bffeb');px(3,-32,5,5,'#8bffeb');px(-4,-22,8,6,shadow);px(16,-12+rune,8,8,light)}
  if(kind==='storm'){px(-18,-42,36,12,'#314c72');px(-11,-49,22,9,light);px(-4,-31,8,9,'#d6faff');px(-24,-23,10,9,light);px(14,-23,10,9,light)}
  if(kind==='knight'){px(-18,-42,36,9,'#633444');px(-11,-53,22,15,'#3b2938');px(-7,-34,14,4,gold);px(-3,-25,6,11,light);px(17,-38,5,44,'#d8d4d4');px(15,-44,9,10,gold)}
  if(kind==='swamp'){px(-21,-42,42,12,'#345d4a');px(-15,-52,30,13,main);px(-8,-29,6,5,'#eaff7b');px(3,-29,6,5,'#eaff7b');px(-26,-10,11,10,'#a1d65c');px(15,-10,11,10,'#a1d65c')}
  if(kind==='phoenix'){px(-16,-48,11,23,'#ffdf7a');px(5,-48,11,23,'#ffdf7a');px(-6,-56,12,18,'#ff7d41');px(-7,-29,5,5,'#fff4c5');px(3,-29,5,5,'#fff4c5');px(-5,6,10,16,'#f57943')}
  if(kind==='dragon'){px(-7,-55,14,5,'#ffd78b');px(-21,-44,5,12,'#ffab72');px(16,-44,5,12,'#ffab72');if(e.phaseLevel>=2){px(-46,-35,9,5,'#ffc16d');px(37,-35,9,5,'#ffc16d')}}
 }
 if(boss){
  const phase=e.phaseLevel||1,wing=Math.round(Math.sin(clock*2)*5);
  ctx.globalAlpha=.65+.3*Math.sin(clock*3);
  px(-17,-42+wing,5,5,light);px(12,-44-wing,5,5,light);
  px(-21,-28,4,4,light);px(17,-30,4,4,light);
  if(phase>=2){px(-26,-36+wing,5,9,main);px(21,-36-wing,5,9,main)}
  if(phase>=3){px(-7,-51,5,5,light);px(4,-55,5,5,light)}
  if(animCast){px(-27,-16+wing,7,7,light);px(20,-16-wing,7,7,light)}
  // Marcas mágicas e aura distintas por chefe.
  if(['frost','storm','lich','dragon','phoenix'].includes(kind)){
   ctx.save();ctx.strokeStyle=light;ctx.globalAlpha=.6+.3*Math.sin(clock*2);ctx.lineWidth=2;
   ctx.beginPath();ctx.arc(0,-16,23+phase*3,clock*.5,clock*.5+Math.PI*1.4);ctx.stroke();ctx.restore();
  }
  if(kind==='spider'){px(-28,-24+wing,8,5,light);px(20,-24-wing,8,5,light)}
  if(kind==='knight'){px(-19,-30,5,32,light);px(14,-30,5,32,light)}
  ctx.globalAlpha=1;
 }else{
  // Respiração, piscadas e sinais de ataque distintos por espécie.
  if(animStrike){px(12,-14,7,5,light)}
  if(['Fantasma','Morcego','Aranha'].includes(kind)){px(-16,-33+Math.round(Math.sin(clock*2)*3),3,3,light)}
 }
 ctx.restore();
 // Barra de HP posicionada acima da cabeça, nunca sobre o corpo do chefe.
 const bar=boss?Math.min(126,Math.max(78,unit*2.1)):Math.max(22,unit*.68);
 const top=y-(boss?Math.max(76,unit*2.3):Math.max(35,unit*.98));
 const ratio=Math.max(0,Math.min(1,e.maxHp>0?e.hp/e.maxHp:0));
 rect(x-bar/2-2,top-2,bar+4,boss?11:9,'#07151e');
 rect(x-bar/2,top,bar,boss?7:5,'#3c2d37');
 rect(x-bar/2,top,bar*ratio,boss?7:5,boss?def.color:'#e88b7c');if(boss){for(let q=1;q<3;q++)rect(x-bar/2+bar*q/3,top,2,7,'#111e2b')}
 if(boss){rect(x-bar/2,top-2,bar,1,def.glow);ctx.fillStyle='#fff4d5';ctx.textAlign='center';ctx.font='bold 9px system-ui';ctx.fillText(def.name,x,top-7)}
}

// Sprites originais de cada classe: silhuetas, armaduras e armas diferentes.
function heroDraw(x,y,cls,dir,walk,attack,hit){
 const palettes={Guerreiro:['#a4b6c9','#475d7b','#e5b65e'],Arqueiro:['#528c60','#244c36','#d6a15a'],Mago:['#8d79d0','#403677','#a4e7ff'],Assassino:['#4b526b','#23263d','#bb8cff'],Tanque:['#b4a77c','#5e6672','#9cdbff'],Lanceiro:['#599caa','#27546b','#d2e5eb'],Samurai:['#a45b73','#432e4e','#f4d6a0'],Berserker:['#b77745','#623a37','#ff8356']};
 const [main,dark,accent]=palettes[cls]||palettes.Guerreiro,active=attack>0,step=player?.isWalking?Math.round(Math.sin(walk)*3):0,pix=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),w,h)};
 ctx.save();ctx.translate(Math.round(x),Math.round(y-(player?.isWalking?Math.abs(Math.sin(walk))*1.5:Math.sin(gameTime*2)*.35)));
 // Todas as direções laterais mantêm o rosto de frente; só muda a mão do equipamento.
 const heroClock=gameTime*6;
 const isCasting=attack>0;
 if(isCasting){ctx.save();ctx.globalAlpha=.22+.12*Math.sin(heroClock*3);ctx.fillStyle=accent;ctx.beginPath();ctx.ellipse(0,-16,20+Math.sin(heroClock)*3,27,0,0,Math.PI*2);ctx.fill();ctx.restore()}
 ctx.rotate(isCasting?Math.sin(heroClock*2)*.035:(player?.isWalking?Math.sin(walk)*.023:0));
 ctx.scale(1.25,1.25);ctx.imageSmoothingEnabled=false;
 pix(-11,11,22,4,'#07142099');pix(-8,0+step,7,13,dark);pix(2,0-step,7,13,dark);pix(-9,10+step,9,4,'#29283a');pix(1,10-step,9,4,'#29283a');
 const wide=cls==='Tanque'?17:cls==='Berserker'?15:cls==='Assassino'?9:12;
 pix(-wide,-18,wide*2,21,dark);pix(-wide+3,-16,wide*2-6,17,main);pix(-wide,-2,wide*2,5,'#303243');
 if(cls==='Tanque'){pix(-18,-19,10,10,'#c5c7b5');pix(8,-19,10,10,'#c5c7b5');pix(-11,-15,22,6,'#f0d999');pix(-7,-9,14,6,'#5a6e83')}
 else if(cls==='Samurai'){pix(-13,-17,26,4,'#f0a5a5');pix(-16,-4,32,5,'#54394b');pix(-13,0,7,8,'#7d4055');pix(6,0,7,8,'#7d4055')}
 else if(cls==='Assassino'){pix(-15,-17,6,22,'#25283b');pix(9,-17,6,22,'#25283b');pix(-8,-12,16,5,'#65677e')}
 else if(cls==='Berserker'){pix(-17,-16,8,9,'#d1b19a');pix(9,-16,8,9,'#d1b19a');pix(-5,-14,10,9,'#6c2d2b')}
 else if(cls==='Mago'){pix(-17,-17,7,24,'#51409a');pix(10,-17,7,24,'#51409a');pix(-5,-14,10,9,'#cfb1f1')}
 else if(cls==='Lanceiro'){pix(-16,-18,8,8,'#b2d9dd');pix(8,-18,8,8,'#b2d9dd');pix(-4,-16,8,15,'#32677d')}
 else if(cls==='Arqueiro'){pix(-14,-16,5,24,'#315d3e');pix(9,-16,5,24,'#315d3e');pix(-8,-14,16,5,'#8eb46a')}
 else {pix(-15,-16,7,8,'#b5b9c5');pix(8,-16,7,8,'#b5b9c5')}
 // Insígnias de classe e acessórios pixelados no peito.
 const marks={Guerreiro:'#ffe1a1',Arqueiro:'#b9f58a',Mago:'#b7eaff',Assassino:'#bfa1ff',Tanque:'#e9e6a5',Lanceiro:'#a9f8ef',Samurai:'#ffd1bb',Berserker:'#ff986e'};
 pix(-4,-12,8,7,marks[cls]||accent);pix(-2,-10,4,3,dark);
 if(cls==='Arqueiro'){pix(-wide+1,-18,4,27,'#76583d');pix(wide-5,-18,4,27,'#76583d')}
 if(cls==='Assassino'){pix(-wide-3,-22,7,28,'#202538');pix(wide-4,-22,7,28,'#202538')}
 if(cls==='Guerreiro'){pix(-wide,-21,wide*2,4,'#b9c9d5')}
 if(cls==='Mago'){pix(-wide,-22,wide*2,4,'#d1b5f2')}
 pix(-wide-3,-12,5,13,main);pix(wide-2,-12,5,13,main);pix(-wide-3,-1,5,5,'#d9a47f');pix(wide-2,-1,5,5,'#d9a47f');
 pix(-10,-35,20,19,'#c78d72');pix(-9,-34,18,16,'#e3b091');
 if(cls==='Assassino'){pix(-13,-39,26,12,'#27263b');pix(-10,-28,20,7,'#2d2a42');pix(-6,-28,4,2,accent);pix(3,-28,4,2,accent)}
 else if(cls==='Samurai'){pix(-12,-39,24,7,'#262639');pix(-14,-41,28,3,accent);pix(-11,-35,22,4,'#e2bcb2')}
 else if(cls==='Tanque'){pix(-12,-40,24,12,'#a9b8c3');pix(-8,-33,16,5,'#4c6076');pix(-3,-31,6,3,accent)}
 else if(cls==='Mago'){pix(-16,-40,32,5,dark);pix(-10,-50,20,13,main);pix(-6,-55,12,7,dark);pix(-2,-51,4,5,accent)}
 else if(cls==='Berserker'){pix(-12,-41,8,11,'#e6d4b0');pix(4,-41,8,11,'#e6d4b0');pix(-10,-36,20,6,'#54332d')}
 else if(cls==='Lanceiro'){pix(-11,-39,22,7,'#a5c7d5');pix(-4,-41,8,6,accent)}
 else if(cls==='Arqueiro'){pix(-13,-39,26,12,'#315b3d');pix(-8,-36,16,5,'#567c47')}
 else {pix(-12,-39,24,7,'#657488');pix(-10,-34,20,4,'#7e8999')}
 // Quatro direções: frente (0), esquerda (1), costas (2), direita (3).
 // As costas mostram manto, cabelo e mochila; laterais têm apenas um olho.
 if(dir===2){
   pix(-10,-36,20,18,cls==='Mago'?'#55418c':cls==='Arqueiro'?'#32573c':dark);
   pix(-8,-35,16,10,cls==='Berserker'?'#6b4032':'#414353');
   pix(-4,-22,8,6,accent);
   if(cls==='Arqueiro'){pix(-7,-17,14,19,'#76513b');pix(-5,-15,10,15,'#b58a52')}
   else if(cls==='Mago'){pix(-11,-17,22,23,'#6852a3');pix(-5,-15,10,16,'#9884dc')}
   else {pix(-6,-14,12,14,dark);pix(-3,-11,6,8,accent)}
 }else if(cls!=='Assassino'){
   pix(-6,-27,3,3,'#252e3a');pix(4,-27,3,3,'#252e3a');
 }
 // Cada equipamento usa a âncora da mão correspondente, nunca o mesmo ponto.
 const swing=active?Math.sin((.3-attack)*14)*.8:(player?.isWalking?Math.sin(walk)*.10:0);
 const hand=(side,draw,tilt=0)=>{ctx.save();const equippedSide=(dir===1?-side:side);ctx.translate(equippedSide*(wide+2),-1);ctx.rotate((equippedSide===1?1:-1)*swing+tilt);ctx.scale(.72,.72);draw();ctx.restore()};
 const blade=(length=26,tint='#c7d7e4')=>{pix(-2,-length,5,length,tint);pix(-1,-length-6,3,7,'#f5faff');pix(-7,-2,15,4,accent);pix(-2,2,5,8,'#6a4938')};
 const dagger=()=>{pix(-2,-17,5,19,'#afc2d4');pix(-1,-21,3,6,accent);pix(-5,1,11,3,'#51445c');pix(-2,4,5,7,'#664b44')};
 const shield=()=>{pix(-11,-23,22,30,'#40596a');pix(-8,-21,16,26,'#b5cbd8');pix(-5,-15,10,16,accent);pix(-2,-12,4,10,'#ffffff66')};
 if(cls==='Assassino'){hand(-1,dagger,-.22);hand(1,dagger,.22)}
 else if(cls==='Tanque'){hand(-1,shield,-.12);hand(1,()=>blade(28,'#d4e2e9'),.12)}
 else if(cls==='Lanceiro'){hand(-1,()=>{pix(-4,-4,9,8,'#c7a07b')});hand(1,()=>{pix(-2,-55,5,68,'#7d5740');pix(-5,-66,11,16,'#d0e9f1');pix(-2,-74,5,11,'#ffffff');pix(-7,-7,14,4,accent)})}
 else if(cls==='Samurai'){hand(-1,()=>{pix(-3,-12,6,19,'#603e4a');pix(-7,-13,14,5,'#e8bd72')});hand(1,()=>{pix(-2,-40,5,45,'#e5edf1');pix(-1,-46,3,8,'#ffffff');pix(-8,1,16,4,'#d9aa5c');pix(-2,5,5,8,'#443039')})}
 else if(cls==='Berserker'){hand(-1,()=>{pix(-4,-6,9,14,'#b58c6e');pix(-6,-8,12,5,'#6a3833')});hand(1,()=>{pix(-3,-35,7,47,'#79533e');pix(-17,-46,34,19,'#9ab4bc');pix(-12,-42,24,11,'#e0e7e7');pix(-8,-29,16,6,'#b25d4c')})}
 else if(cls==='Arqueiro'){
  // Arco, corda e flecha formam uma peça única ancorada na mão do arqueiro.
  // Espelhamento horizontal mantém o conjunto no mesmo lado ao virar.
  const facing=dir===1?-1:dir===3?1:dir===2?-1:1;
  ctx.save();
  ctx.translate(facing*(wide+3),-9);
  ctx.scale(facing*.74,.74);
  const drawPull=active?Math.min(6,Math.max(0,attack*22)):0;
  // Braço e empunhadura seguram o arco no centro.
  pix(-7,4,10,5,'#d9a47f');pix(0,-6,5,14,'#7b5234');
  // Arco curvo: madeira e reforços na ponta.
  ctx.strokeStyle='#a97840';ctx.lineWidth=4;ctx.beginPath();
  ctx.moveTo(3,-29);ctx.quadraticCurveTo(17,-16,13,0);ctx.quadraticCurveTo(17,16,3,29);ctx.stroke();
  ctx.strokeStyle='#e2b36a';ctx.lineWidth=1.5;ctx.beginPath();
  ctx.moveTo(4,-27);ctx.quadraticCurveTo(16,0,4,27);ctx.stroke();
  pix(1,-31,6,5,'#e0c17e');pix(1,26,6,5,'#e0c17e');
  // Corda tensionada; ponta da flecha permanece junto ao arco.
  const pullX=5-drawPull;
  ctx.strokeStyle='#eee3c8';ctx.lineWidth=1.5;ctx.beginPath();
  ctx.moveTo(4,-27);ctx.lineTo(pullX,0);ctx.lineTo(4,27);ctx.stroke();
  pix(pullX-15,-2,29,3,'#e9e2ce');
  pix(pullX+11,-5,8,9,'#e7bb65');
  pix(pullX-17,-6,4,5,'#b8d3d6');pix(pullX-17,1,4,5,'#b8d3d6');
  ctx.restore();
 }
 else if(cls==='Mago'){hand(-1,()=>{pix(-5,-4,10,9,'#6b568a');pix(-3,-7,6,4,accent)});hand(1,()=>{pix(-3,-36,7,45,'#71536b');pix(-7,-45,15,12,accent);pix(-4,-49,9,5,'#f2ffff');if(active){pix(-10,-52,21,4,'#9ceaff');pix(-3,-58,7,7,'#fff')}})}
 else {hand(-1,()=>{pix(-6,-12,12,18,'#6c7e8c');pix(-4,-10,8,14,accent)});hand(1,()=>blade(31))}
 if(isCasting){
  const fx={Guerreiro:'#ffe09a',Arqueiro:'#9fff9e',Mago:'#90dbff',Assassino:'#d1a4ff',Tanque:'#c8eaff',Lanceiro:'#a8f4ff',Samurai:'#ffc0b8',Berserker:'#ff8a65'}[cls]||accent;
  ctx.globalAlpha=.5+.35*Math.sin(heroClock*3);
  for(let k=0;k<3;k++){const a=heroClock+k*2.09;pix(Math.sin(a)*22,-23+Math.cos(a)*17,4,4,fx)}
  ctx.globalAlpha=1;
 }
 if(isCasting){ctx.save();ctx.globalAlpha=.75;pix(-25,-26,4,4,accent);pix(21,-18,4,4,accent);ctx.restore()}
 if(player?.dash>0){ctx.save();ctx.globalAlpha=.35;pix(-19,7,38,3,accent);pix(-15,14,30,2,'#d5e9ee');ctx.restore()}
 if(hit>0)pix(-19,-54,39,70,'#ff777744');ctx.restore();
}
// Oito mascotes originais: cada espécie tem desenho pixelado independente.
function drawPet(kind,at,unit){
 const p=petProgress(),stage=petStage(p?.level||1),t=gameTime;
 const flying=['Fada da Luz','Coruja Lunar','Fênix Jovem'].includes(kind),[x,y]=at(player.x-.76+Math.sin(t*2)*.08,player.y+(flying?-.65:.68));
 const pix=(x,y,w,h,c)=>{ctx.fillStyle=c;ctx.fillRect(Math.round(x),Math.round(y),w,h)};
 ctx.save();ctx.translate(Math.round(x),Math.round(y+(flying?Math.sin(t*4)*2:-Math.abs(Math.sin(t*6)))));ctx.scale(Math.min(1.15,Math.max(.78,unit/42))*(stage===4?1.3:stage===3?1.2:stage===2?1.12:stage===1?1.05:.9),Math.min(1.15,Math.max(.78,unit/42))*(stage===4?1.3:stage===3?1.2:stage===2?1.12:stage===1?1.05:.9));ctx.imageSmoothingEnabled=false;
 pix(-13,13,26,3,'#061b2a88');
 if(kind==='Lobo Guardião'){pix(-13,-8,26,19,'#526b80');pix(-11,-21,8,15,'#526b80');pix(3,-21,8,15,'#526b80');pix(-9,-9,18,14,'#9bb2bd');pix(-7,-4,4,4,'#ffdd88');pix(3,-4,4,4,'#ffdd88');pix(-3,2,6,4,'#293b4d');pix(-11,9,8,6,'#34495d');pix(3,9,8,6,'#34495d');pix(12,-3,9,5,'#728da4')}
 else if(kind==='Fada da Luz'){pix(-20,-15,11,19,'#81caff');pix(9,-15,11,19,'#81caff');pix(-17,-10,8,13,'#d2b2ff');pix(9,-10,8,13,'#d2b2ff');pix(-8,-13,16,17,'#f4d1b0');pix(-9,-18,18,7,'#f5e5a7');pix(-6,-6,3,3,'#283d5a');pix(3,-6,3,3,'#283d5a');pix(-9,5,18,9,'#9c8bdb');pix(-3,-25,6,5,'#fff5b5')}
 else if(kind==='Dragão Imperador'){pix(-19,-16,11,21,'#66528d');pix(8,-16,11,21,'#66528d');pix(-12,-11,24,22,'#9973b8');pix(-11,-23,8,14,'#d4b0e5');pix(3,-23,8,14,'#d4b0e5');pix(-8,-5,5,5,'#ffe3a1');pix(3,-5,5,5,'#ffe3a1');pix(-7,6,14,5,'#d9a7b7');pix(11,6,11,5,'#75568c')}
 else if(kind==='Raposa Mística'){pix(-12,-8,24,19,'#b96442');pix(-13,-24,10,18,'#b96442');pix(3,-24,10,18,'#b96442');pix(-10,-17,5,9,'#f3d0a6');pix(5,-17,5,9,'#f3d0a6');pix(-9,-3,18,12,'#e9b77d');pix(-7,-4,4,4,'#77e9d4');pix(3,-4,4,4,'#77e9d4');pix(-4,3,8,5,'#fff3cf');pix(12,-8,11,8,'#b96442');pix(20,-11,6,6,'#fff3d4')}
 else if(kind==='Coruja Lunar'){pix(-13,-16,26,28,'#696b9a');pix(-15,-18,9,11,'#696b9a');pix(6,-18,9,11,'#696b9a');pix(-10,-9,20,17,'#c6c7e5');pix(-10,-7,9,10,'#f8e9ab');pix(1,-7,9,10,'#f8e9ab');pix(-7,-4,4,4,'#31334b');pix(3,-4,4,4,'#31334b');pix(-2,3,4,6,'#d8a66b');pix(-18,-5,6,16,'#9097c0');pix(12,-5,6,16,'#9097c0')}
 else if(kind==='Golem Miniatura'){pix(-12,-18,24,27,'#6e8890');pix(-9,-24,18,8,'#9ab2b5');pix(-19,-11,8,19,'#8aa5ab');pix(11,-11,8,19,'#8aa5ab');pix(-10,9,8,6,'#516a72');pix(2,9,8,6,'#516a72');pix(-7,-7,5,5,'#75ecff');pix(2,-7,5,5,'#75ecff');pix(-4,2,8,4,'#a6d8cf');pix(-2,-17,4,7,'#c1e8de')}
 else if(kind==='Tigre de Gelo'){pix(-15,-9,30,22,'#b4e3ef');pix(-12,-23,10,17,'#91c9d9');pix(2,-23,10,17,'#91c9d9');pix(-8,-10,5,9,'#4f879d');pix(3,-10,5,9,'#4f879d');pix(-11,0,6,7,'#4f879d');pix(5,0,6,7,'#4f879d');pix(-7,-5,4,4,'#20455d');pix(3,-5,4,4,'#20455d');pix(-4,5,8,5,'#f0fcff');pix(14,-3,10,5,'#b4e3ef')}
 else if(kind==='Fênix Jovem'){pix(-18,-10,10,19,'#f18a3d');pix(8,-10,10,19,'#f18a3d');pix(-15,-15,9,11,'#f5c458');pix(6,-15,9,11,'#f5c458');pix(-9,-14,18,24,'#db5639');pix(-7,-21,14,10,'#f7b951');pix(-3,-29,6,10,'#ffe27c');pix(-7,-7,5,4,'#fff4b6');pix(2,-7,5,4,'#fff4b6');pix(-2,0,7,5,'#f4d8a3');pix(-6,9,5,8,'#a85b39');pix(2,9,5,8,'#a85b39')}
 if(stage>=2){const hue=petInfo(kind).color;pix(-18,-20,5,6,hue);pix(13,-20,5,6,hue);if(kind==='Lobo Guardião'){pix(-11,-25,22,4,'#d7ebfa');pix(-2,-30,4,7,'#e2d0a2')}else if(kind==='Dragão Imperador'){pix(-15,-27,7,13,'#f5c66d');pix(8,-27,7,13,'#f5c66d');pix(-8,10,16,5,'#f2d4a0')}else if(kind==='Fênix Jovem'){pix(-21,-13,5,18,'#ffda69');pix(16,-13,5,18,'#ffda69')}else if(kind==='Tigre de Gelo'){pix(-14,-13,5,10,'#e9ffff');pix(9,-13,5,10,'#e9ffff')}else if(kind==='Golem Miniatura'){pix(-12,-22,24,5,'#b4d9db')}else if(kind==='Coruja Lunar'){pix(-11,-23,22,5,'#e4d9ff')}else if(kind==='Raposa Mística'){pix(-15,5,7,9,'#ffe0b5')}else if(kind==='Fada da Luz'){pix(-3,-29,6,8,'#fff6b4')}}
 if(stage>=3){const c=petInfo(kind).color;pix(-20,-13,5,15,c);pix(15,-13,5,15,c);pix(-7,-33,14,5,'#f6d18b');if(kind==='Lobo Guardião'){pix(-15,-16,5,16,'#c7e8ef');pix(10,-16,5,16,'#c7e8ef')}if(kind==='Dragão Imperador'){pix(-23,-20,9,20,'#c69aff');pix(14,-20,9,20,'#c69aff')}if(kind==='Golem Miniatura'){pix(-15,-27,30,5,'#e0faff')}if(kind==='Fênix Jovem'){pix(-18,-29,9,14,'#ffd16a');pix(9,-29,9,14,'#ffd16a')}}
 if(stage===4){const c=petInfo(kind).color;for(let j=0;j<5;j++){const xx=Math.round(Math.sin(t*2+j*1.26)*28),yy=Math.round(Math.cos(t*2+j*1.26)*26)-8;pix(xx,yy,4,4,j%2?'#fff1a8':c)}pix(-12,-36,5,5,'#ffe5a1');pix(7,-36,5,5,'#ffe5a1')}
 if(stage>=1){const c=stage===4?'#ffd56e':stage===3?'#ffe18c':stage===2?'#d6b3ff':'#b7e5ff';pix(-17,-28,4,4,c);pix(13,-25,4,4,c);if(stage>=2){pix(-3,-32,6,4,c);pix(-22,0,5,6,c)}if(stage>=3){pix(18,-9,6,6,c);pix(-12,-31,5,5,c)}if(stage===4){pix(-4,-39,8,6,'#fff3b0');pix(-23,-19,5,5,c);pix(20,-22,5,5,c);ctx.save();ctx.globalAlpha=.35+.15*Math.sin(t*5);ctx.strokeStyle=c;ctx.lineWidth=2;ctx.strokeRect(-24,-35,48,52);ctx.restore()}}
 ctx.restore();
}
function draw(){const vw=innerWidth,vh=innerHeight;rect(0,0,vw,vh,'#0b1b25');if(!player)return;const zoom=Math.min(1.2,Math.max(.86,vh/480));const unit=T*zoom;camera.x+=(player.x*unit-vw/2-camera.x)*.15;camera.y+=(player.y*unit-vh/2-camera.y)*.15;let ox=-camera.x,oy=-camera.y;if(screenShake>0){ox+=(Math.random()-.5)*5;oy+=(Math.random()-.5)*5;screenShake=Math.max(0,screenShake-.016)}ctx.imageSmoothingEnabled=false;const minX=clamp(Math.floor(-ox/unit)-2,0,W),maxX=clamp(Math.ceil((vw-ox)/unit)+2,0,W),minY=clamp(Math.floor(-oy/unit)-2,0,H),maxY=clamp(Math.ceil((vh-oy)/unit)+2,0,H);
for(let y=minY;y<maxY;y++)for(let x=minX;x<maxX;x++){let sx=ox+x*unit,sy=oy+y*unit,t=world[y][x],n=noise(x,y);rect(sx,sy,unit+1,unit+1,t===4?'#8a4b3c':t===3?(realmIndex===3?'#c5a374':'#8e826d'):t===2?realmInfo().stone:t===1?'#234f46':realmInfo().floor);if(t===2){rect(sx+2,sy+3,unit-4,unit*.35,'#626b71');rect(sx+4,sy+unit*.5,unit*.45,3,'#333e49')}else if(t===1){circle(sx+unit*.5,sy+unit*.35,unit*.33,'#1a4d3c');circle(sx+unit*.35,sy+unit*.27,unit*.2,'#28684c');rect(sx+unit*.44,sy+unit*.58,unit*.13,unit*.25,'#73553b')}else if(t===4){rect(sx+unit*.2,sy+unit*.22,unit*.6,3,'#dc7951');if(Math.sin(gameTime*3+x+y)>0)circle(sx+unit*.5,sy+unit*.6,2,'#ffd36b')}else if(n>.56){rect(sx+unit*.25,sy+unit*.65,2,4,realmInfo().detail);rect(sx+unit*.64,sy+unit*.25,2,3,'#6f9866')}}
// Detalhes exclusivos por bioma, desenhados apenas nos blocos visíveis.
for(let y=minY;y<maxY;y++)for(let x=minX;x<maxX;x++){
 if(world[y][x]===2||world[y][x]===1)continue;
 let n=noise(x+97,y+31),sx=ox+x*unit,sy=oy+y*unit,u=unit;
 if(n<.76)continue;
 ctx.save();ctx.translate(sx+u*.5,sy+u*.55);
 switch(realmIndex){
 case 0: // Flores e plantações
 case 1: for(let j=0;j<3;j++){circle((j-1)*u*.16,Math.sin(gameTime*2+j+x)*2,u*.07,realmIndex===1?'#e4c3f4':'#e9d46e');rect((j-1)*u*.16,u*.07,2,u*.17,'#4e8a53')}break;
 case 2: // Estalagmites cristalinas
  ctx.fillStyle='#91e7fa';ctx.shadowColor='#6dd7ff';ctx.shadowBlur=8;ctx.beginPath();ctx.moveTo(-u*.25,u*.24);ctx.lineTo(-u*.1,-u*.4);ctx.lineTo(u*.04,u*.23);ctx.fill();ctx.beginPath();ctx.moveTo(u*.05,u*.25);ctx.lineTo(u*.25,-u*.2);ctx.lineTo(u*.3,u*.25);ctx.fill();break;
 case 3: // Dunas e cactos
  rect(-u*.12,-u*.26,u*.22,u*.5,'#367d5d');rect(-u*.26,-u*.1,u*.16,u*.12,'#367d5d');rect(u*.1,-u*.16,u*.16,u*.12,'#367d5d');break;
 case 4: // Rochas alpinas
  ctx.fillStyle='#c2cdd6';ctx.beginPath();ctx.moveTo(-u*.37,u*.28);ctx.lineTo(-u*.1,-u*.34);ctx.lineTo(u*.28,u*.28);ctx.fill();rect(-u*.15,-u*.12,u*.1,u*.1,'#f2f4f5');break;
 case 5: // Cristais de gelo e flocos
  ctx.strokeStyle='#f2fcff';ctx.lineWidth=2;for(let a=0;a<3;a++){let t=a*Math.PI/3;ctx.beginPath();ctx.moveTo(Math.cos(t)*u*.18,Math.sin(t)*u*.18);ctx.lineTo(-Math.cos(t)*u*.18,-Math.sin(t)*u*.18);ctx.stroke()}break;
 case 6: // Colunas quebradas da cidade antiga
  rect(-u*.18,-u*.35,u*.36,u*.65,'#d0bea4');rect(-u*.27,-u*.4,u*.54,u*.12,'#8b796b');rect(-u*.23,u*.22,u*.46,u*.11,'#73675c');break;
 case 7: // Poças e cogumelos do pântano
  circle(0,u*.12,u*.26,'#3c8290');rect(-u*.2,-u*.12,u*.08,u*.24,'#eee1ca');circle(-u*.16,-u*.13,u*.13,'#bf7c9a');break;
 case 8: // Fissuras de lava animadas
  ctx.strokeStyle=Math.sin(gameTime*3+x)>.1?'#ffb148':'#e65b36';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(-u*.28,-u*.26);ctx.lineTo(0,0);ctx.lineTo(-u*.05,u*.28);ctx.lineTo(u*.3,u*.37);ctx.stroke();break;
 case 9: // Runas arcanas no trono
  ctx.strokeStyle='#b9a2ff';ctx.lineWidth=2;ctx.rotate(gameTime*.3);ctx.strokeRect(-u*.2,-u*.2,u*.4,u*.4);ctx.rotate(Math.PI/4);ctx.strokeRect(-u*.13,-u*.13,u*.26,u*.26);break;
 }
 ctx.restore();
}
const at=(x,y)=>[ox+x*unit,oy+y*unit];
// Cenários inspirados nos mapas ilustrados da versão 8.2: casas, torres, cristais, fontes e ruínas.
const drawBuilding=(gx,gy,type)=>{
let [x,y]=at(gx,gy);if(x<-100||x>vw+100||y<-100||y>vh+100)return;
let u=unit;ctx.save();ctx.translate(x,y);
if(type==='house'){
rect(-u*1.15,-u*.65,u*2.3,u*1.8,realmIndex===6?'#777e84':'#bda785');
rect(-u*1.35,-u*.92,u*2.7,u*.6,realmIndex===5?'#41616b':'#804c4b');
rect(-u*.23,u*.45,u*.46,u*.7,'#4c3431');
rect(-u*.9,-u*.35,u*.42,u*.42,'#89c4c5');rect(u*.48,-u*.35,u*.42,u*.42,'#89c4c5');
rect(-u*1.36,-u*.95,u*2.75,u*.13,'#c87e6a');
}else if(type==='tower'){
rect(-u*.75,-u*1.8,u*1.5,u*2.65,'#7c788a');rect(-u*.94,-u*1.95,u*1.9,u*.43,'#4e495f');
rect(-u*.22,-u*.9,u*.44,u*.65,'#22273f');rect(-u*.25,u*.4,u*.5,u*.48,'#333043');
}else if(type==='crystal'){
ctx.shadowBlur=15;ctx.shadowColor='#83d9f7';ctx.fillStyle='#85d9f0';ctx.beginPath();ctx.moveTo(0,-u*1.15);ctx.lineTo(u*.5,-u*.35);ctx.lineTo(u*.18,u*.65);ctx.lineTo(-u*.42,u*.38);ctx.closePath();ctx.fill();ctx.shadowBlur=0;
}else if(type==='well'){
circle(0,0,u*.85,'#7e8c8c');circle(0,0,u*.57,'#2e718a');circle(0,0,u*.39,'#4f9fbb');rect(-u*.95,-u*.5,u*.15,u*1.1,'#b5a38a');rect(u*.8,-u*.5,u*.15,u*1.1,'#b5a38a');
}else if(type==='ruin'){
rect(-u*.9,-u*.8,u*.36,u*1.7,'#a4a0a6');rect(u*.5,-u*.8,u*.36,u*1.7,'#a4a0a6');rect(-u*1.03,-u*.9,u*2,u*.29,'#777581');
}
ctx.restore()};
if([0,1,4,6,7,9].includes(realmIndex)){
for(const [hx,hy] of [[16,9],[30,8],[17,29],[34,29]])drawBuilding(hx,hy,realmIndex===4||realmIndex===6||realmIndex===9?'tower':'house');
if(realmIndex===0||realmIndex===7)drawBuilding(22,14,'well');
}
if(realmIndex===2||realmIndex===5)for(const [cx,cy] of [[17,10],[30,13],[20,28],[38,27]])drawBuilding(cx,cy,'crystal');
if(realmIndex===3||realmIndex===6||realmIndex===8)for(const [rx,ry] of [[18,12],[32,13],[27,28]])drawBuilding(rx,ry,'ruin');
for(const c of chests){let [x,y]=at(c.x,c.y);rect(x-unit*.3,y-unit*.24,unit*.6,unit*.44,c.open?'#544c43':'#94613c');rect(x-unit*.27,y-unit*.2,unit*.54,unit*.09,'#e4ba6d');if(!c.open)rect(x-2,y-3,4,8,'#fff2a8')}
{let [gx,gy]=at(portal.x,portal.y);if(gx>-90&&gx<vw+90&&gy>-100&&gy<vh+100){
ctx.save();ctx.translate(gx,gy);let pulse=Math.sin(gameTime*3)*3;ctx.shadowColor='#8ddaff';ctx.shadowBlur=19+8*Math.sin(gameTime*4);ctx.strokeStyle='#b9d3eb';ctx.lineWidth=5;ctx.beginPath();ctx.ellipse(0,-17,20+pulse,30+pulse,0,0,Math.PI*2);ctx.stroke();ctx.strokeStyle='#4d8dce';ctx.lineWidth=9;ctx.beginPath();ctx.ellipse(0,-17,15+pulse,25+pulse,0,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#557de09c';ctx.beginPath();ctx.ellipse(0,-17,11+pulse,22+pulse,0,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
for(let k=0;k<5;k++){let a=gameTime*1.8+k*Math.PI*2/5;circle(Math.cos(a)*14,-17+Math.sin(a)*21,2.3,'#e1ffff')}
ctx.fillStyle='#fce5ae';ctx.font='bold 11px system-ui';ctx.textAlign='center';ctx.fillText(realmIndex===classicRealms.length-1?'PORTAL FINAL':realmRewards[realmIndex]?'PORTAL LIBERADO':'PORTAL SELADO',0,-57);if(player&&Math.hypot(player.x-portal.x,player.y-portal.y)<3){ctx.font='bold 10px system-ui';ctx.fillStyle='#ffffff';ctx.fillText(realmRewards[realmIndex]?'USE para atravessar':'PORTAL SELADO',0,-72)}ctx.restore();}}
if(realmIndex>0&&!dungeonSession){let [bx,by]=at(backPortal.x,backPortal.y);ctx.save();ctx.strokeStyle='#ffc77e';ctx.lineWidth=5;ctx.shadowColor='#ffc77e';ctx.shadowBlur=15;ctx.beginPath();ctx.ellipse(bx,by-14,17,27,0,0,Math.PI*2);ctx.stroke();ctx.shadowBlur=0;ctx.fillStyle='#ffdf9b';ctx.font='bold 11px system-ui';ctx.textAlign='center';ctx.fillText('VOLTAR · '+realmIndex,bx,by-50);ctx.restore()}
for(const n of npcs){let [x,y]=at(n.x,n.y);if(realmIndex!==0){circle(x,y-22,unit*.7,['#b6dbad','#b8ffdb','#a2ddff','#f6d7a0','#c8cbd1','#e0faff','#f2dab6','#b6de95','#ffc28c','#d3a5f7'][realmIndex]+'33');}heroDraw(x,y,n.role==='mentor'?'Mago':n.role==='shop'?'Arqueiro':'Guerreiro',0,gameTime*.3,0,0);ctx.font='bold 11px system-ui';ctx.textAlign='center';ctx.fillStyle='#fbe8b2';ctx.fillText(n.name,x,y-53)}
for(const e of enemies){if(e.elite&&e.charge>0){let [cx,cy]=at(e.warningX,e.warningY),radius=(e.type==='Dragão'?3.3:2.3)*unit;ctx.save();ctx.fillStyle=e.type==='Dragão'?'rgba(255,72,30,.22)':'rgba(180,90,245,.20)';ctx.strokeStyle=e.charge<.48?'#fff1a0':e.type==='Dragão'?'#ff643a':'#c4a1ff';ctx.lineWidth=4;ctx.setLineDash([12,7]);ctx.lineDashOffset=-gameTime*45;ctx.beginPath();if(e.attackPattern===2){let [ex,ey]=at(e.x,e.y);ctx.translate(ex,ey);ctx.rotate(e.attackAngle);ctx.rect(0,-unit*.85,unit*7,unit*1.7)}else if(e.attackPattern===3){let [ex,ey]=at(e.x,e.y);ctx.arc(ex,ey,unit*4.5,0,Math.PI*2);ctx.arc(ex,ey,unit*1.8,0,Math.PI*2,true)}else if(e.attackPattern===4){let [ex,ey]=at(e.x,e.y);ctx.rect(ex-unit*.85,ey-unit*9,unit*1.7,unit*18);ctx.rect(ex-unit*9,ey-unit*.85,unit*18,unit*1.7)}else ctx.arc(cx,cy,radius,0,Math.PI*2);ctx.fill();ctx.stroke();ctx.setLineDash([]);ctx.restore()}}
if(dungeonSession){ctx.save();for(const sw of dungeonSession.switches){const [px,py]=at(sw.x,sw.y);ctx.fillStyle=sw.lit?'#62f2bc':'#d9a3ff';ctx.shadowColor=ctx.fillStyle;ctx.shadowBlur=15;ctx.beginPath();ctx.arc(px,py,unit*.26+Math.sin(gameTime*3)*2,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;ctx.fillStyle='#fff';ctx.font='bold 11px sans-serif';ctx.textAlign='center';ctx.fillText(sw.lit?'✓':'SELO',px,py-16)}const [ex,ey]=at(3.5,3.5);ctx.strokeStyle='#65e4ff';ctx.lineWidth=4;ctx.beginPath();ctx.arc(ex,ey,unit*.38,0,Math.PI*2);ctx.stroke();ctx.fillStyle='#fff';ctx.font='bold 11px sans-serif';ctx.fillText('PORTAL DE RETORNO',ex,ey-26);ctx.font='10px sans-serif';ctx.fillStyle='#b7edff';ctx.fillText('USE para sair',ex,ey+unit*.72);ctx.restore()}
for(const e of enemies){const [x,y]=at(e.x,e.y);eldoriaPixelCreature(e,x,y,unit)}
let [px,py]=at(player.x,player.y);heroDraw(px,py,player.cls,player.dir,player.anim,player.attackAnim,player.hit);
// Impactos discretos junto à arma: sem a antiga barrinha ou meia-lua de pixels.
if(player.attackAnim>0 && !['Arqueiro','Mago'].includes(player.cls)){
 const progress=1-Math.min(1,player.attackAnim/.24);
 const directionAngle=({0:Math.PI/2,1:Math.PI,2:-Math.PI/2,3:0})[player.dir]||0;
 const colors={Guerreiro:'#ffe1a3',Assassino:'#cbaaff',Tanque:'#a9eaff',Lanceiro:'#91f4df',Samurai:'#ffc0d0',Berserker:'#ff936d'};
 const col=colors[player.cls]||'#ffe1a3';
 const reach=player.cls==='Lanceiro'?unit*.98:unit*.62;
 const impactX=px+Math.cos(directionAngle)*reach,impactY=py-unit*.24+Math.sin(directionAngle)*reach;
 const fade=Math.max(0,1-progress);
 ctx.save();ctx.globalAlpha=fade*.85;ctx.fillStyle=col;
 const seed=player.cls==='Samurai'?8:player.cls==='Assassino'?7:5;
 for(let i=0;i<seed;i++){
  const a=directionAngle+(i-(seed-1)/2)*.27;
  const r=unit*(.08+progress*.22+(i%3)*.04);
  const sx=impactX+Math.cos(a)*r,sy=impactY+Math.sin(a)*r;
  const sz=Math.max(2,Math.round(unit*(.045+(i%2)*.016)*fade));
  ctx.fillRect(Math.round(sx),Math.round(sy),sz,sz);
 }
 ctx.restore();
}
for(const s of shots){let [x,y]=at(s.x,s.y);if(s.type==='arrow'){ctx.strokeStyle='#ffe2a2';ctx.lineWidth=3;ctx.beginPath();ctx.moveTo(x-s.vx*1.2,y-s.vy*1.2);ctx.lineTo(x+s.vx*.5,y+s.vy*.5);ctx.stroke();circle(x+s.vx*.5,y+s.vy*.5,3,'#f7ffff')}else{circle(x,y,8,'#4ba9ed77');circle(x,y,4,'#d7ffff')}}
for(const p of particles){let [x,y]=at(p.x,p.y);rect(x,y,3,3,p.color)}
drawClassVfx(at,unit);
// Clima desenhado na tela, com limite de partículas para aparelhos móveis.
if(adventure.weather&&settings.quality!=='low'){ctx.save();const count=adventure.weather===2?10:42;for(let i=0;i<count;i++){let x=((i*137.7+gameTime*(adventure.weather===4?18:45))%(vw+80))-40,y=((i*83.9+gameTime*(adventure.weather===3?25:95))%(vh+60))-30;ctx.strokeStyle=adventure.weather===1?'#a3cce777':adventure.weather===3?'#e8f8ff99':adventure.weather===4?'#ffb36c88':'#b6d8c544';ctx.lineWidth=adventure.weather===1?1:2;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(x+(adventure.weather===1?-7:3),y+(adventure.weather===1?14:3));ctx.stroke()}ctx.restore()}
// Familiar acompanha o jogador visualmente.
if(adventure.companion!=='none')drawPet(adventure.companion,at,unit)
// Entrada de masmorra persistente, marcada no terreno.
if(!dungeonSession){let [dx,dy]=at(26.5,32.5);if(dx>-50&&dx<vw+50&&dy>-50&&dy<vh+50){ctx.save();ctx.strokeStyle=adventure.dungeons[realmIndex]?'#9c9c9c':'#c3a3ff';ctx.lineWidth=4;ctx.shadowColor='#b18eff';ctx.shadowBlur=15;ctx.fillStyle='#293448';ctx.fillRect(dx-20,dy-12,40,32);ctx.fillStyle='#725aa6';ctx.fillRect(dx-17,dy-20,34,9);ctx.fillStyle='#b39bdb';ctx.fillRect(dx-12,dy-26,24,7);ctx.fillStyle='#13172b';ctx.fillRect(dx-12,dy-10,24,29);ctx.fillStyle='#7556c0';ctx.fillRect(dx-9,dy-7,18,23);ctx.fillStyle='#d8baff';ctx.fillRect(dx-5,dy-3,10,14);ctx.fillStyle='#f8e9c0';ctx.fillRect(dx-2,dy+1,4,6);ctx.shadowBlur=0;ctx.fillStyle='#ead8ff';ctx.font='bold 10px system-ui';ctx.textAlign='center';ctx.fillText('MASMORRA',dx,dy-22);ctx.restore()}}
if(realmIndex===8&&player.x>42&&gameTime>150&&!enemies.some(e=>e.type==='Titã')&&!player.titanDefeated&&killCount>=15){enemies.push(makeEnemy(52.5,21.5,'Titã'));player.titanDefeated=true;toast('O Titã de Cinzas surgiu nas Terras Vulcânicas!')}
// Atmosfera ambiental distinta por região, sem obstruir os controles.
if(!dungeonSession&&!adventure.secretCaches?.[realmIndex]){const q=secretLocation(),px=ox+q.x*unit,py=oy+q.y*unit;if(px>-30&&py>-30&&px<vw+30&&py<vh+30){ctx.save();ctx.globalAlpha=.45+.3*Math.sin(gameTime*2.8);circle(px,py,unit*.16,'#f6d47c');ctx.fillStyle='#fff1ba';ctx.font='bold 10px sans-serif';ctx.textAlign='center';ctx.fillText('✦',px,py-13);ctx.restore()}}
if(settings.particles && settings.quality!=='low'){
 ctx.save();
 const amount=realmIndex===5?35:realmIndex===8?22:realmIndex===7?15:12;
 for(let i=0;i<amount;i++){
  let px=((i*179.7+gameTime*(realmIndex===5?19:realmIndex===8?-13:6))%(vw+60)+vw+60)%(vw+60)-30;
  let py=((i*103.1+gameTime*(realmIndex===5?32:realmIndex===8?-26:9))%(vh+50)+vh+50)%(vh+50)-25;
  ctx.globalAlpha=.25+.2*Math.sin(gameTime*1.5+i);
  circle(px,py,realmIndex===5?2:1.5,realmIndex===8?'#ffb26b':realmIndex===5?'#e9faff':realmIndex===7?'#b2e9c5':'#f6e4bb');
 }
 ctx.restore();
}
const night=(Math.sin(gameTime/85)+1)/2;rect(0,0,vw,vh,`rgba(8,15,43,${(.07+night*.18).toFixed(2)})`);if(settings.minimap && now-eldoriaLastMinimap>.22){drawMap(mm,110,88);eldoriaLastMinimap=now}}
function drawMap(c,w,h){if(!player)return;c.clearRect(0,0,w,h);const sx=w/W,sy=h/H;for(let y=0;y<H;y++)for(let x=0;x<W;x++){c.fillStyle=world[y][x]===2?realmInfo().stone:world[y][x]===1&&(realmIndex===1||realmIndex===7)?'#173d31':world[y][x]===4?'#a4503c':world[y][x]===3?realmInfo().stone:realmInfo().floor;c.fillRect(x*sx,y*sy,sx+1,sy+1)}if(!dungeonSession){c.fillStyle='#c790ff';c.fillRect(portal.x*sx-3,portal.y*sy-3,6,6)}else{c.fillStyle='#6feaff';c.fillRect(3.5*sx-3,3.5*sy-3,6,6);for(const sw of dungeonSession.switches){c.fillStyle=sw.lit?'#6feac1':'#e1a4ff';c.fillRect(sw.x*sx-2,sw.y*sy-2,4,4)}}for(const n of npcs){c.fillStyle='#76d7ef';c.fillRect(n.x*sx-2,n.y*sy-2,4,4)}for(const e of enemies)if(e.hp>0){c.fillStyle='#ec7070';c.fillRect(e.x*sx-1,e.y*sy-1,3,3)}c.fillStyle='#ffde88';c.beginPath();c.arc(player.x*sx,player.y*sy,3,0,Math.PI*2);c.fill()}
let eldoriaLastMinimap=-10,eldoriaLastRender=0,eldoriaSimClock=0;function frame(t){const targetInterval=(matchMedia('(pointer:coarse)').matches||settings.quality==='low')?1000/30:1000/45;if(t-eldoriaLastRender<targetInterval-1){requestAnimationFrame(frame);return;}eldoriaLastRender=t;let dt=Math.min(.05,Math.max(.001,(t-last)/1000||.016));last=t;now=t/1000;try{if(gameState==='playing')tick(dt);if(gameState==='playing'||gameState==='paused')draw()}catch(err){console.error('Eldoria: erro durante o jogo',err);try{ctx.setTransform(1,0,0,1,0,0);ctx.restore()}catch(_){}}if(msgUntil&&t>msgUntil){$('notice').classList.remove('show');msgUntil=0}requestAnimationFrame(frame)}
function bind(){$('skillTreeBtn').onclick=()=>openModal('talents');$('petBtn').onclick=()=>openModal('companion');$('dungeonBtn').onclick=()=>openModal('dungeon');$('endingBack').onclick=()=>{$('ending').classList.remove('show');menuPage()};const joyEl=$('joy'),nub=$('nub');function joyMove(e){let r=joyEl.getBoundingClientRect(),x=(e.clientX-r.left-r.width/2)/(r.width*.38),y=(e.clientY-r.top-r.height/2)/(r.height*.38),m=Math.max(1,Math.hypot(x,y));joy.x=x/m;joy.y=y/m;nub.style.transform=`translate(calc(-50% + ${joy.x*35}px),calc(-50% + ${joy.y*35}px))`}joyEl.addEventListener('pointerdown',e=>{joyEl.setPointerCapture(e.pointerId);joyMove(e)});joyEl.addEventListener('pointermove',e=>{if(joyEl.hasPointerCapture(e.pointerId))joyMove(e)});function joyEnd(){joy.x=joy.y=0;nub.style.transform='translate(-50%,-50%)'}joyEl.addEventListener('pointerup',joyEnd);joyEl.addEventListener('pointercancel',joyEnd);
for(const [id,fn] of [['atk',attack],['skill',skill],['dash',dodge],['interact',interact]]){const el=$(id);el.addEventListener('pointerdown',e=>{e.preventDefault();fn()},{passive:false});}for(let i=0;i<2;i++){const el=$('quickPotion'+i);if(el)el.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();quickPotion(i)},{passive:false})}$('quickStats').onclick=()=>openModal('stats');$('bag').onclick=()=>openModal('inventory');$('quest').onclick=()=>openModal('quests');$('minimap').addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();if(player)openModal('map')});$('minimap').addEventListener('click',e=>{e.preventDefault();e.stopPropagation();if(player&&!modalOpen)openModal('map')});$('gear').onclick=()=>openModal('settings');$('pause').onclick=()=>openModal('pause');$('modalClose').onclick=closeModal;$('modal').addEventListener('pointerdown',e=>{if(e.target===$('modal'))closeModal()});window.addEventListener('keydown',e=>{let k=e.key.toLowerCase();if([' ','arrowup','arrowdown','arrowleft','arrowright'].includes(k))e.preventDefault();keys[k]=true;if(e.repeat)return;if(k==='escape'){if(modalOpen)closeModal();else if(gameState==='playing')openModal('pause')}if(gameState!=='playing')return;if(k===' ')attack();if(k==='q')skill();if(k==='shift')dodge();if(k==='e')interact();if(k==='i')openModal('inventory');if(k==='m')openModal('map')});window.addEventListener('keyup',e=>keys[e.key.toLowerCase()]=false);window.addEventListener('blur',()=>{keys={};joyEnd()});window.addEventListener('resize',resize);window.addEventListener('beforeunload',save)}
bind();resize();applySettings();loginPage();requestAnimationFrame(frame);
})();

// A Screen Orientation API exige interação do usuário e normalmente tela cheia.

function updateLoginOrientation(){
 const portrait=window.matchMedia('(orientation: portrait)').matches;
 const status=document.getElementById('orientationStatus');
 const detail=document.getElementById('orientationDetail');
 const btn=document.getElementById('loginRotateBtn');
 if(!status||!detail||!btn)return;
 status.textContent=portrait?'MELHOR NA HORIZONTAL':'TELA HORIZONTAL ATIVA';
 if(!portrait){detail.textContent='Tudo pronto! Aproveite a aventura.';document.getElementById('rotateBtnTitle').textContent='TELA PRONTA';document.getElementById('rotateBtnCaption').textContent='Agora é só começar a aventura';btn.classList.add('isReady');btn.disabled=true}
 else{if(!detail.textContent.includes('Se não girar'))detail.textContent='Toque para girar a tela e jogar com mais espaço.';document.getElementById('rotateBtnTitle').textContent='GIRAR A TELA';document.getElementById('rotateBtnCaption').textContent='Toque para jogar na horizontal';btn.classList.remove('isReady');btn.disabled=false}
}
window.addEventListener('resize',updateLoginOrientation);

async function requestEldoriaLandscape(){
  if(!matchMedia('(pointer:coarse)').matches)return;
  try{if(!document.fullscreenElement&&document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen()}catch(e){}
  try{if(screen.orientation&&typeof screen.orientation.lock==='function')await screen.orientation.lock('landscape')}catch(e){}
}
function updateEldoriaOrientation(){document.body.classList.toggle('eldoria-portrait',window.matchMedia('(orientation: portrait)').matches)}
document.getElementById('rotateBtn').addEventListener('click',async()=>{await requestEldoriaLandscape();updateLoginOrientation()});
document.getElementById('rotateContinue').addEventListener('click',()=>{document.body.classList.add('eldoria-rotation-dismissed')});
window.addEventListener('orientationchange',()=>{document.body.classList.remove('eldoria-rotation-dismissed');setTimeout(updateEldoriaOrientation,200)});updateEldoriaOrientation();



